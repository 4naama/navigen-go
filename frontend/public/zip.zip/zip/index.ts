// src/index.ts
// ES module Worker: QR (/s/*, /api/qr), Analytics (/api/track), Status (/api/status)

import QRCode from "qrcode";

// Fixed event order used by API + UI
const EVENT_ORDER = [
  "lpm-open","call","email","whatsapp","telegram","messenger",
  "official","booking","newsletter",
  "facebook","instagram","pinterest","spotify","tiktok","youtube",
  "share","rating","save","unsave","map","qr-print","qr-scan","qr-view","qr-redeem",
  "redeem-confirmation-cashier",    // cashier confirmed that a redeem event completed
  "redeem-confirmation-customer"    // customer confirmed that a redeem event completed
] as const;

type EventKey = typeof EVENT_ORDER[number];

// tz: payload.tz → country → fallback Berlin → UTC
const TZ_FALLBACK = "Europe/Berlin";
const TZ_BY_COUNTRY: Record<string,string> = {
  HU:"Europe/Budapest", DE:"Europe/Berlin", AT:"Europe/Vienna", CH:"Europe/Zurich",
  GB:"Europe/London",  IE:"Europe/Dublin",  // extend as needed
};
function dayKeyFor(dateUTC: Date, tz?: string, countryCode?: string) {
  const pick = tz || (countryCode && TZ_BY_COUNTRY[countryCode.toUpperCase()]) || TZ_FALLBACK;
  try { return new Intl.DateTimeFormat('en-CA',{ timeZone: pick, year:'numeric',month:'2-digit',day:'2-digit'}).format(dateUTC); }
  catch { return dateUTC.toISOString().slice(0,10); } // UTC fallback
}
async function kvIncr(kv: KVNamespace, key: string) {
  const cur = parseInt((await kv.get(key))||"0",10) || 0;
  await kv.put(key, String(cur+1), { expirationTtl: 60*60*24*366 });
}

export interface Env {
  KV_STATUS: KVNamespace;
  KV_ALIASES: KVNamespace;
  KV_OVERRIDES: KVNamespace;
  KV_STATS: KVNamespace;
  JWT_SECRET: string; // set via wrangler secret
  STRIPE_SECRET_KEY: string; // Stripe secret key for creating Checkout Sessions (server-only)
  STRIPE_WEBHOOK_SECRET: string; // Stripe webhook signing secret (whsec_...)
}

// --- Plan persistence (Phase 8 prerequisite) ---
// Authoritative source: Stripe Checkout Session line items (price.id) at reconciliation time.
// Publish MUST NOT call Stripe; publish reads plan:<payment_intent.id> from KV_STATUS.

type PlanTier = "standard" | "multi" | "large" | "network" | "unknown";

type PlanRecord = {
  priceId: string;
  tier: PlanTier;
  maxPublishedLocations: number;
  purchasedAt: string; // ISO
  expiresAt: string;   // ISO (must equal ownership.exclusiveUntil for same payment)
  initiationType: string;
  campaignPreset: string;
};

// Stripe price.id values from the Dashboard.
// Fail-closed behavior for publish is enforced by maxPublishedLocations=0 when unknown.
const PRICE_ID_TO_PLAN: Record<string, { tier: PlanTier; maxPublishedLocations: number }> = {
  "price_1TDfBIFf2RZOYEdOobudnFRW": { tier: "standard", maxPublishedLocations: 1 },     // TESTING: real Stripe price id for €1
  "price_1TDfBtFf2RZOYEdOGIfPn6uu": { tier: "multi",    maxPublishedLocations: 3 },     // TESTING: real Stripe price id for €2
  "price_1TDfDfFf2RZOYEdOFicVRcQ8": { tier: "large",    maxPublishedLocations: 10 },    // TESTING: real Stripe price id for €319
  "price_1TDfFaFf2RZOYEdOXzIMBxbO": { tier: "network",  maxPublishedLocations: 10000 }, // TESTING: real Stripe price id for €749
};

// Plan chooser codes are BO-facing; price ids are Worker-authoritative.
// Keep this mapping centralized so checkout, restore, and enforcement resolve the same tier contract.
const PLAN_CODE_TO_PRICE_ID: Record<string, string> = {
  standard: "price_1TDfBIFf2RZOYEdOobudnFRW", // TESTING: real Stripe price id for €1
  multi: "price_1TDfBtFf2RZOYEdOGIfPn6uu",   // TESTING: real Stripe price id for €2
  large: "price_1TDfDfFf2RZOYEdOFicVRcQ8",   // TESTING: real Stripe price id for €319
  network: "price_1TDfFaFf2RZOYEdOXzIMBxbO"  // TESTING: real Stripe price id for €749
};

function normalizePlanTier(v: unknown): PlanTier {
  const s = String(v || "").trim().toLowerCase();
  if (s === "standard" || s === "multi" || s === "large" || s === "network") return s;
  return "unknown";
}

function planDefinitionForCode(planCode: unknown): { code: string; priceId: string; tier: PlanTier; maxPublishedLocations: number } | null {
  const code = String(planCode || "").trim().toLowerCase();
  const priceId = String(PLAN_CODE_TO_PRICE_ID[code] || "").trim();
  if (!priceId) return null;

  const mapped = PRICE_ID_TO_PLAN[priceId];
  if (!mapped) return null;

  return {
    code,
    priceId,
    tier: normalizePlanTier(mapped.tier),
    maxPublishedLocations: Math.max(0, Number(mapped.maxPublishedLocations || 0) || 0)
  };
}

async function fetchStripeCheckoutLineItemPriceId(sk: string, checkoutSessionId: string): Promise<string> {
  const url = `https://api.stripe.com/v1/checkout/sessions/${encodeURIComponent(checkoutSessionId)}/line_items?limit=1`;
  const r = await fetch(url, { method: "GET", headers: { Authorization: `Bearer ${sk}` } });
  const txt = await r.text();
  let j: any = null;
  try { j = JSON.parse(txt); } catch { j = null; }

  if (!r.ok) throw new Error(`stripe_line_items_fetch_failed:${r.status}`);
  const item = j?.data && Array.isArray(j.data) && j.data.length ? j.data[0] : null;

  // Stripe line item structure: item.price.id OR item.price (string) depending on API version
  const priceId = String(item?.price?.id || item?.price || "").trim();
  if (!priceId) throw new Error("stripe_line_items_missing_price_id");
  return priceId;
}

async function persistPlanRecord(
  env: Env,
  sk: string,
  checkoutSessionId: string,
  paymentIntentId: string,
  expiresAtIso: string,
  provenance?: { initiationType?: unknown; campaignPreset?: unknown }
): Promise<PlanRecord> {
  const priceId = await fetchStripeCheckoutLineItemPriceId(sk, checkoutSessionId);

  const mapped = PRICE_ID_TO_PLAN[priceId];
  const tier: PlanTier = mapped?.tier || "unknown";
  const maxPublishedLocations = mapped?.maxPublishedLocations ?? 0;
  const initiationType = String(provenance?.initiationType || "").trim();
  const campaignPreset = String(provenance?.campaignPreset || "").trim();

  const rec: PlanRecord = {
    priceId,
    tier,
    maxPublishedLocations,
    purchasedAt: new Date().toISOString(),
    expiresAt: expiresAtIso,
    initiationType,
    campaignPreset
  };

  await env.KV_STATUS.put(`plan:${paymentIntentId}`, JSON.stringify(rec));
  return rec;
}

// --- Stripe webhook verification (HMAC SHA-256) ---
// Lead: keep verification server-side only; never expose secrets to clients.
function parseStripeSigHeader(h: string): { t: string; v1: string[] } | null {
  const parts = String(h || '').split(',').map(s => s.trim()).filter(Boolean);
  const out: { t: string; v1: string[] } = { t: '', v1: [] };
  for (const p of parts) {
    const [k, v] = p.split('=').map(s => s.trim());
    if (!k || !v) continue;
    if (k === 't') out.t = v;
    if (k === 'v1') out.v1.push(v);
  }
  if (!out.t || !out.v1.length) return null;
  return out;
}

function bytesToHex(b: Uint8Array): string {
  return Array.from(b).map(x => x.toString(16).padStart(2, '0')).join('');
}

async function hmacSha256Hex(secret: string, msg: string): Promise<string> {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    'raw',
    enc.encode(secret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );
  const sig = await crypto.subtle.sign('HMAC', key, enc.encode(msg));
  return bytesToHex(new Uint8Array(sig));
}

// Lead: Stripe tolerates minor clock skew; keep tolerance conservative.
async function verifyStripeSignature(rawBody: string, sigHeader: string, secret: string, toleranceSec = 300): Promise<boolean> {
  const parsed = parseStripeSigHeader(sigHeader);
  if (!parsed) return false;

  const ts = Number(parsed.t);
  if (!Number.isFinite(ts)) return false;

  const nowSec = Math.floor(Date.now() / 1000);
  if (Math.abs(nowSec - ts) > toleranceSec) return false;

  const signedPayload = `${parsed.t}.${rawBody}`;
  const expected = await hmacSha256Hex(secret, signedPayload);

  // accept if any v1 matches (Stripe may send multiple)
  return parsed.v1.some(v => v.toLowerCase() === expected.toLowerCase());
}

// Stripe signs the exact raw request bytes: HMAC_SHA256(secret, `${t}.${rawBody}`).
// This verifier avoids decode/re-encode mismatches and must be used for webhook authenticity checks.a
async function verifyStripeSignatureBytes(rawBody: Uint8Array, sigHeader: string, secret: string, toleranceSec = 300): Promise<boolean> {
  const parsed = parseStripeSigHeader(sigHeader);
  if (!parsed) return false;

  const ts = Number(parsed.t);
  if (!Number.isFinite(ts)) return false;

  const nowSec = Math.floor(Date.now() / 1000);
  if (Math.abs(nowSec - ts) > toleranceSec) return false;

  const enc = new TextEncoder();
  const prefix = enc.encode(`${parsed.t}.`);
  const signed = new Uint8Array(prefix.length + rawBody.length);
  signed.set(prefix, 0);
  signed.set(rawBody, prefix.length);

  const expected = await (async () => {
    const key = await crypto.subtle.importKey(
      'raw',
      enc.encode(secret),
      { name: 'HMAC', hash: 'SHA-256' },
      false,
      ['sign']
    );
    const sig = await crypto.subtle.sign('HMAC', key, signed);
    return bytesToHex(new Uint8Array(sig));
  })();

  return parsed.v1.some(v => v.toLowerCase() === expected.toLowerCase());
}

function hexPrefix(buf: ArrayBuffer, nBytes = 4): string {
  const bytes = new Uint8Array(buf);
  const take = Math.min(bytes.length, nBytes);
  let out = '';
  for (let i = 0; i < take; i++) out += bytes[i].toString(16).padStart(2, '0');
  return out;
}

// --- Owner access session (Phase 2) ---
// Real-time owner access uses /owner/stripe-exchange.
// Cross-device or later recovery uses /owner/restore with PaymentIntent id (pi_*).
// Both flows mint the same HttpOnly op_sess cookie and bind one ULID per device session.

const ULID_RE = /^[0-9A-HJKMNP-TV-Z]{26}$/i;

function bytesToB64url(bytes: Uint8Array): string {
  let bin = "";
  for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function cookieSerialize(name: string, value: string, attrs: Record<string, string | boolean | number | undefined>): string {
  const parts: string[] = [`${name}=${value}`];
  for (const [k, v] of Object.entries(attrs)) {
    if (v === undefined) continue;
    if (v === true) parts.push(k);
    else parts.push(`${k}=${String(v)}`);
  }
  return parts.join("; ");
}

function readCookie(header: string, name: string): string {
  const h = String(header || "");
  const parts = h.split(";");
  for (const p of parts) {
    const [k, ...rest] = p.trim().split("=");
    if (!k) continue;
    if (k === name) return rest.join("=").trim();
  }
  return "";
}

function readDeviceId(req: Request): string {
  const dev = readCookie(req.headers.get("Cookie") || "", "ng_dev");
  return String(dev || "").trim();
}

function mintDeviceId(): { dev: string; cookie: string } {
  // 18 bytes → URL-safe base64; unguessable; stable per device cookie lifetime
  const bytes = new Uint8Array(18);
  (crypto as any).getRandomValues(bytes);
  const dev = bytesToB64url(bytes);

  const cookie = cookieSerialize("ng_dev", dev, {
    Path: "/",
    Secure: true,
    SameSite: "Lax",
    "Max-Age": 60 * 60 * 24 * 366 // ~12 months
    // Not HttpOnly: client can read, but Worker is authoritative on binding.
  });

  return { dev, cookie };
}

function devSessKey(dev: string, ulid: string): string {
  return `devsess:${dev}:${ulid}`;
}

function devIndexKey(dev: string): string {
  return `devsess:${dev}:index`;
}

const RATING_WINDOW_MS = 30 * 60 * 1000;

function ratingSummaryKey(locationID: string): string {
  return `rating_summary:${locationID}`;
}

function ratingVoteKey(locationID: string, deviceKey: string): string {
  return `rating_vote:${locationID}:${deviceKey}`;
}

function readRatingDeviceKey(req: Request): string {
  const explicit = String(req.headers.get("X-NG-Device") || "").trim();
  if (explicit) return explicit;

  const cookieDev = readDeviceId(req);
  if (cookieDev) return cookieDev;

  const ip = String(req.headers.get("CF-Connecting-IP") || "").trim();
  const ua = String(req.headers.get("User-Agent") || "").trim().slice(0, 120);
  return encodeURIComponent(`${ip}|${ua}`.trim());
}

async function kvAdd(kv: KVNamespace, key: string, delta: number, ttlSec = 60 * 60 * 24 * 366): Promise<number> {
  const cur = parseInt((await kv.get(key)) || "0", 10) || 0;
  const next = Math.max(0, cur + (Number.isFinite(delta) ? delta : 0));

  if (next <= 0) {
    try { await kv.delete(key); } catch {}
    return 0;
  }

  await kv.put(key, String(next), { expirationTtl: ttlSec });
  return next;
}

type RatingSummary = {
  count: number;
  sum: number;
  avg: number;
};

async function readRatingSummary(env: Env, locationID: string): Promise<RatingSummary> {
  const cached = await env.KV_STATUS.get(ratingSummaryKey(locationID), { type: "json" }) as any;
  const cachedCount = Number(cached?.count);
  const cachedSum = Number(cached?.sum);

  if (Number.isFinite(cachedCount) && cachedCount >= 0 && Number.isFinite(cachedSum) && cachedSum >= 0) {
    return {
      count: cachedCount,
      sum: cachedSum,
      avg: cachedCount > 0 ? (cachedSum / cachedCount) : 0
    };
  }

  let count = 0;
  let sum = 0;
  let cursor: string | undefined = undefined;

  do {
    const page = await env.KV_STATS.list({ prefix: `stats:${locationID}:`, cursor });
    for (const key of page.keys) {
      const name = String(key.name || "");
      const parts = name.split(":");
      if (parts.length !== 4) continue;

      const bucket = String(parts[3] || "").trim();
      if (bucket !== "rating" && bucket !== "rating-score") continue;

      const value = parseInt((await env.KV_STATS.get(name)) || "0", 10) || 0;
      if (bucket === "rating") count += value;
      else sum += value;
    }
    cursor = page.cursor || undefined;
  } while (cursor);

  try {
    await env.KV_STATUS.put(
      ratingSummaryKey(locationID),
      JSON.stringify({ count, sum, updatedAt: new Date().toISOString() })
    );
  } catch {
    // summary cache must never block reads
  }

  return {
    count,
    sum,
    avg: count > 0 ? (sum / count) : 0
  };
}

type OwnerSession = {
  ver: number;
  ulid: string;
  createdAt: string;
  expiresAt: string;
};

async function requireOwnerSession(req: Request, env: Env): Promise<{ ulid: string } | Response> {
  const sid = readCookie(req.headers.get("Cookie") || "", "op_sess");
  if (!sid) {
    return new Response("Denied", {
      status: 401,
      headers: { "cache-control": "no-store", "Referrer-Policy": "no-referrer" }
    });
  }

  const sessKey = `opsess:${sid}`;
  const sess = await env.KV_STATUS.get(sessKey, { type: "json" }) as OwnerSession | null;
  if (!sess || !sess.ulid) {
    return new Response("Denied", {
      status: 401,
      headers: { "cache-control": "no-store", "Referrer-Policy": "no-referrer" }
    });
  }

  const exp = new Date(String(sess.expiresAt || ""));
  if (Number.isNaN(exp.getTime()) || exp.getTime() <= Date.now()) {
    // Session expired; fail closed. (We do not rely on cookie expiry alone.)
    return new Response("Denied", {
      status: 401,
      headers: { "cache-control": "no-store", "Referrer-Policy": "no-referrer" }
    });
  }

  // Authentication only: session validity + ULID binding.
  // Campaign entitlement is enforced by the endpoint itself, not here.
  return { ulid: String(sess.ulid).trim() };
}

async function promoteCampaignDraftAndBuildRedirectHint(
  req: Request,
  sess: any,
  ulid: string,
  env: Env,
  logTag: string
): Promise<string> {
  // Build a deterministic hint for the landing UI (not a source of truth; just prevents sticky wrong paint).
  // If this checkout session funded a campaign, promote draft now and enrich redirect with campaign hint.
  try {
    const md = (sess?.metadata && typeof sess.metadata === "object") ? sess.metadata : {};
    const ownershipSource = String(md?.ownershipSource || "").trim();
    const campaignKey = String(md?.campaignKey || "").trim();

    if (ownershipSource !== "campaign" || !campaignKey) return "";

    const draftKey = `campaigns:draft:${ulid}`;
    const draft = await env.KV_STATUS.get(draftKey, { type: "json" }) as any;

    if (!draft || String(draft?.campaignKey || "").trim() !== campaignKey) return "";

    const currentPlan = await currentPlanForUlid(env, ulid);
    const promoted = await promoteCampaignDraftToActiveRows({
      req,
      env,
      ownerUlid: ulid,
      draft,
      locationSlug: String(md?.locationID || "").trim(),
      campaignKey,
      stripeSessionId: String(sess?.id || "").trim(),
      paidPlan: currentPlan,
      logTag
    });

    if (!promoted.ok) return "";

    await env.KV_STATUS.delete(draftKey);

    const end = String(promoted.endDate || "").trim();
    if (/^\d{4}-\d{2}-\d{2}$/.test(end)) {
      return `ce=1&ced=${encodeURIComponent(end)}&cak=${encodeURIComponent(campaignKey)}`;
    }
    return `ce=1&cak=${encodeURIComponent(campaignKey)}`;
  } catch (e: any) {
    console.error(`${logTag}: promote_failed`, {
      ulid,
      err: String(e?.message || e || "")
    });
    // Do not block exchange/restore on hint/promotion failure.
    return "";
  }
}

async function handleOwnerStripeExchange(req: Request, env: Env): Promise<Response> {
  const u = new URL(req.url);
  const sid = String(u.searchParams.get("sid") || "").trim();
  const nextRaw = String(u.searchParams.get("next") || "").trim();

  const noStoreHeaders = { "cache-control": "no-store", "Referrer-Policy": "no-referrer" };

  if (!sid) return new Response("Denied", { status: 400, headers: noStoreHeaders });

  // Prevent open redirects: allow only same-origin relative paths.
  const isSafeNext = (p: string) =>
    p.startsWith("/") && !p.startsWith("//") && !p.includes("://") && !p.includes("\\");
const next = (nextRaw && isSafeNext(nextRaw)) ? nextRaw : "";
let redirectHint = ""; // ensure local scope for redirect logic used later in /owner/restore

  const sk = String((env as any).STRIPE_SECRET_KEY || "").trim();
  if (!sk) return new Response("Misconfigured", { status: 500, headers: noStoreHeaders });

  // Fetch Stripe Checkout Session and verify payment.
  const stripeUrl = `https://api.stripe.com/v1/checkout/sessions/${encodeURIComponent(sid)}`;
  const r = await fetch(stripeUrl, {
    method: "GET",
    headers: { "Authorization": `Bearer ${sk}` }
  });

  const txt = await r.text();
  let sess: any = null;
  try { sess = JSON.parse(txt); } catch { sess = null; }
  if (!r.ok || !sess) return new Response("Denied", { status: 403, headers: noStoreHeaders });

  const paymentStatus = String(sess?.payment_status || "").toLowerCase();
  const status = String(sess?.status || "").toLowerCase();
  if (paymentStatus !== "paid" || status !== "complete") {
    return new Response("Denied", { status: 403, headers: noStoreHeaders });
  }

  const meta = sess?.metadata || {};
    redirectHint = '';

  const target = await resolveTargetIdentity(env, {
    locationID: meta?.locationID,
    draftULID: meta?.draftULID,
    draftSessionId: meta?.draftSessionId
  }, { validateDraft: true });
  if (!target) return new Response("Denied", { status: 403, headers: noStoreHeaders });

  const ulid = target.ulid;
  const locationID = target.locationID;

  // Canonical: a paid campaign checkout is itself the state transition trigger.
  // Do NOT depend on webhook timing for ownership/session/campaign visibility.
  const ownKey = `ownership:${ulid}`;

  // Compute ownership window. Keep current behavior: 30d exclusive + 60d courtesy.
  // If an ownership record already exists, extend from its exclusiveUntil when later than now.
  const now = Date.now();
  const prev = await env.KV_STATUS.get(ownKey, { type: "json" }) as any;

  const prevExIso = String(prev?.exclusiveUntil || "").trim();
  const prevEx = prevExIso ? new Date(prevExIso) : null;
  const baseMs = (prevEx && !Number.isNaN(prevEx.getTime()) && prevEx.getTime() > now) ? prevEx.getTime() : now;

  const EXCLUSIVE_MS = 30 * 24 * 60 * 60 * 1000;
  const COURTESY_MS  = 60 * 24 * 60 * 60 * 1000;

  const exclusiveUntil = new Date(baseMs + EXCLUSIVE_MS);
  const courtesyUntil  = new Date(exclusiveUntil.getTime() + COURTESY_MS);

  // Persist ownership deterministically (reconciliation path).
  // Invariant: ownership.lastEventId is the Plan anchor for publish capacity.
  await env.KV_STATUS.put(ownKey, JSON.stringify({
    uid: ulid,
    state: "owned",
    exclusiveUntil: exclusiveUntil.toISOString(),
    source: String(meta?.ownershipSource || "campaign").trim() || "campaign",
    lastEventId: String(sess?.payment_intent || "").trim(),
    updatedAt: new Date().toISOString()
  }));

  // Persist Plan record for publish capacity (KV-only at publish time).
  // Requires Checkout Session line items → price.id → internal tier map.
  try {
    const paymentIntentId = String(sess?.payment_intent || "").trim();
    if (paymentIntentId) {
      // expiresAt must align with ownership exclusiveUntil invariant
      await persistPlanRecord(env, sk, String(sess?.id || "").trim(), paymentIntentId, exclusiveUntil.toISOString(), {
        initiationType: meta?.initiationType,
        campaignPreset: meta?.campaignPreset
      });      
    }
  } catch (e: any) {
    console.error("owner_stripe_exchange: plan_persist_failed", { ulid, err: String(e?.message || e || "") });
    // Must NOT block session minting if plan persistence fails.
  }

  // Create sessionId (unguessable) and store opsess:<sid> (same as /owner/exchange).
  const sidBytes = new Uint8Array(18);
  (crypto as any).getRandomValues(sidBytes);
  const sessionId = bytesToB64url(sidBytes);

  const createdAt = new Date();
  const expiresAt = exclusiveUntil;

  const sessKey = `opsess:${sessionId}`;
  const sessVal = {
    ver: 1,
    ulid,
    createdAt: createdAt.toISOString(),
    expiresAt: expiresAt.toISOString()
  };

  const maxAge = Math.max(0, Math.floor((expiresAt.getTime() - createdAt.getTime()) / 1000));
  try {
    await env.KV_STATUS.put(sessKey, JSON.stringify(sessVal), { expirationTtl: Math.max(60, maxAge) });
  } catch {
    return new Response("Denied", { status: 500, headers: noStoreHeaders });
  }

  // Register this session to the current device so Owner Center can switch without email receipts (ng_dev cookie).
  let devSetCookie = "";
  try {
    let dev = readDeviceId(req);
    if (!dev) {
      const minted = mintDeviceId();
      dev = minted.dev;
      devSetCookie = minted.cookie;
    }

    if (dev) {
      const mapKey = devSessKey(dev, ulid);
      await env.KV_STATUS.put(mapKey, sessionId, { expirationTtl: Math.max(60, maxAge) });

      const idxKey = devIndexKey(dev);
      const rawIdx = await env.KV_STATUS.get(idxKey, "text");
      let arr: string[] = [];
      try { arr = rawIdx ? (JSON.parse(rawIdx) as any) : []; } catch { arr = []; }
      if (!Array.isArray(arr)) arr = [];
      if (!arr.includes(ulid)) arr.unshift(ulid);
      // keep small, deterministic list (most recent first)
      arr = arr.slice(0, 24);
      await env.KV_STATUS.put(idxKey, JSON.stringify(arr), { expirationTtl: 60 * 60 * 24 * 366 });
    }
  } catch {
    // device registry must never block owner exchange
  }

  // If this checkout session funded a campaign, promote draft now and enrich redirect with campaign hint.
  // This avoids "sticky wrong" LPM badge rendering after redirect.
  redirectHint = await promoteCampaignDraftAndBuildRedirectHint(req, sess, ulid, env, "owner_stripe_exchange");
  
  const cookie = cookieSerialize("op_sess", sessionId, {
    Path: "/",
    HttpOnly: true,
    Secure: true,
    SameSite: "Lax",
    "Max-Age": maxAge
  });

  const headers = new Headers({ ...noStoreHeaders });

  headers.append("Set-Cookie", cookie);
  if (devSetCookie) headers.append("Set-Cookie", devSetCookie);

  headers.set("Location", (() => {
    const base = next || `/dash/${encodeURIComponent(ulid)}`;
    if (!redirectHint) return base;

    const u = new URL(base, "https://navigen.io");
    if (!u.searchParams.get("ce")) {
      const parts = redirectHint.split("&");
      parts.forEach(kv => {
        const [k, v] = kv.split("=");
        if (k && v && !u.searchParams.get(k)) u.searchParams.set(k, decodeURIComponent(v));
        else if (k && !u.searchParams.get(k)) u.searchParams.set(k, "1");
      });
    }
    return u.pathname + u.search + u.hash;
  })());

  console.info("owner_exchange_success", { ulid, stripeSessionId: sess?.id, sessionId });
  return new Response(null, { status: 302, headers });
}

// --- Ownership writer (Phase 1): KV_STATUS keys ---
// - ownership:<ULID>
// - stripe_processed:<payment_intent.id>
async function handleStripeWebhook(req: Request, env: Env): Promise<Response> {
  const sig = req.headers.get('Stripe-Signature') || '';
  if (!sig) {
    const u = new URL(req.url);
    console.warn('stripe_webhook: missing_signature_header', { host: u.host, path: u.pathname });
    return new Response('Missing Stripe-Signature header', { status: 400 });
  }

  // Raw body is required for signature verification
  const rawBuf = await req.arrayBuffer();
  const rawBytes = new Uint8Array(rawBuf);
  // Decode once for optional text-based verification fallback (do NOT parse until verified).
  const rawText = new TextDecoder().decode(rawBytes);

  // Verify against raw bytes (Stripe signs exact bytes)
  let secretRaw = String(env.STRIPE_WEBHOOK_SECRET || "").trim();
  // Guard against accidental surrounding quotes (common when pasting secrets via shells/UIs).
  if (
    (secretRaw.startsWith('"') && secretRaw.endsWith('"')) ||
    (secretRaw.startsWith("'") && secretRaw.endsWith("'")) ||
    (secretRaw.startsWith("`") && secretRaw.endsWith("`"))
  ) {
    secretRaw = secretRaw.slice(1, -1).trim();
  }

  // Safe fingerprint: lets us confirm which secret is deployed without exposing it.
  const enc = new TextEncoder();
  const secretFpBuf = await crypto.subtle.digest('SHA-256', enc.encode(secretRaw));
  const secretFp = hexPrefix(secretFpBuf, 6); // 12 hex chars

  // Reject obviously invalid/misconfigured secrets early.
  // Stripe webhook signing secrets are "whsec_..." and are long; anything else is a config error.
  if (secretRaw.length < 20 || !secretRaw.startsWith("whsec_")) {
    console.error("stripe_webhook: secret_invalid", { secretLen: secretRaw.length, secretFp });
    return new Response("Stripe webhook secret invalid/misconfigured", { status: 500 });
  }

  // Allow a comma/whitespace-separated list to support safe multi-env deployments (test+live).
  const secrets = secretRaw.split(/[\s,]+/g).map(s => s.trim()).filter(Boolean);

  // Per-secret fingerprinting (safe): helps identify which candidate secrets are present.
  const secretFps: string[] = [];
  for (const s of secrets) {
    const b = await crypto.subtle.digest('SHA-256', enc.encode(s));
    secretFps.push(hexPrefix(b, 6)); // 12 hex chars each
  }

  // Fail loudly if the secret is not configured. (A silent 400 looks like a bad Stripe delivery.)
  if (!secrets.length) {
    const u = new URL(req.url);
    console.error('stripe_webhook: secret_not_configured', { host: u.host, path: u.pathname });
    return new Response('Stripe webhook secret not configured', { status: 500 });
  }

  let ok = false;
  let verifyMode: 'bytes' | 'text' | null = null;
  let bytesOk = false;
  let textOk = false;

  for (const s of secrets) {
    // Try bytes first (canonical)
    bytesOk = await verifyStripeSignatureBytes(rawBytes, sig, s);
    if (bytesOk) { ok = true; verifyMode = 'bytes'; break; }

    // Then try text fallback (diagnostic)
    textOk = await verifyStripeSignature(rawText, sig, s);
    if (textOk) { ok = true; verifyMode = 'text'; break; }
  }

  if (!ok) {
    const u = new URL(req.url);

    // Parse Stripe timestamp to detect tolerance/skew issues (without trusting clocks blindly).
    let ts: number | null = null;
    try {
      const parsed = parseStripeSigHeader(sig);
      ts = parsed ? Number(parsed.t) : null;
      if (ts !== null && !Number.isFinite(ts)) ts = null;
    } catch {
      ts = null;
    }

    const nowSec = Math.floor(Date.now() / 1000);

    const parsedForLog = parseStripeSigHeader(sig);
    console.warn('stripe_webhook: sig_invalid', {
      host: u.host,
      path: u.pathname,
      skewSec: ts === null ? null : (nowSec - ts),
      contentEncoding: req.headers.get('content-encoding') || null,
      contentType: req.headers.get('content-type') || null,
      bodyLen: rawBytes.length,

      // Header parse diagnostics
      sigParsed: !!parsedForLog,
      v1Count: parsedForLog?.v1?.length || 0,
      stripeAccount: req.headers.get("Stripe-Account") || "",

      // Secret diagnostics
      secretsCount: secrets.length,
      secretFp,          // keep legacy combined fingerprint
      secretFps,         // per-candidate fingerprints (safe)
      bytesOk,
      textOk
    });

    return new Response('Invalid Stripe signature', {
      status: 400,
      headers: {
        // Safe diagnostics: helps prove which secret is deployed and whether header parse looks sane.
        "x-ng-secretfp": secretFp,
        "x-ng-secretfps": secretFps.join(","),      // per-candidate fingerprints
        "x-ng-secrets": String(secrets.length),
        "x-ng-worker": "navigen-api",
        "x-ng-sigparsed": String(!!parsedForLog),
        "x-ng-v1count": String(parsedForLog?.v1?.length || 0),

        "x-ng-verify": verifyMode || "",
        "x-ng-skewsec": String(ts === null ? "" : (nowSec - ts)),
        "x-ng-encoding": req.headers.get("content-encoding") || "",
        "x-ng-bodylen": String(rawBytes.length)
      }
    });
  }

  const rawBody = new TextDecoder().decode(rawBytes); // decode only after signature verification
  let evt: any = null;
  try { evt = JSON.parse(rawBody); } catch { return new Response('Invalid JSON', { status: 400 }); }

  const type = String(evt?.type || '').trim();
  // Phase 1: only accept checkout.session.completed as ownership-confirming
  if (type !== 'checkout.session.completed') return new Response('Ignored', { status: 200 });

  const session = evt?.data?.object || {};
  const paymentIntentId = String(session?.payment_intent || '').trim();
  if (!paymentIntentId) return new Response('Missing payment_intent', { status: 400 });

  const meta = (session?.metadata && typeof session.metadata === 'object') ? session.metadata : {};
  const ownershipSource = String(meta.ownershipSource || '').trim();   // "campaign" | "exclusive"
  const initiationType = String(meta.initiationType || '').trim();     // "owner" | "agent" | "platform"

  // Non-ownership checkouts (e.g. donations) may have empty metadata.
  // We must acknowledge the webhook to prevent Stripe retries and simply ignore it.
  if (!ownershipSource || !initiationType) {
    return new Response('Ignored (no ownership metadata)', { status: 200 });
  }

  const target = await resolveTargetIdentity(env, {
    locationID: meta?.locationID,
    draftULID: meta?.draftULID,
    draftSessionId: meta?.draftSessionId
  }, { validateDraft: true });
  if (!target || !/^[0-9A-HJKMNP-TV-Z]{26}$/i.test(target.ulid)) {
    return new Response('target identity did not resolve to a canonical ULID', { status: 400 });
  }

  const ulid = target.ulid;
  const locationID = target.locationID;

  // Idempotency
  const idemKey = `stripe_processed:${paymentIntentId}`;
  const seen = await env.KV_STATUS.get(idemKey);
  if (seen) return new Response('OK', { status: 200 });

  const ownKey = `ownership:${ulid}`;
  const current = await env.KV_STATUS.get(ownKey, { type: 'json' }) as any;

  const now = new Date();
  const curUntil = current?.exclusiveUntil ? new Date(String(current.exclusiveUntil)) : null;
  const base = (curUntil && !Number.isNaN(curUntil.getTime()) && curUntil > now) ? curUntil : now;

  // Phase 1: minimum ownership extension = 30 days (campaign coverage logic can expand later)
  const THIRTY_DAYS_MS = 30 * 24 * 60 * 60 * 1000;
  const newUntil = new Date(base.getTime() + THIRTY_DAYS_MS);

  const rec = {
    uid: ulid,
    state: 'owned',
    exclusiveUntil: newUntil.toISOString(),
    source: ownershipSource,
    lastEventId: paymentIntentId,
    updatedAt: now.toISOString()
  };

  // Write ownership first; only then write idempotency marker
  await env.KV_STATUS.put(ownKey, JSON.stringify(rec));
  
  // Persist plan record (priceId from line items) with expiry aligned to ownership window.
  try {
    const sk = String((env as any).STRIPE_SECRET_KEY || "").trim();
    const checkoutSessionId = String(session?.id || "").trim();
    if (sk && checkoutSessionId) {
      await persistPlanRecord(env, sk, checkoutSessionId, paymentIntentId, rec.exclusiveUntil, {
        initiationType,
        campaignPreset: meta?.campaignPreset
      });      
    }
  } catch (e: any) {
    console.error("stripe_webhook: plan_persist_failed", { ulid, err: String(e?.message || e || "") });
    // Must NOT block ownership establishment if plan persistence fails.
  }
    
  await env.KV_STATUS.put(idemKey, JSON.stringify({
    paymentIntentId,
    ulid,
    ownershipSource,
    processedAt: now.toISOString()
  }));

  return new Response('OK', { status: 200, headers: { "x-ng-verify": verifyMode || "" } });
}

async function createCampaignCheckoutSession(env: Env, req: Request, body: any, noStore: Record<string, string>) {
  // Fail closed if not configured
  const sk = String((env as any).STRIPE_SECRET_KEY || "").trim();
  if (!sk) return json({ error: { code: "misconfigured", message: "STRIPE_SECRET_KEY not set" } }, 500, noStore);

  const locationID = String(body?.locationID || "").trim();           // MUST be slug when provided
  const draftULID = String(body?.draftULID || "").trim();
  const draftSessionId = String(body?.draftSessionId || "").trim();
  const campaignKey = String(body?.campaignKey || "").trim();         // required for ownershipSource="campaign"
  const initiationType = String(body?.initiationType || "").trim();   // "owner" | "public"
  const ownershipSource = String(body?.ownershipSource || "").trim(); // "campaign"
  const navigenVersion = String(body?.navigenVersion || "").trim() || "phase5";
  const planCode = String(body?.planCode || "").trim().toLowerCase();

  // Allow both owner-initiated and public (no-session) initiation types.
  // Canonical product: campaign payment is the only purchase; session is minted on return.
  const okInitiation = (initiationType === "owner" || initiationType === "public");
  const requestedPlan = planDefinitionForCode(planCode);
  const hasLocationRoute = !!locationID;
  const hasDraftRoute = !!draftULID || !!draftSessionId;
  if ((!hasLocationRoute && !hasDraftRoute) || (hasLocationRoute && hasDraftRoute) || !campaignKey || !okInitiation || ownershipSource !== "campaign" || !requestedPlan) {
    return json(
      { error: { code: "invalid_request", message: "exactly one target identity route (locationID OR draftULID + draftSessionId), campaignKey, valid planCode, initiationType in {'owner','public'}, ownershipSource='campaign' required" } },
      400,
      noStore
    );
  }

  // Reject generic billing keys; campaignKey must bind to the specific saved draft.
  // Prevents "paid but no campaign row" when promotion expects a draft-bound campaignKey.
  if (campaignKey === "campaign-30d") {
    return json(
      { error: { code: "invalid_request", message: "campaignKey must be the draft campaignKey (not 'campaign-30d')" } },
      400,
      noStore
    );
  }

  // Enforce the spec invariant: clients must never supply ULIDs as locationID
  if (locationID && /^[0-9A-HJKMNP-TV-Z]{26}$/i.test(locationID)) {
    return json({ error: { code: "invalid_request", message: "locationID must be a slug, not a ULID" } }, 400, noStore);
  }

  const target = await resolveTargetIdentity(env, { locationID, draftULID, draftSessionId }, { validateDraft: hasDraftRoute }).catch(() => null);
  if (!target) {
    return json({ error: { code: "not_found", message: hasLocationRoute ? "unknown locationID" : "unknown private shell target" } }, 404, noStore);
  }

  const ulid = target.ulid;

  // Validate the authoritative saved draft against the requested Plan tier before payment.
  // This keeps Stripe checkout aligned with scope/capacity rules and produces upgrade-safe failures.
  const draftKey = `campaigns:draft:${ulid}`;
  const draft = await env.KV_STATUS.get(draftKey, { type: "json" }) as any;
  if (!draft || String(draft?.campaignKey || "").trim() !== campaignKey) {
    return json({ error: { code: "invalid_state", message: "draft not found for the requested campaignKey" } }, 409, noStore);
  }

  const scope = normCampaignScope(draft?.campaignScope);
  const eligibleLocations = await eligibleLocationsForRequest(req, env, ulid);
  const eligibleByUlid = new Map(eligibleLocations.map((x) => [x.ulid, x]));
  const eligibleUlids = eligibleLocations.map((x) => x.ulid);

  if (scope !== "single" && requestedPlan.maxPublishedLocations <= 1) {
    return json(buildPlanUpgradeErrorBody(requestedPlan, scope, 2), 409, noStore);
  }

  let includedUlids: string[] = [ulid];
  if (scope === "selected") {
    includedUlids = Array.from(new Set((Array.isArray(draft?.selectedLocationULIDs) ? draft.selectedLocationULIDs : []).map((x: any) => String(x || "").trim()).filter(Boolean)));
    includedUlids = includedUlids.filter((id) => eligibleByUlid.has(id));
    if (!includedUlids.length) {
      return json({ error: { code: "invalid_state", message: "selected scope has no eligible locations" } }, 409, noStore);
    }
  } else if (scope === "all") {
    includedUlids = eligibleUlids.length ? eligibleUlids : [ulid];
  }

  if (requestedPlan.maxPublishedLocations > 0 && includedUlids.length > requestedPlan.maxPublishedLocations) {
    return json(buildPlanUpgradeErrorBody(requestedPlan, scope, includedUlids.length), 409, noStore);
  }

  const campaignPreset = normCampaignPreset(body?.campaignPreset || draft?.campaignPreset || "promotion");

  // Build redirect URLs on the web app origin (not the API Worker origin)
  const siteOrigin = req.headers.get("Origin") || "https://navigen.io";
  // IMPORTANT: keep {CHECKOUT_SESSION_ID} unencoded or Stripe will not substitute it.
  const successUrlObj = new URL("/", siteOrigin);
  successUrlObj.searchParams.set("flow", "campaign");
  if (target.route === "existing-location") {
    successUrlObj.searchParams.set("locationID", target.locationID);
  } else {
    successUrlObj.searchParams.set("draftULID", target.draftULID);
    successUrlObj.searchParams.set("draftSessionId", target.draftSessionId);
  }
  successUrlObj.searchParams.set("sid", "{CHECKOUT_SESSION_ID}");
  const successUrl = successUrlObj.toString().replace("%7BCHECKOUT_SESSION_ID%7D", "{CHECKOUT_SESSION_ID}");

  const cancelUrl = new URL("/", siteOrigin);
  cancelUrl.searchParams.set("flow", "campaign");
  if (target.route === "existing-location") {
    cancelUrl.searchParams.set("locationID", target.locationID);
  } else {
    cancelUrl.searchParams.set("draftULID", target.draftULID);
    cancelUrl.searchParams.set("draftSessionId", target.draftSessionId);
  }
  cancelUrl.searchParams.set("canceled", "1");

  const form = new URLSearchParams();
  form.set("mode", "payment");
  form.set("customer_creation", "if_required");
  form.set("billing_address_collection", "auto");
  form.set("success_url", successUrl);
  form.set("cancel_url", cancelUrl.toString());

  form.set("line_items[0][quantity]", "1");
  form.set("line_items[0][price]", requestedPlan.priceId);

  // Metadata contract (MUST be copied to PaymentIntent)
  if (target.route === "existing-location") {
    form.set("metadata[locationID]", target.locationID);
    form.set("payment_intent_data[metadata][locationID]", target.locationID);
  } else {
    form.set("metadata[draftULID]", target.draftULID);
    form.set("metadata[draftSessionId]", target.draftSessionId);
    form.set("payment_intent_data[metadata][draftULID]", target.draftULID);
    form.set("payment_intent_data[metadata][draftSessionId]", target.draftSessionId);
  }
  form.set("metadata[campaignKey]", campaignKey);
  form.set("metadata[initiationType]", initiationType);
  form.set("metadata[ownershipSource]", ownershipSource);
  form.set("metadata[campaignPreset]", campaignPreset);
  form.set("metadata[navigenVersion]", navigenVersion);

  // Ensure metadata is also on PaymentIntent (spec requirement)
  form.set("payment_intent_data[metadata][campaignKey]", campaignKey);
  form.set("payment_intent_data[metadata][initiationType]", initiationType);
  form.set("payment_intent_data[metadata][ownershipSource]", ownershipSource);
  form.set("payment_intent_data[metadata][campaignPreset]", campaignPreset);
  form.set("payment_intent_data[metadata][navigenVersion]", navigenVersion);

  const r = await fetch("https://api.stripe.com/v1/checkout/sessions", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${sk}`,
      "Content-Type": "application/x-www-form-urlencoded"
    },
    body: form.toString()
  });

  const txt = await r.text();
  let out: any = null;
  try { out = JSON.parse(txt); } catch { out = null; }

  if (!r.ok || !out?.id) {
    return json({ error: { code: "stripe_error", message: String(out?.error?.message || "Stripe create session failed") } }, 502, noStore);
  }

  return json({ sessionId: out.id, url: String(out.url || "") }, 200, noStore);
}

// Internal helper: resolve an item by canonical ULID (same semantics as /api/data/item?id=...).
// Returns null if not found. Keeps logic centralized for future “locations project”.
async function getItemById(ulid: string, env: Env): Promise<any | null> {
  const id = String(ulid || "").trim();
  if (!id) return null;

  try {
    const src = new URL("/data/profiles.json", "https://navigen.io").toString();
    const resp = await fetch(src, {
      cf: { cacheTtl: 60, cacheEverything: true },
      headers: { "Accept": "application/json" }
    });
    if (!resp.ok) return null;

    const data: any = await resp.json().catch(() => ({ locations: [] }));
    const arr: any[] = Array.isArray(data?.locations)
      ? data.locations
      : (data?.locations && typeof data.locations === "object")
        ? Object.values(data.locations)
        : [];

    if (!Array.isArray(arr)) return null;

    // 1) direct ULID match from profiles.json when present
    let hit = arr.find((r: any) => String(r?.ID || r?.id || "").trim() === id);
    if (hit) return hit;

    // 2) fallback: reverse alias lookup ULID -> slug via KV_ALIASES, then slug -> profiles.json
    if (env.KV_ALIASES) {
      let aliasSlug = "";
      let cursor: string | undefined = undefined;

      do {
        const page = await env.KV_ALIASES.list({ prefix: "alias:", cursor });
        for (const k of page.keys) {
          const name = k.name; // "alias:<slug>"
          const raw = await env.KV_ALIASES.get(name, "text");
          if (!raw) continue;

          let val = raw.trim();
          if (val.startsWith("{")) {
            try {
              const j = JSON.parse(val) as any;
              val = String(j?.locationID || "").trim();
            } catch {
              val = "";
            }
          }

          if (val && val === id) {
            aliasSlug = name.replace(/^alias:/, "");
            break;
          }
        }
        if (aliasSlug) break;
        cursor = page.cursor || undefined;
      } while (cursor);

      if (aliasSlug) {
        hit = arr.find((r: any) => String(r?.locationID || "").trim() === aliasSlug);
        if (hit) return hit;
      }
    }

    return null;
  } catch {
    return null;
  }
}

// Normalize a multilingual name field to a short display string.
function pickName(name: any): string {
  if (!name) return "";
  if (typeof name === "string") return name;
  if (typeof name === "object") {
    return String(name.en || name.hu || Object.values(name)[0] || "").trim();
  }
  return "";
}

// --- TEMP DO STUBS (deploy unblock) ---
// These stubs exist only to satisfy Wrangler Durable Object export checks during the profiles.json revamp.
// They must be replaced by the real implementations (or removed from wrangler.toml) when ready.
export class PlanAllocDO {
  state: DurableObjectState;
  env: any;
  constructor(state: DurableObjectState, env: any) {
    this.state = state;
    this.env = env;
  }
  async fetch(_req: Request): Promise<Response> {
    return new Response("PlanAllocDO not implemented", { status: 501 });
  }
}

export class SearchShardDO {
  state: DurableObjectState;
  env: any;
  constructor(state: DurableObjectState, env: any) {
    this.state = state;
    this.env = env;
  }
  async fetch(_req: Request): Promise<Response> {
    return new Response("SearchShardDO not implemented", { status: 501 });
  }
}

export class ContextShardDO {
  state: DurableObjectState;
  env: any;
  constructor(state: DurableObjectState, env: any) {
    this.state = state;
    this.env = env;
  }
  async fetch(_req: Request): Promise<Response> {
    return new Response("ContextShardDO not implemented", { status: 501 });
  }
}

export default {
  async fetch(req: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    const url = new URL(req.url);
    // normalize once: collapse repeats; strip one trailing slash (not root)
    const pathname = url.pathname;
    const normPath = pathname.replace(/\/{2,}/g, "/").replace(/(.+)\/$/, "$1");

    // --- CORS preflight: allow credentialed requests from allowed web origins
    // GLOBAL CORS PREFLIGHT — must run before all routing
    if (req.method === "OPTIONS") {
      const origin  = req.headers.get("Origin") || "";
      const reqHdrs = req.headers.get("Access-Control-Request-Headers") || "";
      const allow = new Set(["https://navigen.io","https://navigen-go.pages.dev"]);
      const allowOrigin = allow.has(origin) ? origin : "https://navigen.io";

      return new Response(null, {
        status: 204,
        headers: {
          "Access-Control-Allow-Origin": allowOrigin,
          "Access-Control-Allow-Credentials": "true", // REQUIRED for credentials
          "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
          "Access-Control-Allow-Headers": reqHdrs || "content-type, authorization, cache-control, pragma",
          "Access-Control-Max-Age": "600",
          "Vary": "Origin"
        }
      });
    }

    try {
      // --- Stripe diag: /api/_diag/stripe-secret (safe fingerprint only)
      if (normPath === "/api/_diag/stripe-secret" && req.method === "GET") {
        const secretRaw = (env.STRIPE_WEBHOOK_SECRET || "").trim();
        const enc = new TextEncoder();
        const fpBuf = await crypto.subtle.digest("SHA-256", enc.encode(secretRaw));
        const fp = hexPrefix(fpBuf, 6);
        return new Response(JSON.stringify({
          hasSecret: !!secretRaw,
          secretLen: secretRaw.length,
          secretFp: fp
        }), { status: 200, headers: { "content-type": "application/json", "x-ng-worker": "navigen-api" } });
      }

      // --- Owner Center: list device-bound locations (no secrets)
      if (normPath === "/api/owner/sessions" && req.method === "GET") {
        const dev = readDeviceId(req);
        if (!dev) {
          // No device id cookie set on this browser. Owner Center is device-bound, so we can’t list sessions yet.
          return json({ items: [], reason: "no_device_id" }, 200, { "cache-control": "no-store" });
        }

        const idxKey = devIndexKey(dev);
        const rawIdx = await env.KV_STATUS.get(idxKey, "text");
        let ulids: string[] = [];
        try { ulids = rawIdx ? JSON.parse(rawIdx) : []; } catch { ulids = []; }
        if (!Array.isArray(ulids)) ulids = [];

        // Only return ULIDs that still have a mapped session id
        const out: string[] = [];
        for (const u of ulids) {
          const ulid = String(u || "").trim();
          if (!ULID_RE.test(ulid)) continue;
          const sid = await env.KV_STATUS.get(devSessKey(dev, ulid), "text");
          if (sid) out.push(ulid);
        }

        return json({ items: out }, 200, { "cache-control": "no-store" });
      }

      // --- Owner Center: remove a device-bound location from this device registry
      // POST /api/owner/sessions/remove   body: { ulid: "<ULID>" }
      // Removes:
      // - devsess:<ng_dev>:<ULID>
      // - ULID from devsess:<ng_dev>:index
      if (normPath === "/api/owner/sessions/remove" && req.method === "POST") {
        const dev = readDeviceId(req);
        if (!dev) {
          return json({ error: { code: "no_device_id", message: "ng_dev missing" } }, 401, { "cache-control": "no-store" });
        }

        const body = await req.json().catch(() => ({})) as any;
        const ulid = String(body?.ulid || "").trim();
        if (!ULID_RE.test(ulid)) {
          return json({ error: { code: "invalid_request", message: "ulid required" } }, 400, { "cache-control": "no-store" });
        }

        // 1) delete mapping devsess:<dev>:<ulid>
        try { await env.KV_STATUS.delete(devSessKey(dev, ulid)); } catch {}

        // 2) remove from devsess:<dev>:index
        try {
          const idxKey = devIndexKey(dev);
          const rawIdx = await env.KV_STATUS.get(idxKey, "text");
          let arr: string[] = [];
          try { arr = rawIdx ? JSON.parse(rawIdx) : []; } catch { arr = []; }
          if (!Array.isArray(arr)) arr = [];
          arr = arr.filter(x => String(x || "").trim() !== ulid);
          await env.KV_STATUS.put(idxKey, JSON.stringify(arr), { expirationTtl: 60 * 60 * 24 * 366 });
        } catch {}

        return json({ ok: true, ulid }, 200, { "cache-control": "no-store" });
      }

      // --- Owner Campaigns: list active/history + current draft for this session-bound ULID
      // GET /api/owner/campaigns
      if (normPath === "/api/owner/campaigns" && req.method === "GET") {
        const sess = await requireOwnerSession(req, env);
        if (sess instanceof Response) return sess;
        const ulid = String(sess.ulid || "").trim();

        const draftKey = `campaigns:draft:${ulid}`;
        const histKey = campaignsByUlidKey(ulid);

        let draft: any = null;
        let history: any[] = [];

        try {
          const rawDraft = await env.KV_STATUS.get(draftKey, { type: "json" }) as any;
          if (rawDraft && typeof rawDraft === "object") draft = rawDraft;
        } catch {}

        try {
          const rawHist = await env.KV_STATUS.get(histKey, { type: "json" }) as any;
          history = Array.isArray(rawHist) ? rawHist : [];
        } catch {
          history = [];
        }

        const inherited = await materializeInheritedAllScopeForCurrentUlid(req, env, ulid).catch(() => ({
          addedRows: 0,
          addedGroups: 0,
          blockedRows: 0,
          blockedGroups: 0,
          blockedPlanTier: "",
          blockedMaxPublishedLocations: 0
        }));        
        if (inherited.addedRows > 0) {
          try {
            const refreshed = await env.KV_STATUS.get(histKey, { type: "json" }) as any;
            history = Array.isArray(refreshed) ? refreshed : history;
          } catch {}
        }

        const eligibleLocations = await eligibleLocationsForRequest(req, env, ulid);

        const currentPlan = await currentPlanForUlid(env, ulid);
        const currentGroupPlan = await currentGroupPlanForUlid(env, ulid);

        const effectivePlanTier = normalizePlanTier(currentPlan?.tier || currentGroupPlan?.tier);
        const effectivePlanCapacity = Math.max(
          0,
          Number(currentPlan?.maxPublishedLocations || currentGroupPlan?.maxPublishedLocations || 0) || 0
        );
        const multiLocationEnabled = effectivePlanCapacity > 1;

        // Provide a shallow "active" view for convenience (no resolver duplication).
        const nowMs = Date.now();
        const active = history.filter((r: any) => {
          const st = effectiveCampaignStatus(r);
          if (st !== "active") return false;
          const sMs = parseYmdUtcMs(String(r?.startDate || ""));
          const eMs = parseYmdUtcMs(String(r?.endDate || ""));
          if (!Number.isFinite(sMs) || !Number.isFinite(eMs)) return false;
          return nowMs >= sMs && nowMs <= (eMs + 24 * 60 * 60 * 1000 - 1);
        });

        return json(
          {
            ulid,
            draft,
            active,
            history,
            plan: {
              tier: String(effectivePlanTier || "").trim() || "unknown",
              maxPublishedLocations: effectivePlanCapacity,
              multiLocationEnabled
            },
            eligibleLocations,
            inheritedNotice: (inherited.addedRows > 0 || inherited.blockedRows > 0) ? {
              addedRows: inherited.addedRows,
              addedGroups: inherited.addedGroups,
              blockedRows: inherited.blockedRows,
              blockedGroups: inherited.blockedGroups,
              blockedPlanTier: inherited.blockedPlanTier,
              blockedMaxPublishedLocations: inherited.blockedMaxPublishedLocations
            } : null
          },
          200,
          { "cache-control": "no-store" }
        );
      }

      // --- Owner Campaign Group: flat roster for one campaignGroupKey on this device
      // GET /api/owner/campaigns/group?campaignGroupKey=<key>
      if (normPath === "/api/owner/campaigns/group" && req.method === "GET") {
        const sess = await requireOwnerSession(req, env);
        if (sess instanceof Response) return sess;

        const ulid = String(sess.ulid || "").trim();
        const campaignGroupKey = String(url.searchParams.get("campaignGroupKey") || "").trim();
        if (!campaignGroupKey) {
          return json({ error: { code: "invalid_request", message: "campaignGroupKey required" } }, 400, { "cache-control": "no-store" });
        }

        const eligible = await eligibleLocationsForRequest(req, env, ulid);
        const items = [];

        for (const loc of eligible) {
          const histRaw = await env.KV_STATUS.get(campaignsByUlidKey(loc.ulid), { type: "json" }) as any;
          const rows: any[] = Array.isArray(histRaw) ? histRaw : [];

          const row = [...rows].reverse().find((r: any) =>
            String(r?.campaignGroupKey || "").trim() === campaignGroupKey
          );

          if (row) {
            items.push({
              ulid: loc.ulid,
              slug: loc.slug,
              locationName: loc.locationName,
              included: true,
              status: String(row?.statusOverride || row?.status || "").trim().toLowerCase() || "active",
              campaignKey: String(row?.campaignKey || "").trim(),
              inheritedAt: String(row?.inheritedAt || "").trim() || ""
            });
          } else {
            items.push({
              ulid: loc.ulid,
              slug: loc.slug,
              locationName: loc.locationName,
              included: false,
              status: "excluded",
              campaignKey: "",
              inheritedAt: ""
            });
          }
        }

        return json(
          { campaignGroupKey, items },
          200,
          { "cache-control": "no-store" }
        );
      }
      
      // --- Owner Campaigns: upsert draft for this session-bound ULID
      // POST /api/owner/campaigns/draft  body: CampaignRow-like (slug + dates + rules)
      // Stores: campaigns:draft:<ULID>
      if (normPath === "/api/owner/campaigns/draft" && req.method === "POST") {
        const sess = await requireOwnerSession(req, env);
        if (sess instanceof Response) return sess;
        const ulid = String(sess.ulid || "").trim();

        const body = await req.json().catch(() => ({})) as any;

        const campaignKey = String(body?.campaignKey || "").trim();
        const startDate = String(body?.startDate || "").trim();
        const endDate = String(body?.endDate || "").trim();
        const scope = normCampaignScope(body?.campaignScope);
        const campaignPreset = normCampaignPreset(body?.campaignPreset);
        const requestedPlan = planDefinitionForCode(body?.planCode) || await currentPlanForUlid(env, ulid);

        if (!campaignKey) {
          return json({ error: { code: "invalid_request", message: "campaignKey required" } }, 400, { "cache-control": "no-store" });
        }
        if (!/^\d{4}-\d{2}-\d{2}$/.test(startDate) || !/^\d{4}-\d{2}-\d{2}$/.test(endDate)) {
          return json({ error: { code: "invalid_request", message: "startDate/endDate must be YYYY-MM-DD" } }, 400, { "cache-control": "no-store" });
        }

        const eligibleLocations = await eligibleLocationsForRequest(req, env, ulid);
        const eligibleByUlid = new Map(eligibleLocations.map((x) => [x.ulid, x]));
        const eligibleUlids = eligibleLocations.map((x) => x.ulid);

        if (scope !== "single" && Number(requestedPlan?.maxPublishedLocations || 0) <= 1) {
          return json(buildPlanUpgradeErrorBody(requestedPlan, scope, 2), 409, { "cache-control": "no-store" });
        }

        const selectedLocationULIDs: string[] = Array.isArray(body?.selectedLocationULIDs)
          ? Array.from(new Set(body.selectedLocationULIDs.map((x: any) => String(x || "").trim()).filter(Boolean))) as string[]
          : [];

        if (scope === "selected") {
          if (!selectedLocationULIDs.length) {
            return json({ error: { code: "invalid_request", message: "selected scope requires at least one location" } }, 400, { "cache-control": "no-store" });
          }
          for (const id of selectedLocationULIDs) {
            if (!eligibleByUlid.has(id)) {
              return json({ error: { code: "denied", message: "selected location is not eligible on this device" } }, 403, { "cache-control": "no-store" });
            }
          }
        }

        const requestedLocations = scope === "selected"
          ? selectedLocationULIDs.length
          : scope === "all"
            ? (eligibleUlids.length || 1)
            : 1;

        if (Number(requestedPlan?.maxPublishedLocations || 0) > 0 && requestedLocations > Number(requestedPlan?.maxPublishedLocations || 0)) {
          return json(buildPlanUpgradeErrorBody(requestedPlan, scope, requestedLocations), 409, { "cache-control": "no-store" });
        }

        const draft = {
          ...body,
          locationID: ulid,
          campaignKey,
          campaignGroupKey: scope === "single" ? "" : String(body?.campaignGroupKey || deriveCampaignGroupKey(String(body?.locationSlug || ulid), campaignKey)).trim(),
          campaignScope: scope,
          campaignPreset,
          planCode: String(body?.planCode || "").trim().toLowerCase(),
          selectedLocationULIDs,
          startDate,
          endDate,
          status: "Draft",
          updatedAt: new Date().toISOString()
        };

        const draftKey = `campaigns:draft:${ulid}`;
        await env.KV_STATUS.put(draftKey, JSON.stringify(draft));

        return json({ ok: true, ulid, draftKey: `campaigns:draft:<ULID>` }, 200, { "cache-control": "no-store" });
      }

      // --- Public Campaigns: create checkout session and persist draft without requiring owner session
      // POST /api/campaigns/checkout  body: { locationID:"<slug>", draft:{...}, planCode?:string }
      if (normPath === "/api/campaigns/checkout" && req.method === "POST") {
        const noStore = { "cache-control": "no-store", "Referrer-Policy": "no-referrer" };

        const body = await req.json().catch(() => ({})) as any;
        const locationSlug = String(body?.locationID || "").trim();
        const draftIn = (body?.draft && typeof body.draft === "object") ? body.draft : {};

        if (!locationSlug) return json({ error:{ code:"invalid_request", message:"locationID (slug) required" } }, 400, noStore);
        if (/^[0-9A-HJKMNP-TV-Z]{26}$/i.test(locationSlug)) {
          return json({ error:{ code:"invalid_request", message:"locationID must be a slug, not a ULID" } }, 400, noStore);
        }

        const resolved = await resolveUid(locationSlug, env).catch(() => null);
        const ulid = String(resolved || "").trim();
        if (!ulid) return json({ error:{ code:"not_found", message:"unknown locationID" } }, 404, noStore);

        // Validate draft minimally (server-authoritative; we only accept structurally valid campaigns).
        const campaignKey = String(draftIn?.campaignKey || "").trim();
        const startDate = String(draftIn?.startDate || "").trim();
        const endDate = String(draftIn?.endDate || "").trim();

        if (!campaignKey) return json({ error:{ code:"invalid_request", message:"draft.campaignKey required" } }, 400, noStore);
        if (!/^\d{4}-\d{2}-\d{2}$/.test(startDate) || !/^\d{4}-\d{2}-\d{2}$/.test(endDate)) {
          return json({ error:{ code:"invalid_request", message:"draft.startDate/endDate must be YYYY-MM-DD" } }, 400, noStore);
        }

        // Persist draft server-side, keyed by authoritative ULID.
        const draft = {
          ...draftIn,
          locationID: ulid,
          campaignKey,
          startDate,
          endDate,
          status: "Draft",
          updatedAt: new Date().toISOString()
        };

        await env.KV_STATUS.put(`campaigns:draft:${ulid}`, JSON.stringify(draft));

        const stripeReq = {
          locationID: locationSlug,
          campaignKey,
          initiationType: "public",
          ownershipSource: "campaign",
          navigenVersion: "phase5",
          planCode: body?.planCode
        };

        return await createCampaignCheckoutSession(env, req, stripeReq, noStore);
      }

      // --- Owner Campaigns: create checkout session from the current draft (session-bound)
      // POST /api/owner/campaigns/checkout  body: { locationID: "<slug>", planCode?: string }      
      if (normPath === "/api/owner/campaigns/checkout" && req.method === "POST") {
        const noStore = { "cache-control": "no-store", "Referrer-Policy": "no-referrer" };

        const sess = await requireOwnerSession(req, env);
        if (sess instanceof Response) return sess;
        const ulid = String(sess.ulid || "").trim();

        const body = await req.json().catch(() => ({})) as any;
        const locationSlug = String(body?.locationID || "").trim();

        if (!locationSlug) {
          return json({ error: { code: "invalid_request", message: "locationID (slug) required" } }, 400, noStore);
        }

        // Zero-trust: verify slug resolves to THIS session ULID.
        if (/^[0-9A-HJKMNP-TV-Z]{26}$/i.test(locationSlug)) {
          return json({ error: { code: "invalid_request", message: "locationID must be a slug, not a ULID" } }, 400, noStore);
        }

        const resolved = await resolveUid(locationSlug, env).catch(() => null);
        if (!resolved || String(resolved).trim() !== ulid) {
          return new Response("Denied", { status: 401, headers: noStore });
        }

        const draftKey = `campaigns:draft:${ulid}`;
        const draft = await env.KV_STATUS.get(draftKey, { type: "json" }) as any;
        const campaignKey = String(draft?.campaignKey || "").trim();
        if (!campaignKey) {
          return json({ error: { code: "invalid_request", message: "no draft campaign found for this location" } }, 400, noStore);
        }

        // Delegate to the same Stripe session creator used by /api/stripe/create-checkout-session
        const stripeReq = {
          locationID: locationSlug,
          campaignKey,
          initiationType: "owner",
          ownershipSource: "campaign",
          navigenVersion: "phase5",
          planCode: body?.planCode
        };

        return await createCampaignCheckoutSession(env, req, stripeReq, { "cache-control": "no-store" });
      }

      // --- Owner Campaigns: promote draft → active after Stripe checkout
      // POST /api/owner/campaigns/promote  body: { sessionId: "cs_..." }
      // Requires owner session; also verifies Stripe session is paid/complete.
      if (normPath === "/api/owner/campaigns/promote" && req.method === "POST") {
        const noStore = { "cache-control": "no-store", "Referrer-Policy": "no-referrer" };

        const sess = await requireOwnerSession(req, env);
        if (sess instanceof Response) return sess;
        const ulid = String(sess.ulid || "").trim();

        const body = await req.json().catch(() => ({})) as any;
        const cs = String(body?.sessionId || "").trim();
        if (!/^cs_(live|test)_/i.test(cs)) {
          return json({ error: { code: "invalid_request", message: "sessionId (cs_...) required" } }, 400, noStore);
        }

        const sk = String((env as any).STRIPE_SECRET_KEY || "").trim();
        if (!sk) return json({ error: { code: "misconfigured", message: "STRIPE_SECRET_KEY not set" } }, 500, noStore);

        const stripeUrl = `https://api.stripe.com/v1/checkout/sessions/${encodeURIComponent(cs)}?expand[]=payment_intent`;
        const r = await fetch(stripeUrl, { headers: { "Authorization": `Bearer ${sk}` } });
        const txt = await r.text();
        let out: any = null;
        try { out = JSON.parse(txt); } catch { out = null; }

        if (!r.ok || !out) {
          return json({ error: { code: "stripe_error", message: String(out?.error?.message || "Stripe session fetch failed") } }, 502, noStore);
        }

        const status = String(out?.status || "").toLowerCase();
        const payStatus = String(out?.payment_status || "").toLowerCase();
        if (status !== "complete" || payStatus !== "paid") {
          return json({ error: { code: "not_paid", message: "checkout not complete/paid" } }, 409, noStore);
        }

        const pi = out?.payment_intent;
        const meta = (pi && pi.metadata) ? pi.metadata : (out.metadata || {});
        const locationSlug = String(meta?.locationID || "").trim();
        const campaignKey = String(meta?.campaignKey || "").trim();

        if (!locationSlug || !campaignKey) {
          return json({ error: { code: "invalid_state", message: "missing metadata.locationID/campaignKey" } }, 500, noStore);
        }

        const resolved = await resolveUid(locationSlug, env).catch(() => null);
        if (!resolved || String(resolved).trim() !== ulid) {
          return new Response("Denied", { status: 401, headers: noStore });
        }

        const draftKey = `campaigns:draft:${ulid}`;
        const draft = await env.KV_STATUS.get(draftKey, { type: "json" }) as any;
        if (!draft) {
          return json({ error: { code: "not_found", message: "draft not found" } }, 404, noStore);
        }

        if (String(draft?.campaignKey || "").trim() !== campaignKey) {
          return json({ error: { code: "invalid_state", message: "draft campaignKey mismatch" } }, 409, noStore);
        }

        const paidPriceId = await fetchStripeCheckoutLineItemPriceId(sk, cs).catch(() => "");
        const paidPlan = paidPriceId ? PRICE_ID_TO_PLAN[paidPriceId] : null;
        if (!paidPlan) {
          return json({ error: { code: "invalid_state", message: "paid checkout session has no recognized Plan tier" } }, 409, noStore);
        }

        const promoted = await promoteCampaignDraftToActiveRows({
          req,
          env,
          ownerUlid: ulid,
          draft,
          locationSlug,
          campaignKey,
          stripeSessionId: cs,
          paidPlan,
          logTag: "owner_campaigns_promote"
        });

        if ("body" in promoted) {
          return json(promoted.body, promoted.status, noStore);
        }

        await env.KV_STATUS.delete(draftKey);

        return json({
          ok: true,
          ulid,
          campaignKey,
          campaignGroupKey: promoted.campaignGroupKey,
          includedCount: promoted.includedTargets.length
        }, 200, { "cache-control": "no-store" });
      }

      // --- Owner Campaigns: suspend/resume a campaign row or campaign group (KV-authoritative)
      // POST /api/owner/campaigns/suspend body: { campaignKey?: "<key>", campaignGroupKey?: "<group>", action: "suspend"|"resume" }
      if (normPath === "/api/owner/campaigns/suspend" && req.method === "POST") {
        const noStore = { "cache-control": "no-store", "Referrer-Policy": "no-referrer" };

        const sess = await requireOwnerSession(req, env);
        if (sess instanceof Response) return sess;
        const ulid = String(sess.ulid || "").trim();

        const body = await req.json().catch(() => ({})) as any;
        const campaignKey = String(body?.campaignKey || "").trim();
        const campaignGroupKey = String(body?.campaignGroupKey || "").trim();
        const action = String(body?.action || "suspend").trim().toLowerCase();

        if (!campaignKey && !campaignGroupKey) {
          return json({ error: { code: "invalid_request", message: "campaignKey or campaignGroupKey required" } }, 400, noStore);
        }
        if (action !== "suspend" && action !== "resume") {
          return json({ error: { code: "invalid_request", message: "action must be suspend|resume" } }, 400, noStore);
        }

        const applyToRows = async (targetUlid: string): Promise<boolean> => {
          const histKey = campaignsByUlidKey(targetUlid);
          const hist = await env.KV_STATUS.get(histKey, { type: "json" }) as any;
          const arr: any[] = Array.isArray(hist) ? hist : [];
          let changed = false;

          const next = arr.map((row: any) => {
            const sameKey = campaignKey && String(row?.campaignKey || "").trim() === campaignKey;
            const sameGroup = campaignGroupKey && String(row?.campaignGroupKey || "").trim() === campaignGroupKey;
            if (!sameKey && !sameGroup) return row;

            changed = true;
            const out = { ...row };
            if (action === "suspend") {
              out.statusOverride = "Suspended";
              out.suspendedAt = new Date().toISOString();
            } else {
              out.statusOverride = "";
              delete out.suspendedAt;
            }
            return out;
          });

          if (changed) {
            await env.KV_STATUS.put(histKey, JSON.stringify(next));
          }
          return changed;
        };

        if (campaignGroupKey) {
          const eligible = await eligibleLocationsForRequest(req, env, ulid);
          let affected = 0;
          for (const loc of eligible) {
            if (await applyToRows(loc.ulid)) affected += 1;
          }
          return json({ ok: true, ulid, campaignGroupKey, action, affected }, 200, noStore);
        }

        const changed = await applyToRows(ulid);
        if (!changed) {
          return json({ error: { code: "not_found", message: "campaign not found for this location" } }, 404, noStore);
        }

        return json({ ok: true, ulid, campaignKey, action }, 200, noStore);
      }

      // --- Owner Campaign Group: suspend/resume selected included locations only
      // POST /api/owner/campaigns/suspend-selected
      // body: { campaignGroupKey: "<group>", action: "suspend"|"resume", ulids: ["<ULID>", ...] }
      if (normPath === "/api/owner/campaigns/suspend-selected" && req.method === "POST") {
        const noStore = { "cache-control": "no-store", "Referrer-Policy": "no-referrer" };

        const sess = await requireOwnerSession(req, env);
        if (sess instanceof Response) return sess;

        const currentUlid = String(sess.ulid || "").trim();
        const body = await req.json().catch(() => ({})) as any;

        const campaignGroupKey = String(body?.campaignGroupKey || "").trim();
        const action = String(body?.action || "").trim().toLowerCase();
        const rawUlids = Array.isArray(body?.ulids) ? body.ulids : [];

        if (!campaignGroupKey) {
          return json({ error: { code: "invalid_request", message: "campaignGroupKey required" } }, 400, noStore);
        }
        if (action !== "suspend" && action !== "resume") {
          return json({ error: { code: "invalid_request", message: "action must be suspend|resume" } }, 400, noStore);
        }

        const eligible = await eligibleLocationsForRequest(req, env, currentUlid);
        const eligibleSet = new Set(eligible.map((x) => String(x.ulid || "").trim()));
        const targetUlids = Array.from(new Set(rawUlids.map((x: any) => String(x || "").trim()).filter(Boolean)))
          .filter((id) => eligibleSet.has(id));

        if (!targetUlids.length) {
          return json({ error: { code: "invalid_request", message: "no eligible selected locations" } }, 400, noStore);
        }

        let affected = 0;

        for (const targetUlid of targetUlids) {
          const histKey = campaignsByUlidKey(targetUlid);
          const histRaw = await env.KV_STATUS.get(histKey, { type: "json" }) as any;
          const arr: any[] = Array.isArray(histRaw) ? histRaw : [];

          let changed = false;
          const next = arr.map((row: any) => {
            if (String(row?.campaignGroupKey || "").trim() !== campaignGroupKey) return row;

            changed = true;
            const out = { ...row };
            if (action === "suspend") {
              out.statusOverride = "Suspended";
              out.suspendedAt = new Date().toISOString();
            } else {
              out.statusOverride = "";
              delete out.suspendedAt;
            }
            return out;
          });

          if (changed) {
            await env.KV_STATUS.put(histKey, JSON.stringify(next));
            affected += 1;
          }
        }

        return json(
          { ok: true, campaignGroupKey, action, affected, ulids: targetUlids },
          200,
          noStore
        );
      }
      
      // --- Owner session diag: /api/_diag/opsess (safe; no secrets)
      if (normPath === "/api/_diag/opsess" && req.method === "GET") {
        const cookieHdr = req.headers.get("Cookie") || "";
        const sid = readCookie(cookieHdr, "op_sess");

        const sessKey = sid ? `opsess:${sid}` : "";
        const sess = sid
          ? await env.KV_STATUS.get(sessKey, { type: "json" })
          : null;

        return json(
          {
            hasCookieHeader: !!cookieHdr,
            cookieHeaderLen: cookieHdr.length,
            hasOpSessCookie: !!sid,
            opSessLen: sid ? String(sid).length : 0,
            kvHit: !!sess,
            kvKey: sessKey ? `opsess:<redacted>` : "",
            ulid: (sess && typeof sess === "object") ? String((sess as any).ulid || "") : ""
          },
          200,
          { "cache-control": "no-store", "x-ng-worker": "navigen-api" }
        );
      }

      // --- Owner exchange from Stripe Checkout (Phase 5: sid → cookie session)
      if (normPath === "/owner/stripe-exchange" && req.method === "GET") {
        return await handleOwnerStripeExchange(req, env);
      }

      // --- Restore by PaymentIntent id (pi_...) for cross-device recovery
      if (normPath === "/owner/restore" && req.method === "GET") {
        const u = new URL(req.url);
        const pi = String(u.searchParams.get("pi") || "").trim();
        const nextRaw = String(u.searchParams.get("next") || "").trim();

        const noStoreHeaders = { "cache-control": "no-store", "Referrer-Policy": "no-referrer" };

        if (!pi || !/^pi_/i.test(pi)) return new Response("Denied", { status: 400, headers: noStoreHeaders });

        const isSafeNext = (p: string) =>
          p.startsWith("/") && !p.startsWith("//") && !p.includes("://") && !p.includes("\\");

        const next = (nextRaw && isSafeNext(nextRaw)) ? nextRaw : "";
        const jsonMode = u.searchParams.get("json") === "1" || /\bapplication\/json\b/i.test(String(req.headers.get("Accept") || ""));
        let redirectHint = "";

        const sk = String((env as any).STRIPE_SECRET_KEY || "").trim();
        if (!sk) return new Response("Misconfigured", { status: 500, headers: noStoreHeaders });

        // Find the Checkout Session by payment_intent
        const listUrl = `https://api.stripe.com/v1/checkout/sessions?payment_intent=${encodeURIComponent(pi)}&limit=1`;
        const rr = await fetch(listUrl, { method: "GET", headers: { "Authorization": `Bearer ${sk}` } });
        const txt = await rr.text();
        let out: any = null;
        try { out = JSON.parse(txt); } catch { out = null; }

        const sess = out?.data && Array.isArray(out.data) && out.data.length ? out.data[0] : null;
        if (!rr.ok || !sess) return new Response("Denied", { status: 403, headers: noStoreHeaders });

        const paymentStatus = String(sess?.payment_status || "").toLowerCase();
        const status = String(sess?.status || "").toLowerCase();
        if (paymentStatus !== "paid" || status !== "complete") {
          return new Response("Denied", { status: 403, headers: noStoreHeaders });
        }

        const meta = sess?.metadata || {};
        const target = await resolveTargetIdentity(env, {
          locationID: meta?.locationID,
          draftULID: meta?.draftULID,
          draftSessionId: meta?.draftSessionId
        }, { validateDraft: true });
        if (!target) return new Response("Denied", { status: 403, headers: noStoreHeaders });

        const ulid = target.ulid;
        const locationID = target.locationID;

        const ownKey = `ownership:${ulid}`;
        const ownership = await env.KV_STATUS.get(ownKey, { type: "json" }) as any;
        const exclusiveUntilIso = String(ownership?.exclusiveUntil || "").trim();
        const exclusiveUntil = exclusiveUntilIso ? new Date(exclusiveUntilIso) : null;
        if (!exclusiveUntil || Number.isNaN(exclusiveUntil.getTime()) || exclusiveUntil.getTime() <= Date.now()) {
          return new Response("Denied", { status: 403, headers: noStoreHeaders });
        }
        
        try {
          await persistPlanRecord(env, sk, String(sess?.id || "").trim(), pi, exclusiveUntil.toISOString(), {
            initiationType: meta?.initiationType,
            campaignPreset: meta?.campaignPreset
          });          
        } catch (e: any) {
          console.error("owner_restore: plan_persist_failed", { ulid, err: String(e?.message || e || "") });
        }        

        // Mint op_sess exactly like handleOwnerStripeExchange
        const sidBytes = new Uint8Array(18);
        (crypto as any).getRandomValues(sidBytes);
        const sessionId = bytesToB64url(sidBytes);

        const createdAt = new Date();
        const expiresAt = exclusiveUntil;
        const maxAge = Math.max(0, Math.floor((expiresAt.getTime() - createdAt.getTime()) / 1000));

        const sessKey = `opsess:${sessionId}`;
        const sessVal = { ver: 1, ulid, createdAt: createdAt.toISOString(), expiresAt: expiresAt.toISOString() };

        await env.KV_STATUS.put(sessKey, JSON.stringify(sessVal), { expirationTtl: Math.max(60, maxAge) });

        // Register to device (mint ng_dev if missing) so Owner Center works on this device
        let devSetCookie = "";
        try {
          let dev = readDeviceId(req);
          if (!dev) {
            const minted = mintDeviceId();
            dev = minted.dev;
            devSetCookie = minted.cookie;
          }

          if (dev) {
            await env.KV_STATUS.put(devSessKey(dev, ulid), sessionId, { expirationTtl: Math.max(60, maxAge) });
            const idxKey = devIndexKey(dev);
            const rawIdx = await env.KV_STATUS.get(idxKey, "text");
            let arr: string[] = [];
            try { arr = rawIdx ? JSON.parse(rawIdx) : []; } catch { arr = []; }
            if (!Array.isArray(arr)) arr = [];
            if (!arr.includes(ulid)) arr.unshift(ulid);
            arr = arr.slice(0, 24);
            await env.KV_STATUS.put(idxKey, JSON.stringify(arr), { expirationTtl: 60 * 60 * 24 * 366 });
          }
        } catch {}

        // If this checkout session funded a campaign, promote draft now and enrich redirect with campaign hint.
        // This avoids "sticky wrong" LPM badge rendering after redirect.
        redirectHint = await promoteCampaignDraftAndBuildRedirectHint(req, sess, ulid, env, "owner_restore");        
        
        const cookie = cookieSerialize("op_sess", sessionId, {
          Path: "/",
          HttpOnly: true,
          Secure: true,
          SameSite: "Lax",
          "Max-Age": maxAge
        });

        const redirectTarget = (() => {
          const base = next || `/dash/${encodeURIComponent(ulid)}`;
          if (!redirectHint) return base;

          const u = new URL(base, "https://navigen.io");
          if (!u.searchParams.get("ce")) {
            const parts = redirectHint.split("&");
            parts.forEach(kv => {
              const [k, v] = kv.split("=");
              if (k && v && !u.searchParams.get(k)) u.searchParams.set(k, decodeURIComponent(v));
              else if (k && !u.searchParams.get(k)) u.searchParams.set(k, "1");
            });
          }
          return u.pathname + u.search + u.hash;
        })();

        const headers = new Headers({ ...noStoreHeaders });
        headers.append("Set-Cookie", cookie);
        if (devSetCookie) headers.append("Set-Cookie", devSetCookie);

        console.info("owner_restore_success", { ulid, locationID, pi, sessionId });

        if (jsonMode) {
          headers.set("Content-Type", "application/json; charset=utf-8");
          return new Response(JSON.stringify({
            ok: true,
            ulid,
            locationID,
            redirectTo: redirectTarget
          }), { status: 200, headers });
        }

        headers.set("Location", redirectTarget);
        return new Response(null, { status: 302, headers });
      }

      // --- Owner session clear: /owner/clear-session
      // Clears the active op_sess cookie on this device (HttpOnly, so JS can't delete it).
      if (normPath === "/owner/clear-session" && req.method === "GET") {
        const u = new URL(req.url);
        const nextRaw = String(u.searchParams.get("next") || "").trim();

        const isSafeNext = (p: string) =>
          p.startsWith("/") && !p.startsWith("//") && !p.includes("://") && !p.includes("\\");

        const next = (nextRaw && isSafeNext(nextRaw)) ? nextRaw : "/";

        const noStoreHeaders = { "cache-control": "no-store", "Referrer-Policy": "no-referrer" };

        // Expire cookie. We do not need to delete opsess:<id> in KV; it expires naturally.
        const cookie = cookieSerialize("op_sess", "", {
          Path: "/",
          HttpOnly: true,
          Secure: true,
          SameSite: "Lax",
          "Max-Age": 0
        });

        return new Response(null, {
          status: 302,
          headers: {
            "Set-Cookie": cookie,
            "Location": next,
            ...noStoreHeaders
          }
        });
      }

      // --- Owner Center: switch active op_sess to a device-bound location
      if (normPath === "/owner/switch" && req.method === "GET") {
        const u = new URL(req.url);
        const ulid = String(u.searchParams.get("ulid") || "").trim();
        const nextRaw = String(u.searchParams.get("next") || "").trim();

        const noStoreHeaders = { "cache-control": "no-store", "Referrer-Policy": "no-referrer" };

        if (!ULID_RE.test(ulid)) return new Response("Denied", { status: 400, headers: noStoreHeaders });

        const isSafeNext = (p: string) =>
          p.startsWith("/") && !p.startsWith("//") && !p.includes("://") && !p.includes("\\");

        const next = (nextRaw && isSafeNext(nextRaw)) ? nextRaw : `/dash/${encodeURIComponent(ulid)}`;

        const dev = readDeviceId(req);
        if (!dev) return new Response("Denied", { status: 401, headers: noStoreHeaders });

        const sid = await env.KV_STATUS.get(devSessKey(dev, ulid), "text");
        if (!sid) return new Response("Denied", { status: 403, headers: noStoreHeaders });

        // Validate session still exists and is not expired
        const sessKey = `opsess:${sid}`;
        const sess = await env.KV_STATUS.get(sessKey, { type: "json" }) as OwnerSession | null;
        if (!sess || !sess.ulid) return new Response("Denied", { status: 403, headers: noStoreHeaders });

        const exp = new Date(String(sess.expiresAt || ""));
        if (Number.isNaN(exp.getTime()) || exp.getTime() <= Date.now()) {
          return new Response("Denied", { status: 401, headers: noStoreHeaders });
        }

        // Set cookie to the mapped session id
        const maxAge = Math.max(0, Math.floor((exp.getTime() - Date.now()) / 1000));
        const cookie = cookieSerialize("op_sess", sid, {
          Path: "/",
          HttpOnly: true,
          Secure: true,
          SameSite: "Lax",
          "Max-Age": maxAge
        });

        return new Response(null, {
          status: 302,
          headers: {
            "Set-Cookie": cookie,
            "Location": next,
            ...noStoreHeaders
          }
        });
      }

      // --- Stripe webhook: /api/stripe/webhook (Phase 1: ownership writer)
      if (normPath === "/api/stripe/webhook" && req.method === "POST") {
        return await handleStripeWebhook(req, env);
      }

      // --- QR image: /api/qr?locationID=...&c=...&fmt=svg|png&size=512
      if (pathname === "/api/qr" && req.method === "GET") {
        return await handleQr(req, env);
      }

      // --- Campaign summary (read-only): GET /api/campaign-summary?locationID=...&campaignKey=...
      if (pathname === "/api/campaign-summary" && req.method === "GET") {
        const u = new URL(req.url);
        const locationRaw = (u.searchParams.get("locationID") || "").trim();
        const campaignKeyRaw = (u.searchParams.get("campaignKey") || "").trim();

        if (!locationRaw || !campaignKeyRaw) {
          return json(
            { error: { code: "invalid_request", message: "locationID and campaignKey required" } },
            400,
            { "cache-control": "no-store" }
          );
        }

        const locULID = (await resolveUid(locationRaw, env)) || locationRaw;
        if (!locULID || !ULID_RE.test(locULID)) {
          return json(
            { error: { code: "invalid_request", message: "unknown location" } },
            400,
            { "cache-control": "no-store" }
          );
        }

        const rawRows = await env.KV_STATUS.get(campaignsByUlidKey(locULID), { type: "json" }) as any;
        const rows: any[] = Array.isArray(rawRows) ? rawRows : [];

        const nowMs = Date.now();
        const row = rows.find((r) => {
          if (!r) return false;
          if (String(r?.locationID || "").trim() !== locULID) return false;
          if (String(r?.campaignKey || "").trim() !== campaignKeyRaw) return false;

          const st = String(r?.statusOverride || r?.status || "").trim().toLowerCase();
          if (st !== "active") return false;

          const sMs = parseYmdUtcMs(String(r?.startDate || ""));
          const eMs = parseYmdUtcMs(String(r?.endDate || ""));
          if (!Number.isFinite(sMs) || !Number.isFinite(eMs)) return false;

          if (nowMs < sMs) return false;
          if (nowMs > (eMs + 24 * 60 * 60 * 1000 - 1)) return false;

          return true;
        });

        if (!row) {
          return json(
            { error: { code: "forbidden", message: "campaign not active" } },
            403,
            { "cache-control": "no-store" }
          );
        }

        const item = await getItemById(locULID, env).catch(() => null);
        const locationName = pickName(item?.locationName) || "";

        const dvRaw = (row?.campaignDiscountValue != null) ? row.campaignDiscountValue : null;
        const discountValue =
          (typeof dvRaw === "number") ? dvRaw :
          (typeof dvRaw === "string" && dvRaw.trim() && Number.isFinite(Number(dvRaw))) ? Number(dvRaw) :
          null;

        return json(
          {
            locationID: locationRaw,
            locationULID: locULID,
            locationName,
            campaignKey: String(row?.campaignKey || "").trim(),
            campaignName: String(row?.campaignName || "").trim(),
            offerType: String(row?.offerType || "").trim(),
            productName: String(row?.productName || "").trim(),
            startDate: String(row?.startDate || "").trim(),
            endDate: String(row?.endDate || "").trim(),
            eligibilityType: String(row?.eligibilityType || "").trim(),
            eligibilityNotes: String(row?.eligibilityNotes || "").trim(),
            discountKind: String(row?.discountKind || "").trim(),
            discountValue
          },
          200,
          { "cache-control": "no-store" }
        );
      }

      // --- Promotion QR URL: GET /api/promo-qr?locationID=... [&campaignKey=...]
      if (pathname === "/api/promo-qr" && req.method === "GET") {        const u = new URL(req.url);
        const locationRaw = (u.searchParams.get("locationID") || "").trim();
        const campaignKeyRaw = (u.searchParams.get("campaignKey") || "").trim(); // optional

        if (!locationRaw) {
          return json(
            { error: { code: "invalid_request", message: "locationID required" } },
            400
          );
        }

        // Resolve slug → canonical ULID (or accept ULID as-is)
        const locULID = (await resolveUid(locationRaw, env)) || locationRaw;
        if (!locULID) {
          return json(
            { error: { code: "invalid_request", message: "unknown location" } },
            400
          );
        }

        const siteOrigin = req.headers.get("Origin") || "https://navigen.io";

        // Resolve active campaign from KV (authoritative)
        const requestedKey = String(campaignKeyRaw || "").trim();

        // Load all active rows (effective status === active, in-window)
        const rawRows = await env.KV_STATUS.get(campaignsByUlidKey(locULID), { type: "json" }) as any;
        const rows: any[] = Array.isArray(rawRows) ? rawRows : [];

        const nowMs = Date.now();

        const isActiveRow = (r: any) => {
          if (!r) return false;
          if (String(r?.locationID || "").trim() !== locULID) return false;

          const st = String(r?.statusOverride || r?.status || "").trim().toLowerCase();
          if (st !== "active") return false;

          const sMs = parseYmdUtcMs(String(r?.startDate || ""));
          const eMs = parseYmdUtcMs(String(r?.endDate || ""));
          if (!Number.isFinite(sMs) || !Number.isFinite(eMs)) return false;

          if (nowMs < sMs) return false;
          if (nowMs > (eMs + 24 * 60 * 60 * 1000 - 1)) return false;

          return true;
        };

        const actives = rows.filter(isActiveRow);

        if (!actives.length) {
          return json({ error: { code: "forbidden", message: "campaign required" } }, 403);
        }

        // If caller specified campaignKey, use it only if it's active.
        if (requestedKey) {
          const hit = actives.find(r => String(r?.campaignKey || "").trim() === requestedKey);
          if (!hit) {
            return json({ error: { code: "forbidden", message: "campaign not active" } }, 403);
          }
          // continue with activeRow = hit
          var activeRow = hit;
        } else {
          // No campaignKey specified:
          // - if exactly one active, proceed
          // - if multiple, force selection
          if (actives.length !== 1) {
            const items = actives.map(r => {
              const dvRaw = (r?.campaignDiscountValue != null) ? r.campaignDiscountValue : null;
              const discountValue =
                (typeof dvRaw === "number") ? dvRaw :
                (typeof dvRaw === "string" && dvRaw.trim() && Number.isFinite(Number(dvRaw))) ? Number(dvRaw) :
                null;

              return {
                campaignKey: String(r?.campaignKey || "").trim(),
                campaignName: String(r?.campaignName || "").trim(),
                productName: String(r?.productName || "").trim(),
                startDate: String(r?.startDate || "").trim(),
                endDate: String(r?.endDate || "").trim(),
                eligibilityType: String(r?.eligibilityType || "").trim(),
                eligibilityNotes: String(r?.eligibilityNotes || "").trim(),
                discountKind: String(r?.discountKind || "").trim(),
                discountValue
              };
            });
            return json({ error: { code: "multiple_active", message: "multiple active campaigns" }, items }, 409, { "cache-control": "no-store" });
          }
          var activeRow = actives[0];
        }
        if (!activeRow) {
          return json(
            { error: { code: "forbidden", message: "campaign required" } },
            403
          );
        }

        if (normCampaignPreset(activeRow?.campaignPreset) === "visibility") {
          return json(
            { error: { code: "campaign_preset_visibility", message: "Promotion is turned off for this campaign." } },
            403,
            { "cache-control": "no-store" }
          );
        }

        const chosenKey = String(activeRow.campaignKey || "").trim();
        if (!chosenKey) {
          return json(
            { error: { code: "forbidden", message: "campaign required" } },
            403
          );
        }

        // Create redeem token for this location + campaign
        const token = await createRedeemToken(env.KV_STATS, locULID, chosenKey);

        // Record that a promotion QR was shown (ARMED) for this campaign/location
        await logQrArmed(env.KV_STATS, env, locULID, req, chosenKey);

        // Build Promotion QR URL using the original locationRaw (slug), not ULID
        const qrBase = "https://navigen-api.4naama.workers.dev"; // temporary hotfix: bypass the site redeem entry until /out/qr-redeem serves pending-v2 live
        const qrUrlObj = new URL(`/out/qr-redeem/${encodeURIComponent(locationRaw)}`, qrBase);
        qrUrlObj.searchParams.set("camp", chosenKey);
        qrUrlObj.searchParams.set("rt", token);

        const dvRaw = (activeRow.campaignDiscountValue != null) ? activeRow.campaignDiscountValue : null;
        const discountValue =
          (typeof dvRaw === "number") ? dvRaw :
          (typeof dvRaw === "string" && dvRaw.trim() && Number.isFinite(Number(dvRaw))) ? Number(dvRaw) :
          null;

        return json({
          qrUrl: qrUrlObj.toString(),
          campaignName: String(activeRow.campaignName || "").trim(),
          offerType: String(activeRow.offerType || "").trim(),
          productName: String(activeRow.productName || "").trim(),
          startDate: String(activeRow.startDate || "").trim(),
          endDate: String(activeRow.endDate || "").trim(),
          eligibilityType: String(activeRow.eligibilityType || "").trim(),
          eligibilityNotes: String(activeRow.eligibilityNotes || "").trim(),
          discountKind: String(activeRow.discountKind || "").trim(),
          discountValue
        }, 200);
      }

      // --- Admin purge (one-off): POST /api/admin/purge-legacy
      // Merges stats:<loc>:<day>:<event_with_underscores> → hyphen, or burns legacy keys entirely.
      if (pathname === "/api/admin/purge-legacy" && req.method === "POST") {
        const auth = req.headers.get("Authorization") || "";
        if (!auth.startsWith("Bearer ")) {
          return json({ error:{ code:"unauthorized", message:"Bearer token required" } }, 401);
        }
        const token = auth.slice(7).trim();
        const expected = String(env.JWT_SECRET || "").trim();
        if (!expected) {
          // Misconfiguration must be explicit; otherwise you chase ghosts.
          return json({ error:{ code:"misconfigured", message:"JWT_SECRET not set in runtime env" } }, 500, { "cache-control": "no-store" });
        }
        if (!token || token.trim() !== expected) {
          return json({ error:{ code:"forbidden", message:"Bad token" } }, 403, { "cache-control": "no-store" });
        }

        const body = await req.json().catch(() => ({}));
        const mode = (body?.mode || "merge").toString(); // 'merge' or 'burn'

        let cursor: string|undefined = undefined;
        let migrated = 0, removed = 0;

        do {
          const page = await env.KV_STATS.list({ prefix: "stats:", cursor });
          for (const k of page.keys) {
            // keys look like: stats:<loc>:YYYY-MM-DD:<event>
            const name = k.name;
            const parts = name.split(":");
            if (parts.length !== 4) continue;

            const ev = parts[3];
            if (!ev.includes("_")) continue; // only legacy

            if (mode === "merge") {
              const n = parseInt((await env.KV_STATS.get(name)) || "0", 10) || 0;
              if (!n) { await env.KV_STATS.delete(name); removed++; continue; } // drop empty
              const hyphen = ev.replaceAll("_","-");
              const target = `stats:${parts[1]}:${parts[2]}:${hyphen}`;
              const cur = parseInt((await env.KV_STATS.get(target)) || "0", 10) || 0;
              await env.KV_STATS.put(target, String(cur + n), { expirationTtl: 60*60*24*366 });
              migrated++;
            }
            // 'burn' deletes legacy without merging
            await env.KV_STATS.delete(name);
            removed++;
          }
          cursor = page.cursor || undefined;
        } while (cursor);

        return json({ ok:true, mode, migrated, removed }, 200);
      }

      // --- Admin backfill: POST /api/admin/backfill-slug-stats
      // Moves stats:<slug>:YYYY-MM-DD:<event> → stats:<ULID>:YYYY-MM-DD:<event> using KV_ALIASES.
      if (pathname === "/api/admin/backfill-slug-stats" && req.method === "POST") {
        const auth = req.headers.get("Authorization") || "";
        if (!auth.startsWith("Bearer ")) {
          return json({ error:{ code:"unauthorized", message:"Bearer token required" } }, 401);
        }
        const token = auth.slice(7).trim();
        const expected = String(env.JWT_SECRET || "").trim();
        if (!expected) {
          // Misconfiguration must be explicit; otherwise you chase ghosts.
          return json({ error:{ code:"misconfigured", message:"JWT_SECRET not set in runtime env" } }, 500, { "cache-control": "no-store" });
        }
        if (!token || token.trim() !== expected) {
          return json({ error:{ code:"forbidden", message:"Bad token" } }, 403, { "cache-control": "no-store" });
        }

        let cursor: string|undefined = undefined;
        let moved = 0, removed = 0, skipped = 0;

        do {
          const page = await env.KV_STATS.list({ prefix: "stats:", cursor });
          for (const k of page.keys) {
            // shape: stats:<id>:YYYY-MM-DD:<event>
            const parts = k.name.split(":");
            if (parts.length !== 4) continue;

            const id = parts[1];
            const day = parts[2];
            const ev  = parts[3];

            // skip if already ULID
            if (/^[0-9A-HJKMNP-TV-Z]{26}$/.test(id)) { skipped++; continue; }

            // try alias → ULID
            const mapped = await env.KV_ALIASES.get(aliasKey(id), "json");
            const ulid = (typeof mapped === "string" ? mapped : mapped?.locationID) || "";
            if (!ulid || !/^[0-9A-HJKMNP-TV-Z]{26}$/.test(ulid)) { skipped++; continue; }

            const srcVal = parseInt((await env.KV_STATS.get(k.name)) || "0", 10) || 0;
            if (!srcVal) { await env.KV_STATS.delete(k.name); removed++; continue; }

            const dstKey = `stats:${ulid}:${day}:${ev.replaceAll("_","-")}`; // normalize event
            const cur = parseInt((await env.KV_STATS.get(dstKey)) || "0", 10) || 0;
            await env.KV_STATS.put(dstKey, String(cur + srcVal), { expirationTtl: 60*60*24*366 });
            await env.KV_STATS.delete(k.name);
            moved++;
          }
          cursor = page.cursor || undefined;
        } while (cursor);

        return json({ ok:true, moved, removed, skipped }, 200);
      }
                
      // --- Admin seed: POST /api/admin/seed-alias-ulids
      // Generate deterministic ULIDs for all aliases in profiles.json and write KV_ALIASES.
      if (pathname === "/api/admin/seed-alias-ulids" && req.method === "POST") {
        const auth = req.headers.get("Authorization") || "";
        if (!auth.startsWith("Bearer ")) {
          return json({ error:{ code:"unauthorized", message:"Bearer token required" } }, 401);
        }
        const token = auth.slice(7).trim();
        const expected = String(env.JWT_SECRET || "").trim();
        if (!expected) {
          // Misconfiguration must be explicit; otherwise you chase ghosts.
          return json({ error:{ code:"misconfigured", message:"JWT_SECRET not set in runtime env" } }, 500, { "cache-control": "no-store" });
        }
        if (!token || token.trim() !== expected) {
          return json({ error:{ code:"forbidden", message:"Bad token" } }, 403, { "cache-control": "no-store" });
        }

        // Load profiles.json from caller origin (keeps staging/prod safe)
        const base = req.headers.get("Origin") || "https://navigen.io";
        const src  = new URL("/data/profiles.json", base).toString();
        const resp = await fetch(src, { cf: { cacheTtl: 60, cacheEverything: true }, headers: { "Accept": "application/json" } });
        if (!resp.ok) return json({ error:{ code:"upstream", message:"profiles.json not reachable" } }, 502);
        const data: any = await resp.json();

        // Normalize locations list: supports array or object map
        const list: Array<{locationID:string}> =
          Array.isArray(data?.locations) ? data.locations :
          (data?.locations && typeof data.locations === "object")
            ? Object.values(data.locations) as any[] : [];

        // Collect aliases (anything not already a 26-char ULID)
        const aliases: string[] = list
          .map(x => String(x?.locationID || "").trim())
          .filter(id => id && !/^[0-9A-HJKMNP-TV-Z]{26}$/.test(id));

        // Small helpers local to this request (no globals)
        const B32 = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
        const toBase32 = (bytes: Uint8Array) => {
          let bits = 0, val = 0, out = "";
          for (const b of bytes) {
            val = (val << 8) | b; bits += 8;
            while (bits >= 5) { bits -= 5; out += B32[(val >>> bits) & 31]; val &= (1 << bits) - 1; }
          }
          if (bits > 0) out += B32[(val << (5 - bits)) & 31];
          return out;
        };
        const deterministicUlid = async (alias: string) => {
          // Fixed timestamp keeps outputs stable across runs.
          const t = new Uint8Array(8);
          new DataView(t.buffer).setBigUint64(0, 1735689600000n); // 2025-01-01T00:00:00.000Z
          const time48 = t.slice(2); // last 6 bytes

          const enc = new TextEncoder().encode(alias);
          const hashBuf = await crypto.subtle.digest("SHA-256", enc); // Web Crypto at edge
          const h = new Uint8Array(hashBuf).slice(0, 10); // 80 bits

          const bytes = new Uint8Array(16);
          bytes.set(time48, 0); bytes.set(h, 6);

          let b32 = toBase32(bytes);
          if (b32.length < 26) b32 = b32.padEnd(26, "0");
          if (b32.length > 26) b32 = b32.slice(0, 26);
          return b32;
        };

        let wrote = 0, skipped = 0;
        for (const alias of aliases) {
          try {
            const ulid = await deterministicUlid(alias);
            await env.KV_ALIASES.put(`alias:${alias}`, JSON.stringify({ locationID: ulid }));
            wrote++;
          } catch { skipped++; }
        }

        return json({ ok:true, wrote, skipped, total: aliases.length }, 200);
      }

      // --- Admin read (one-off): GET /api/admin/ownership?locationID=.
      // Returns raw ownership:<ULID> record + computed ownedNow/exclusiveUntil.
      // Auth: Bearer <JWT_SECRET> (same pattern as other admin endpoints).
      if (pathname === "/api/admin/ownership" && req.method === "GET") {
        const auth = req.headers.get("Authorization") || "";
        if (!auth.startsWith("Bearer ")) {
          return json({ error:{ code:"unauthorized", message:"Bearer token required" } }, 401, { "cache-control":"no-store" });
        }
        const token = auth.slice(7).trim();
        const expected = String(env.JWT_SECRET || "").trim();
        if (!expected) {
          return json({ error:{ code:"misconfigured", message:"JWT_SECRET not set in runtime env" } }, 500, { "cache-control":"no-store" });
        }
        if (!token || token !== expected) {
          return json({ error:{ code:"forbidden", message:"Bad token" } }, 403, { "cache-control":"no-store" });
        }

        const u = new URL(req.url);
        const idRaw = String(u.searchParams.get("locationID") || "").trim();
        if (!idRaw) {
          return json({ error:{ code:"invalid_request", message:"locationID required" } }, 400, { "cache-control":"no-store" });
        }

        const ulid = ULID_RE.test(idRaw) ? idRaw : ((await resolveUid(idRaw, env)) || "");
        if (!ulid) {
          return json({ error:{ code:"invalid_request", message:"unknown locationID" } }, 404, { "cache-control":"no-store" });
        }

        const ownKey = `ownership:${ulid}`;
        const rec = await env.KV_STATUS.get(ownKey, { type: "json" }) as any;

        const exclusiveUntilIso = String(rec?.exclusiveUntil || "").trim();
        const exclusiveUntil = exclusiveUntilIso ? new Date(exclusiveUntilIso) : null;
        const ownedNow = !!exclusiveUntil && !Number.isNaN(exclusiveUntil.getTime()) && exclusiveUntil.getTime() > Date.now();

        return json({
          ulid,
          key: ownKey,
          ownedNow,
          exclusiveUntil: exclusiveUntilIso || "",
          source: String(rec?.source || "").trim(),
          lastEventId: String(rec?.lastEventId || "").trim(),
          updatedAt: String(rec?.updatedAt || "").trim(),
          state: String(rec?.state || "").trim(),
          uid: String(rec?.uid || "").trim(),
          raw: rec || null
        }, 200, { "cache-control":"no-store" });
      }

      // --- Admin seed: POST /api/admin/seed-campaigns
      // Seeds KV_STATUS campaigns:byUlid:<ULID> from a batch of campaign rows (preseed step).
      // Auth: Bearer <JWT_SECRET> (same pattern as other admin endpoints).
      if (pathname === "/api/admin/seed-campaigns" && req.method === "POST") {
        const auth = req.headers.get("Authorization") || "";
        if (!auth.startsWith("Bearer ")) {
          return json({ error:{ code:"unauthorized", message:"Bearer token required" } }, 401);
        }
        const token = auth.slice(7).trim();
        const expected = String(env.JWT_SECRET || "").trim();
        if (!expected) {
          return json({ error:{ code:"misconfigured", message:"JWT_SECRET not set in runtime env" } }, 500, { "cache-control": "no-store" });
        }
        if (!token || token.trim() !== expected) {
          return json({ error:{ code:"forbidden", message:"Bad token" } }, 403, { "cache-control": "no-store" });
        }

        const body = await req.json().catch(() => null) as any;
        const rowsRaw: any[] =
          Array.isArray(body) ? body :
          Array.isArray(body?.rows) ? body.rows :
          Array.isArray(body?.campaigns) ? body.campaigns : [];

        if (!Array.isArray(rowsRaw) || !rowsRaw.length) {
          return json({ error:{ code:"invalid_request", message:"rows[] required" } }, 400);
        }

        // Group by ULID after resolving slug/alias where needed.
        const byUlid = new Map<string, CampaignRow[]>();
        let total = 0, wrote = 0, skipped = 0, unresolved = 0;

        for (const r of rowsRaw) {
          total++;
          try {
            const locIn = String(r?.locationID || "").trim();
            if (!locIn) { skipped++; continue; }

            const locResolved = ULID_RE.test(locIn) ? locIn : ((await resolveUid(locIn, env)) || "");
            if (!locResolved || !ULID_RE.test(locResolved)) { unresolved++; continue; }

            const ulid = locResolved;

            // Normalize campaign dates to YYYY-MM-DD.
            // campaigns.json may store Date strings (e.g. "Sun Nov 30 2025 ..."); KV requires YYYY-MM-DD.
            const normYmd = (v: any): string => {
              const s = String(v || "").trim();
              if (!s) return "";
              if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;

              const d = new Date(s);
              if (Number.isNaN(d.getTime())) return "";

              // Shift forward 12h to avoid off-by-one when local midnight is parsed across timezones.
              d.setHours(d.getHours() + 12);
              return d.toISOString().slice(0, 10);
            };

            const startDate = normYmd(r?.startDate);
            const endDate   = normYmd(r?.endDate);

            if (!startDate || !endDate) { skipped++; continue; }

            const row: any = {
              locationID: ulid, // canonical ULID (existing contract)
              locationULID: ulid,
              locationSlug: locIn, // original input (slug) from campaigns.json
              campaignKey: String(r?.campaignKey || "").trim(),
              campaignName: typeof r?.campaignName === "string" ? r.campaignName : undefined,
              sectorKey: typeof r?.sectorKey === "string" ? r.sectorKey : undefined,
              brandKey: typeof r?.brandKey === "string" ? r.brandKey : undefined,
              context: typeof r?.context === "string" ? r.context : undefined,

              startDate,
              endDate,
              status: String(r?.status || "").trim() || "Draft",
              statusOverride: (r?.statusOverride != null) ? String(r.statusOverride).trim() : undefined,

              campaignType: (r?.campaignType != null) ? String(r.campaignType).trim() : undefined,
              targetChannels: r?.targetChannels,
              offerType: (r?.offerType != null) ? String(r.offerType).trim() : undefined,
              productName: (r?.productName != null) ? String(r.productName).trim() : undefined,
              discountKind: (r?.discountKind != null) ? String(r.discountKind).trim() : undefined,
              campaignDiscountValue: (r?.campaignDiscountValue != null) ? r.campaignDiscountValue : undefined,
              eligibilityType: (r?.eligibilityType != null) ? String(r.eligibilityType).trim() : undefined,
              eligibilityNotes: (r?.eligibilityNotes != null) ? String(r.eligibilityNotes).trim() : undefined,

              utmSource: (r?.utmSource != null) ? String(r.utmSource).trim() : undefined,
              utmMedium: (r?.utmMedium != null) ? String(r.utmMedium).trim() : undefined,
              utmCampaign: (r?.utmCampaign != null) ? String(r.utmCampaign).trim() : undefined,

              notes: (r?.notes != null) ? String(r.notes).trim() : undefined
            };

            if (!row.campaignKey) { skipped++; continue; }

            const arr = byUlid.get(ulid) || [];
            arr.push(row);
            byUlid.set(ulid, arr);

          } catch {
            skipped++;
          }
        }

        for (const [ulid, arr] of byUlid.entries()) {
          try {
            await env.KV_STATUS.put(campaignsByUlidKey(ulid), JSON.stringify(arr));
            wrote++;
          } catch {
            // keep going; seed should be best-effort
          }
        }

        return json({ ok: true, total, wrote, skipped, unresolved }, 200);
        }

      // (removed) /api/admin/mint-owner-link — temporary Phase 2 test endpoint

        // (removed) leftover mint-owner-link body (fully deleted)

      // GET /api/stats?locationID=.
      // Phase 3: owner session required; requested location must match the session ULID.
      if (url.pathname === "/api/stats" && req.method === "GET") {
        // Allow Example Locations without a session (real stats; no synthetic data).
        // For all non-example locations, require an owner session (fail closed).
        let auth: { ulid: string } | null = null;

        const locRaw = (url.searchParams.get("locationID") || "").trim();
        const locResolved = (await resolveUid(locRaw, env)) || locRaw;
        const loc = String(locResolved || "").trim();

        let isExample = false;
        try {
          // Load profiles.json once and check the example flag for this location.
          const base = req.headers.get("Origin") || "https://navigen.io";
          const src = new URL("/data/profiles.json", base).toString();
          const resp = await fetch(src, { cf: { cacheTtl: 60, cacheEverything: true }, headers: { "Accept": "application/json" } });
          if (resp.ok) {
            const data: any = await resp.json().catch(() => null);
            const locs: any[] = Array.isArray(data?.locations)
              ? data.locations
              : (data?.locations && typeof data.locations === "object")
                ? Object.values(data.locations)
                : [];

            const rec = locs.find(r => String(r?.locationID || "").trim() === locRaw || String(r?.ID || r?.id || "").trim() === locRaw || String(r?.ID || r?.id || "").trim() === loc);
            const v = rec?.exampleLocation ?? rec?.isExample ?? rec?.example ?? rec?.exampleDash ?? rec?.flags?.example;
            isExample = (v === true || v === 1 || String(v || "").toLowerCase() === "true" || String(v || "").toLowerCase() === "yes");
          }
        } catch {
          isExample = false; // fail closed
        }

        if (!isExample) {
          const a = await requireOwnerSession(req, env);
          if (a instanceof Response) return a;
          auth = a;
        }
        if (auth instanceof Response) return auth;

        // locRaw resolved above

        // locResolved resolved above

        // loc resolved above

        if (!loc || !/^[0-9A-HJKMNP-TV-Z]{26}$/i.test(loc)) {
          return json({ error: { code: "invalid_request", message: "locationID, from, to required (YYYY-MM-DD)" } }, 400);
        }

        // Enforce single-ULID session binding
        if (auth && loc !== auth.ulid) {
          return new Response("Denied", {
            status: 403,
            headers: { "cache-control": "no-store", "Referrer-Policy": "no-referrer" }
          });
        }

        // Enforce campaign entitlement (Dash access gate)
        // Example locations must bypass campaign entitlement so Example Dashboards always load.
        if (!isExample) {
          const camp = await campaignEntitlementForUlid(env, loc);
          if (!camp.entitled) {
            return new Response("Campaign required", {
              status: 403,
              headers: { "cache-control": "no-store", "Referrer-Policy": "no-referrer" }
            });
          }
        }

        const from = (url.searchParams.get("from") || "").trim();
        const to = (url.searchParams.get("to") || "").trim();
        const tz = (url.searchParams.get("tz") || "").trim() || undefined;

        if (!loc || !/^\d{4}-\d{2}-\d{2}$/.test(from) || !/^\d{4}-\d{2}-\d{2}$/.test(to)) {
          return json({ error: { code: "invalid_request", message: "locationID, from, to required (YYYY-MM-DD)" } }, 400);
        }

        const prefix = `stats:${loc}:`;
        const days: Record<string, Partial<Record<EventKey, number>>> = {};
        let cursor: string | undefined = undefined;

        let ratedSum = 0;
        let ratingScoreSum = 0;

        const allowed = new Set<string>(EVENT_ORDER as readonly string[]);

        do {
          const page = await env.KV_STATS.list({ prefix, cursor });
          for (const k of page.keys) {
            const name = k.name;
            const parts = name.split(":");
            if (parts.length !== 4) continue;

            const day = parts[2];
            if (day < from || day > to) continue;

            const rawEv = (parts[3] as string).replaceAll("_", "-");

            if (rawEv === "rating-score") {
              const sv = parseInt((await env.KV_STATS.get(name)) || "0", 10) || 0;
              ratingScoreSum += sv;
              continue;
            }

            if (!allowed.has(rawEv)) continue;
            const ev = rawEv as EventKey;

            const n = parseInt((await env.KV_STATS.get(name)) || "0", 10) || 0;
            if (!days[day]) days[day] = {};
            days[day][ev] = (days[day][ev] || 0) + n;

            if (ev === "rating") ratedSum += n;
          }
          cursor = page.cursor || undefined;
        } while (cursor);

        const ratingAvg = ratedSum > 0 ? ratingScoreSum / ratedSum : 0;

        const siteOrigin =
          req.headers.get("Origin") || "https://navigen.io";

        // --- Build QR Info (per-scan logs) and Campaign aggregates --- //
        const qrInfo: any[] = [];
        const campaignsAgg: Record<string, {
          campaignKey: string;
          scans: number;
          redemptions: number;
          invalids: number;
          armed: number;                 // how many times a promotion QR was shown (ARMED)
          uniqueVisitors: Set<string>;
          repeatVisitors: Set<string>;
          uniqueRedeemers: Set<string>;
          repeatRedeemers: Set<string>;
          langs: Set<string>;
          countries: Set<string>;
        }> = {};

        // load campaigns once per stats call
        const allCampaigns = await env.KV_STATUS.get(campaignsByUlidKey(loc), { type: "json" }) as any;
        const allCampaignRows: CampaignRow[] = Array.isArray(allCampaigns) ? allCampaigns : [];

        // QR logs live under qrlog:<loc>:<day>:<scanId>
        const qrPrefix = `qrlog:${loc}:`;
        let qrCursor: string | undefined = undefined;

        do {
          const page = await env.KV_STATS.list({ prefix: qrPrefix, cursor: qrCursor });
          for (const k of page.keys) {
            const name = k.name;
            const parts = name.split(":"); // ['qrlog', '<loc>', '<day>', '<scanId>']
            if (parts.length !== 4) continue;

            const dayKey = parts[2];
            if (dayKey < from || dayKey > to) continue;

            const raw = await env.KV_STATS.get(name, "text");
            if (!raw) continue;

            let entry: QrLogEntry | null = null;
            try {
              entry = JSON.parse(raw) as QrLogEntry;
            } catch {
              entry = null;
            }
            if (!entry || entry.locationID !== loc) continue;

            const scanId = parts[3];

            // Push into qrInfo array (shape aligned with dash expectations)
            // Build QR Info row
            qrInfo.push({
              time: entry.time,
              source: entry.source || "",
              // Location: use physical scanner country code (CF country), not the location ULID
              location: entry.city
                ? `${entry.city}, ${entry.country || ''}`.trim().replace(/,\s*$/, '')
                : (entry.country || ""),
              // Device/Browser: keep UA here; frontend will bucketize into Device + Browser
              device: entry.ua || "",
              browser: entry.ua || "",
              lang: entry.lang || "",
              scanId,
              visitor: entry.visitor || "",
              campaign: entry.campaignKey || "",
              signal: entry.signal || "scan"
            });

            // Aggregate by campaignKey for Campaigns view
            const cKey = entry.campaignKey || "";
            const bucketKey = cKey || "_no_campaign";

            if (!campaignsAgg[bucketKey]) {
              campaignsAgg[bucketKey] = {
                campaignKey: cKey,
                scans: 0,
                redemptions: 0,
                invalids: 0,
                armed: 0,                         // promo QR shown counter
                uniqueVisitors: new Set<string>(),
                repeatVisitors: new Set<string>(),
                uniqueRedeemers: new Set<string>(),
                repeatRedeemers: new Set<string>(),
                langs: new Set<string>(),
                countries: new Set<string>()
              };
            }

            const agg = campaignsAgg[bucketKey];

            // Scans: only count entries with signal="scan"
            if (entry.signal === "scan") {
              agg.scans += 1;
            }

            // Redemptions: only explicit "redeem" signals count as true redemptions.
            if (entry.signal === "redeem") {
              agg.redemptions += 1;
            }

            // Invalid attempts (expired/used/invalid tokens)
            if (entry.signal === "invalid") {
              agg.invalids += 1;
            }

            // Promo QR shown (ARMED): track how many times a promotion QR was displayed
            if (entry.signal === "armed") {
              agg.armed += 1;
            }

            // Visitor identity (for now): derive from UA + country if visitor field is empty
            const visitorKey = entry.visitor && entry.visitor.trim()
              ? entry.visitor.trim()
              : `${entry.ua || ""}|${entry.country || ""}`;

            if (visitorKey) {
              // All visitors (scan + redeem + invalid)
              if (agg.uniqueVisitors.has(visitorKey)) {
                agg.repeatVisitors.add(visitorKey);
              } else {
                agg.uniqueVisitors.add(visitorKey);
              }

              // Redeemers: only consider entries with signal="redeem"
              if (entry.signal === "redeem") {
                if (agg.uniqueRedeemers.has(visitorKey)) {
                  agg.repeatRedeemers.add(visitorKey);
                } else {
                  agg.uniqueRedeemers.add(visitorKey);
                }
              }
            }

            // Aggregate primary language and scanner country
            if (entry.lang) {
              const primaryLang = String(entry.lang).split(",")[0].trim();
              if (primaryLang) agg.langs.add(primaryLang);
            }
            if (entry.country) {
              agg.countries.add(entry.country);
            }

          }
          qrCursor = page.cursor || undefined;
        } while (qrCursor);

        // Sort QR Info rows by time (newest first)
        qrInfo.sort((a, b) => {
          const ta = String(a.time || '');
          const tb = String(b.time || '');
          if (ta < tb) return 1;   // reverse comparison for newest-first
          if (ta > tb) return -1;
          return 0;
        });

        // Serialize campaignsAgg into a simple array
        const campaignAggValues = Object.values(campaignsAgg);

        // Aggregate promo QR + redeem metrics across all campaigns for QA tagging.
        let totalArmed = 0;
        let totalRedeems = 0;
        let totalInvalid = 0;
        for (const agg of campaignAggValues) {
          if ((agg.campaignKey || "").trim() === "") continue; // ignore "_no_campaign"
          totalArmed += agg.armed;
          totalRedeems += agg.redemptions;
          totalInvalid += agg.invalids;
        }

        const campaigns = campaignAggValues
          // hide "_no_campaign" bucket (scans without a campaignKey)
          .filter(agg => (agg.campaignKey || "").trim() !== "")
          .map((agg) => {
            const key = agg.campaignKey;
            const meta = allCampaignRows.find(c => String(c.locationID || "").trim() === loc && String(c.campaignKey || "").trim() === key) || null;

            const uniqueCount = agg.uniqueVisitors.size;
            const repeatCount = agg.repeatVisitors.size;
            const uniqueRedeemerCount = agg.uniqueRedeemers.size;
            const repeatRedeemerCount = agg.repeatRedeemers.size;

            // Period: prefer campaign start/end if available, otherwise stats window
            const campaignStart = meta ? String((meta as any).startDate || "").trim() : "";
            const campaignEnd   = meta ? String((meta as any).endDate || "").trim() : "";
            const periodLabel = (campaignStart && campaignEnd)
              ? `${campaignStart} → ${campaignEnd}`
              : `${from} → ${to}`;

            return {
              // Campaign ID + Name + Brand for dashboard
              campaign: key || "",
              campaignName: meta ? (String((meta as any).campaignName || "").trim()) : "",
              brand: meta ? (String((meta as any).brandKey || "").trim()) : "",
              target: meta ? (String((meta as any).context || "").trim()) : "",
              period: periodLabel,
              armed: agg.armed,                     // Promo QR shown (ARMED)
              scans: agg.scans,
              redemptions: agg.redemptions,
              invalids: agg.invalids,
              uniqueVisitors: uniqueCount,
              repeatVisitors: repeatCount,
              uniqueRedeemers: uniqueRedeemerCount,
              repeatRedeemers: repeatRedeemerCount,
              locations: agg.countries.size
            };
          });

        // Silent QA auto-tagging per location (internal only: admin dashboards, monitoring).
        try {
          const hasPromoActivity = totalArmed > 0 || totalRedeems > 0 || totalInvalid > 0;
          if (hasPromoActivity) {
            // Sum confirmation metrics from daily buckets
            let cashierConfs = 0;
            let customerConfs = 0;
            for (const dayKey of Object.keys(days)) {
              const bucket: any = (days as any)[dayKey] || {};
              const cashierVal = Number(bucket["redeem-confirmation-cashier"] ?? bucket["redeem_confirmation_cashier"] ?? 0);
              const customerVal = Number(bucket["redeem-confirmation-customer"] ?? bucket["redeem_confirmation_customer"] ?? 0);
              if (cashierVal) cashierConfs += cashierVal;
              if (customerVal) customerConfs += customerVal;
            }

            const totalRedeemAttempts = totalRedeems + totalInvalid;
            const complianceRatio = totalArmed > 0 ? (totalRedeems / totalArmed) : null;
            const invalidRatio = totalRedeemAttempts > 0 ? (totalInvalid / totalRedeemAttempts) : 0;
            const cashierCoverage = totalRedeems > 0 ? (cashierConfs / totalRedeems) : null;
            const customerCoverage = totalArmed > 0 ? (customerConfs / totalArmed) : null;

            const flags: string[] = [];

            if (complianceRatio !== null && complianceRatio < 0.7) {
              flags.push("low-scan-discipline");
            }
            if (invalidRatio > 0.10 && totalInvalid >= 3) {
              flags.push("high-invalid-attempts");
            }
            if (cashierCoverage !== null && cashierCoverage < 0.8) {
              flags.push("low-cashier-coverage");
            }
            if (customerCoverage !== null && totalArmed >= 10 && customerCoverage < 0.5) {
              flags.push("low-customer-confirmation");
            }

            if (!flags.length) {
              flags.push("qa-ok");
            }

            // Fire-and-forget: do not delay the stats response.
            ctx.waitUntil(writeQaFlags(env, loc, flags));
          }
        } catch {
          // tagging errors must never break stats
        }

        return json(
          {
            locationID: loc,
            locationName: await nameForLocation(loc, siteOrigin),
            from,
            to,
            tz: tz || TZ_FALLBACK,
            order: EVENT_ORDER,
            days,
            rated_sum: ratedSum,
            rating_avg: ratingAvg,
            qrInfo,
            campaigns
          },
          200
        );
      }

      // GET /api/stats/entity?entityID=...&from=YYYY-MM-DD&to=YYYY-MM-DD[&tz=Europe/Berlin]
      // Phase 3: owner session required; entity access allowed only if the session ULID is in entity:<id>:locations.
      if (url.pathname === "/api/stats/entity" && req.method === "GET") {
        const auth = await requireOwnerSession(req, env);
        if (auth instanceof Response) return auth;

        const ent  = (url.searchParams.get("entityID")||"").trim();

        const from = (url.searchParams.get("from")||"").trim();
        const to   = (url.searchParams.get("to")  ||"").trim();
        const tz   = (url.searchParams.get("tz")  ||"").trim() || undefined;
        if (!ent || !/^\d{4}-\d{2}-\d{2}$/.test(from) || !/^\d{4}-\d{2}-\d{2}$/.test(to)) {
          return json({ error:{code:"invalid_request", message:"entityID, from, to required (YYYY-MM-DD)"} }, 400);
        }

        // Resolve the entity's locations. To start, read a KV list (write it when you approve the entity).
        // Format: KV key entity:<entityID>:locations => JSON array of locationIDs
        const raw = await env.KV_STATUS.get(`entity:${ent}:locations`);
        const locs: string[] = raw ? JSON.parse(raw) : [];

        // Single-ULID session binding: entity sums are allowed only if the session ULID is explicitly part of the entity.
        if (!Array.isArray(locs) || !locs.includes(auth.ulid)) {
          return new Response("Denied", {
            status: 403,
            headers: { "cache-control": "no-store", "Referrer-Policy": "no-referrer" }
          });
        }

        const days: Record<string, Partial<Record<EventKey, number>>> = {};

        for (const loc of locs) {
          const prefix = `stats:${loc}:`;
          let cursor: string|undefined = undefined;
          do {
            const page = await env.KV_STATS.list({ prefix, cursor });
            for (const k of page.keys) {
              const parts = k.name.split(":");
              if (parts.length !== 4) continue;
              const day = parts[2];
              const ev = (parts[3] as string).replaceAll("_", "-") as EventKey;
              if (day < from || day > to) continue;
              const n = parseInt((await env.KV_STATS.get(k.name))||"0",10) || 0;
              if (!days[day]) days[day] = {};
              days[day][ev] = (days[day][ev] || 0) + n; // keep additive; now normalized
            }
            cursor = page.cursor || undefined;
          } while (cursor);
        }

        return json({ entityID: ent, entityName: await nameForEntity(ent), from, to, tz: tz || TZ_FALLBACK, order: EVENT_ORDER, days }, 200);
      }

      // --- Analytics track: POST /api/track
      if (pathname === "/api/track" && req.method === "POST") {
        return await handleTrack(req, env);
      }

      // --- Status: GET /api/status?locationID=...
      if (pathname === "/api/status" && req.method === "GET") {
        return await handleStatus(req, env);
      }

      // --- Redeem token status: GET /api/redeem-status?token=... (or &rt=...)
      // Used by the customer device to detect when a promo QR token was actually redeemed.
      if (pathname === "/api/redeem-status" && req.method === "GET") {
        const u = new URL(req.url);
        const token =
          (u.searchParams.get("token") || "").trim() ||
          (u.searchParams.get("rt") || "").trim();

        if (!token) {
          return json(
            { error: { code: "invalid_request", message: "token required" } },
            400
          );
        }

        const key = `redeem:${token}`;
        const raw = await env.KV_STATS.get(key, "text");

        let status: "pending" | "redeemed" | "invalid" = "invalid";
        if (raw) {
          try {
            const rec = JSON.parse(raw) as RedeemTokenRecord;
            if (rec && rec.status === "fresh") status = "pending";
            else if (rec && rec.status === "redeemed") status = "redeemed";
            else status = "invalid";
          } catch {
            status = "invalid";
          }
        }

        return json({ token, status }, 200);
      }

      // --- Promo redeem landing: /out/qr-redeem/<slug>?camp=...&rt=...
      // Redirect only with pending state; the landing page must ask the backend for the real redeem outcome.
      if (pathname.startsWith("/out/qr-redeem/") && req.method === "GET") {
        const parts = pathname.split("/").filter(Boolean); // ['out','qr-redeem','id']
        const idRaw = parts[2] || "";
        const loc = await resolveUid(idRaw, env);
        if (!loc) {
          return json({ error:{ code:"invalid_request", message:"bad id" } }, 400);
        }

        const u = new URL(req.url);
        const token =
          (u.searchParams.get("rt") || "").trim() ||
          (u.searchParams.get("token") || "").trim();
        const camp = (u.searchParams.get("camp") || "").trim();

        const landing = new URL("/", "https://navigen.io"); // redeem landing must always return to the site shell, even when QR entry uses the API worker
        landing.searchParams.set("lp", idRaw);
        landing.searchParams.set("redeem", "pending");
        if (camp) landing.searchParams.set("camp", camp);
        if (token) landing.searchParams.set("rt", token);

        return new Response(null, {
          status: 302,
          headers: {
            "Location": landing.toString(),
            "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
            "CDN-Cache-Control": "no-store",
            "Pragma": "no-cache",
            "Expires": "0",
            "Referrer-Policy": "no-referrer",
            "X-NG-Redeem-Contract": "pending-v2",
            "X-NG-Redeem-Build": "2026-03-11-api-pending-v4",
            "Access-Control-Allow-Origin": "https://navigen.io",
            "Access-Control-Allow-Credentials": "true",
            "Vary": "Origin"
          }
        });
      }
      
      // --- Outbound tracked redirect: /out/{event}/{id}?to=<url>
      if (pathname.startsWith("/out/") && req.method === "GET") {
        const parts = pathname.split("/").filter(Boolean); // ['out','event','id']
        const ev = (parts[1] || "").toLowerCase().replaceAll("_","-");
        const idRaw = parts[2] || "";
        const to = (new URL(req.url)).searchParams.get("to") || "";

        const allowed = new Set<string>(EVENT_ORDER as readonly string[]);
        if (!allowed.has(ev)) {
          return json({ error:{ code:"invalid_request", message:"unsupported event" } }, 400);
        }

        const loc = await resolveUid(idRaw, env);
        if (!loc) {
          return json({ error:{ code:"invalid_request", message:"bad id" } }, 400);
        }

        // basic redirect safety: https only
        if (!/^https:\/\/[^ ]+/i.test(to)) {
          return json({ error:{ code:"invalid_request", message:"https to= required" } }, 400);
        }

        // lightweight human-navigation guard (skip obvious bots/previews)
        const method = req.method || "GET";
        const sfm = req.headers.get("Sec-Fetch-Mode") || "";
        const ua = req.headers.get("User-Agent") || "";
        const isHumanNav =
          method === "GET" &&
          (!sfm || /navigate|same-origin/i.test(sfm)) &&
          !/(bot|crawler|spider|facebookexternalhit|twitterbot|slackbot)/i.test(ua);

        if (isHumanNav) {
          try {
            const now = new Date();
            const country = (req as any).cf?.country || "";
            const day = dayKeyFor(now, undefined, country);
            await kvIncr(env.KV_STATS, `stats:${loc}:${day}:${ev}`);
          } catch {}
        }

        return new Response(null, {
          status: 302,
          headers: {
            "Location": to,
            "Cache-Control": "no-store",
            "Access-Control-Allow-Origin": "https://navigen.io",
            "Access-Control-Allow-Credentials": "true",
            "Vary": "Origin"
          }
        });
      }
      
      // --- Non-redirect hit: POST /hit/{event}/{id}
      if (pathname.startsWith("/hit/") && req.method === "POST") {
        const parts = pathname.split("/").filter(Boolean); // ['hit','event','id']
        const ev = (parts[1] || "").toLowerCase().replaceAll("_","-");
        const idRaw = parts[2] || "";

        const allowed = new Set<string>(EVENT_ORDER as readonly string[]);
        if (!allowed.has(ev)) {
          return json({ error:{ code:"invalid_request", message:"unsupported event" } }, 400);
        }

        // QR-redeem must be accepted broadly; token + KV record enforce validity.

        const loc = await resolveUid(idRaw, env);
        if (!loc) {
          return json({ error:{ code:"invalid_request", message:"bad id" } }, 400);
        }

        const now = new Date();
        const country = (req as any).cf?.country || "";
        const day = dayKeyFor(now, undefined, country);

        if (ev === "rating") {
          const url = new URL(req.url);
          const scoreRaw = (url.searchParams.get("score") || "").trim();
          const score = parseInt(scoreRaw, 10);

          if (!Number.isFinite(score) || score < 1 || score > 5) {
            return json(
              { error: { code: "invalid_request", message: "score must be 1-5" } },
              400,
              { "cache-control": "no-store", "Referrer-Policy": "no-referrer" }
            );
          }

          const deviceKey = readRatingDeviceKey(req);
          if (!deviceKey) {
            return json(
              { error: { code: "invalid_request", message: "rating device missing" } },
              400,
              { "cache-control": "no-store", "Referrer-Policy": "no-referrer" }
            );
          }

          const voteKey = ratingVoteKey(loc, deviceKey);
          const prev = await env.KV_STATUS.get(voteKey, { type: "json" }) as any;

          const prevScore = Number(prev?.score);
          const prevDay = String(prev?.day || "").trim();
          const prevVotedAtMs = Date.parse(String(prev?.votedAt || ""));

          const isLocked =
            Number.isFinite(prevScore) &&
            prevScore >= 1 &&
            prevScore <= 5 &&
            Number.isFinite(prevVotedAtMs) &&
            (now.getTime() - prevVotedAtMs) < RATING_WINDOW_MS;

          const summary = await readRatingSummary(env, loc);

          let nextCount = summary.count;
          let nextSum = summary.sum;
          let applied: "new" | "updated" | "noop" = "new";

          if (isLocked) {
            const delta = score - prevScore;

            if (delta !== 0) {
              if (prevDay && prevDay !== day) {
                await kvAdd(env.KV_STATS, `stats:${loc}:${prevDay}:rating`, -1);
                await kvAdd(env.KV_STATS, `stats:${loc}:${prevDay}:rating-score`, -prevScore);
                await kvAdd(env.KV_STATS, `stats:${loc}:${day}:rating`, 1);
                await kvAdd(env.KV_STATS, `stats:${loc}:${day}:rating-score`, score);
              } else {
                await kvAdd(env.KV_STATS, `stats:${loc}:${day}:rating-score`, delta);
              }

              nextSum = Math.max(0, nextSum + delta);
              applied = "updated";
            } else {
              applied = "noop";
            }
          } else {
            await kvIncr(env.KV_STATS, `stats:${loc}:${day}:${ev}`);
            await kvAdd(env.KV_STATS, `stats:${loc}:${day}:rating-score`, score);
            nextCount += 1;
            nextSum += score;
            applied = "new";
          }

          await env.KV_STATUS.put(
            ratingSummaryKey(loc),
            JSON.stringify({
              count: nextCount,
              sum: nextSum,
              updatedAt: now.toISOString()
            })
          );

          const lockedUntil = new Date(now.getTime() + RATING_WINDOW_MS).toISOString();

          await env.KV_STATUS.put(
            voteKey,
            JSON.stringify({
              score,
              day,
              votedAt: now.toISOString()
            }),
            { expirationTtl: 60 * 60 * 24 * 31 }
          );

          return json(
            {
              ok: true,
              locationID: loc,
              applied,
              ratingAvg: nextCount > 0 ? (nextSum / nextCount) : 0,
              ratedSum: nextCount,
              userScore: score,
              ratingLockedUntil: lockedUntil,
              ratingCooldownMinutes: 30
            },
            200,
            { "cache-control": "no-store", "Referrer-Policy": "no-referrer" }
          );
        }

        // always increment the base event counter (e.g., 'share' → how many times the action was used)
        await kvIncr(env.KV_STATS, `stats:${loc}:${day}:${ev}`);

        // For QR scan events, also log a per-scan record (powers QR Info / Campaigns in the dash).
        if (ev === "qr-scan") {
          await logQrScan(env.KV_STATS, env, loc, req);
        }

        // For QR redeem events, validate token and return a truthful outcome for the landing page.
        if (ev === "qr-redeem") {
          // Accept token from header OR query string.
          // Reason: real QR scans open a URL and cannot send custom headers.
          const u = new URL(req.url);
          const token =
            (req.headers.get("X-NG-QR-Token") || "").trim() ||
            (u.searchParams.get("rt") || "").trim() ||
            (u.searchParams.get("token") || "").trim();
          const wantsJson = (u.searchParams.get("json") || "").trim() === "1";

          const finish = async (
            outcome: "ok" | "used" | "inactive" | "invalid",
            campaignKey = ""
          ) => {
            if (outcome === "ok") {
              await logQrRedeem(env.KV_STATS, env, loc, req, campaignKey);
            } else {
              await logQrRedeemInvalid(env.KV_STATS, env, loc, req, campaignKey);
            }

            if (wantsJson) {
              return json(
                { ok: outcome === "ok", outcome, campaignKey },
                200,
                { "cache-control": "no-store", "Referrer-Policy": "no-referrer" }
              );
            }

            return new Response(null, {
              status: 204,
              headers: {
                "Access-Control-Allow-Origin": "https://navigen.io",
                "Access-Control-Allow-Credentials": "true",
                "Vary": "Origin"
              }
            });
          };

          // Promo redeem is campaign-paid: campaign entitlement is enforced below via tokenCampaignKey.
          if (!token) {
            return await finish("invalid");
          }

          const recRaw = await env.KV_STATS.get(`redeem:${token}`, "text");
          let tokenCampaignKey = "";
          let tokenLocationID = "";
          let tokenStatus = "";

          try {
            const rec = recRaw ? (JSON.parse(recRaw) as RedeemTokenRecord) : null;
            tokenCampaignKey = String(rec?.campaignKey || "").trim();
            tokenLocationID = String(rec?.locationID || "").trim();
            tokenStatus = String(rec?.status || "").trim();
          } catch {
            tokenCampaignKey = "";
            tokenLocationID = "";
            tokenStatus = "";
          }

          if (!tokenCampaignKey || !tokenLocationID || tokenLocationID !== loc) {
            return await finish("invalid", tokenCampaignKey);
          }

          // Validate: the token's campaignKey must still be active for this ULID (no "winner" logic).
          const rawRows = await env.KV_STATUS.get(campaignsByUlidKey(loc), { type: "json" }) as any;
          const rows: any[] = Array.isArray(rawRows) ? rawRows : [];

          const nowMs = Date.now();
          const tokenCampaignIsActive = rows.some((r: any) => {
            if (!r || String(r.locationID || "").trim() !== loc) return false;
            const st = String(r?.statusOverride || r?.status || "").trim().toLowerCase();
            if (st !== "active") return false;
            const sMs = parseYmdUtcMs(String(r?.startDate || ""));
            const eMs = parseYmdUtcMs(String(r?.endDate || ""));
            if (!Number.isFinite(sMs) || !Number.isFinite(eMs)) return false;
            if (nowMs < sMs) return false;
            if (nowMs > (eMs + 24 * 60 * 60 * 1000 - 1)) return false;
            return String(r?.campaignKey || "").trim() === tokenCampaignKey;
          });

          if (!tokenCampaignIsActive) {
            return await finish("inactive", tokenCampaignKey);
          }

          if (tokenStatus === "redeemed") {
            return await finish("used", tokenCampaignKey);
          }

          const result = await consumeRedeemToken(env.KV_STATS, token, loc, tokenCampaignKey);

          if (result === "ok") {
            return await finish("ok", tokenCampaignKey);
          }
          if (result === "used") {
            return await finish("used", tokenCampaignKey);
          }
          return await finish("invalid", tokenCampaignKey);
        }
        
        return new Response(null, {
          status: 204,
          headers: {
            "Access-Control-Allow-Origin": "https://navigen.io",
            "Access-Control-Allow-Credentials": "true",
            "Vary": "Origin"
          }
        });
      }

      // --- Stripe: create Checkout Session for campaign purchase (Phase 5)
      // Server-only: uses STRIPE_SECRET_KEY; client never sees Stripe secret.
      if (normPath === "/api/stripe/create-checkout-session" && req.method === "POST") {
        const noStore = { "cache-control": "no-store" };
        const body = await req.json().catch(() => null) as any;
        return await createCampaignCheckoutSession(env, req, body, noStore);
      }

      // (Stubs for later)
      // if (pathname === "/api/checkout") { ... }
      // if (pathname === "/api/webhook")  { ... }
      // if (pathname === "/m/edit")       { ... }
      // if (pathname === "/api/location/update") { ... }

      // use normPath declared earlier; do not redeclare here

      // GET /api/campaigns/active?context=<pageKey?>
      // KV-authoritative list of active campaigns, used by Promotions modal.
      if (pathname === "/api/campaigns/active" && req.method === "GET") {
        const u = new URL(req.url);
        const ctx = String(u.searchParams.get("context") || "").trim().toLowerCase();

        const todayISO = (() => {
          const now = new Date();
          // normalize to YYYY-MM-DD in UTC for window comparisons
          return new Date(now.getTime() - now.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
        })();

        const isActiveRow = (r: any) => {
          const st = String(r?.statusOverride || r?.status || "").trim().toLowerCase();
          if (st !== "active") return false;
          const sd = String(r?.startDate || "").trim();
          const ed = String(r?.endDate || "").trim();
          if (!/^\d{4}-\d{2}-\d{2}$/.test(sd) || !/^\d{4}-\d{2}-\d{2}$/.test(ed)) return false;
          return todayISO >= sd && todayISO <= ed;
        };

        const matchesContext = (r: any) => {
          if (!ctx) return true;
          const raw = String(r?.context || "").trim().toLowerCase();
          if (!raw) return true; // empty ctx means global
          const arr = raw.split(";").map(s => s.trim()).filter(Boolean);
          return arr.includes(ctx);
        };

        // Walk KV campaigns:byUlid:* (small set; safe for now)
        const out: any[] = [];
        let cursor: string | undefined = undefined;

        for (let guard = 0; guard < 25; guard++) { // hard guard against accidental infinite paging
          const page = await env.KV_STATUS.list({ prefix: "campaigns:byUlid:", cursor });
          for (const k of (page.keys || [])) {
            const raw = await env.KV_STATUS.get(k.name, "text");
            if (!raw) continue;
            let rows: any[] = [];
            try { rows = JSON.parse(raw); } catch { rows = []; }
            if (!Array.isArray(rows)) continue;

            const actives = rows.filter(r => isActiveRow(r) && matchesContext(r));
            for (const r of actives) {
              const locationULID = String(r?.locationULID || r?.locationID || "").trim();
              const locationSlug = String(r?.locationSlug || "").trim();

              // Resolve human name by slug (profiles.json is keyed by locationID=slug)
              const locationName = (await nameForLocation(locationSlug, req.headers.get("Origin") || "https://navigen.io")) || "";

              const dvRaw = (r?.campaignDiscountValue != null) ? r.campaignDiscountValue : null;
              const discountValue =
                (typeof dvRaw === "number") ? dvRaw :
                (typeof dvRaw === "string" && dvRaw.trim() && Number.isFinite(Number(dvRaw))) ? Number(dvRaw) :
                null;

              out.push({
                campaignKey: String(r?.campaignKey || "").trim(),
                campaignName: String(r?.campaignName || "").trim(),
                locationID: locationSlug || locationULID,
                locationULID,
                locationSlug,
                locationName,
                context: String(r?.context || "").trim(),
                offerType: String(r?.offerType || "").trim(),
                productName: String(r?.productName || r?.offerType || "").trim(),
                eligibilityType: String(r?.eligibilityType || "").trim(),
                eligibilityNotes: String(r?.eligibilityNotes || "").trim(),
                discountKind: String(r?.discountKind || "").trim(),
                discountValue,
                startDate: String(r?.startDate || "").trim(),
                endDate: String(r?.endDate || "").trim(),
                status: String(r?.statusOverride || r?.status || "").trim()
              });
            }
          }

          cursor = page.cursor;
          if (!page.list_complete) break;
          if (!cursor) break;
        }

        return json({ items: out }, 200, { "cache-control": "no-store" });
      }

      // GET /api/data/list?context=...&limit=...
      if (normPath === "/api/data/list" && req.method === "GET") {
        const target = new URL("https://navigen.io/api/data/list"); // fixed upstream path
        url.searchParams.forEach((v, k) => target.searchParams.set(k, v)); // pass through query exactly
        const r = await fetch(target.toString(), { cf: { cacheTtl: 30, cacheEverything: true }, headers: { "Accept": "application/json" } });

        if (r.status >= 400) {
          const preview = await r.clone().text().then(t => t.slice(0, 256)).catch(() => "<no-body>");
          const qs = Object.fromEntries(target.searchParams);
          console.warn(JSON.stringify({ route: "/api/data/list", status: r.status, qs, preview }));
        }

        const body = await r.text();

        // Discoverability policy for context discovery:
        // Keep the full upstream row set so context pages can mirror source visibility and priority.
        // Direct-link LPM behavior remains unchanged; only list ordering is adjusted here.
        let outBody = body;

        try {
          // Only filter successful JSON responses.
          if (r.ok) {
            const parsed = JSON.parse(body);

            const arr: any[] = Array.isArray(parsed?.items)
              ? parsed.items
              : (parsed?.items && typeof parsed.items === "object")
                ? Object.values(parsed.items)
                : (Array.isArray(parsed?.locations)
                    ? parsed.locations
                    : (parsed?.locations && typeof parsed.locations === "object")
                      ? Object.values(parsed.locations)
                      : []);

            // Build discovery list with preferential visibility:
            // - "promoted" (paid active) first
            // - then "visible" (courtesy/hold)
            // - then remaining rows, without excluding them from the context list
            //
            // NOTE: this is a deterministic, lightweight ordering (no ML, no ads).
            const ranked: Array<{ rec: any; rank: number }> = [];

            for (const rec of arr) {
              const slug = String(rec?.alias || rec?.locationID || "").trim();
              const ulid = (await resolveUid(slug, env)) || ""; // canonical ULID (required for ownership lookup)

              // If we can't resolve a ULID, fail open (treat as visible but non-promoted).
              if (!ulid || !/^[0-9A-HJKMNP-TV-Z]{26}$/i.test(ulid)) {
                ranked.push({ rec, rank: 0 });
                continue;
              }

              const vis = await computeVisibilityState(env, ulid);

              // Exclude hidden from discovery lists
              // Keep hidden-state rows in the context list; only rank them after promoted and visible rows.
              
              // Preferential visibility weight (highest first)
              const rank =
                vis.visibilityState === "promoted" ? 2 :
                vis.visibilityState === "visible"  ? 1 : 0;

              ranked.push({ rec, rank });
            }

            // Stable ordering: promoted first, then visible, then the rest
            ranked.sort((a, b) => b.rank - a.rank);

            const filtered = ranked.map(x => x.rec);

            // Preserve original shape: if upstream returned { locations: [...] }, keep that.
            outBody = JSON.stringify(parsed?.items ? { ...parsed, items: filtered } : { ...parsed, locations: filtered });
          }
        } catch {
          // Fail open: never break list loading due to a filtering error.
          outBody = body;
        }

        return new Response(outBody, {
          status: r.status,
          headers: {
            "Content-Type": "application/json; charset=utf-8",
            "Access-Control-Allow-Origin": "https://navigen.io",
            "Access-Control-Allow-Credentials": "true",
            "Vary": "Origin",
            "Cache-Control": "no-store",
            "x-navigen-route": "/api/data/list",
            "x-ng-list-order": "promoted-first"
          }
        });
      }

      // GET /api/data/profile?id=...
      // profile: accept alias or ULID; resolve alias → ULID via KV_ALIASES
      if (normPath === "/api/data/profile" && req.method === "GET") {
        const base = req.headers.get("Origin") || "https://navigen.io"; // keep caller origin
        const target = new URL("/api/data/profile", base);

        const raw = (url.searchParams.get("id") || "").trim();
        const isUlid = /^[0-9A-HJKMNP-TV-Z]{26}$/.test(raw);
        const mapped = isUlid ? raw : (await resolveUid(raw, env)) || raw;

        url.searchParams.forEach((v, k) => { if (k !== "id") target.searchParams.set(k, v); });
        target.searchParams.set("id", mapped);

        const r = await fetch(target.toString(), { cf: { cacheTtl: 30, cacheEverything: true }, headers: { "Accept": "application/json" } });

        const body = await r.text();
        
        return new Response(body, {
          status: r.status,
          headers: {
            "Content-Type": r.headers.get("Content-Type") || "application/json; charset=utf-8",
            "Access-Control-Allow-Origin": "https://navigen.io",
            "Access-Control-Allow-Credentials": "true",
            "Vary": "Origin",
            "Cache-Control": "no-store",
            "x-navigen-route": "/api/data/profile"
          }
        });
      }

      // GET /api/data/item?id=...
      // item: accept alias or ULID; resolve alias → ULID; return single item + contexts[]
      if (normPath === "/api/data/item" && req.method === "GET") {
        const idParam = (url.searchParams.get("id") || "").trim();
        if (!idParam) {
          return json(
            { error: { code: "invalid_request", message: "id required" } },
            400,
            { "x-navigen-route": "/api/data/item" }
          );
        }

        const ULID_RE = /^[0-9A-HJKMNP-TV-Z]{26}$/i;

        // 1) canonical ULID (if idParam is a slug)
        const mapped = (await resolveUid(idParam, env)) || idParam;
        const isUlid = ULID_RE.test(mapped);

        // 2) load profiles.json once
        const base = req.headers.get("Origin") || "https://navigen.io";
        const src  = new URL("/data/profiles.json", base).toString();
        const resp = await fetch(src, {
          cf: { cacheTtl: 60, cacheEverything: true },
          headers: { "Accept": "application/json" }
        });

        if (!resp.ok) {
          return json(
            { error: { code: "upstream", message: "profiles.json not reachable" } },
            502,
            { "x-navigen-route": "/api/data/item" }
          );
        }

        let data: any;
        try {
          data = await resp.json();
        } catch {
          data = { locations: [] };
        }

        const locs: any[] = Array.isArray(data?.locations)
          ? data.locations
          : (data?.locations && typeof data.locations === "object")
            ? Object.values(data.locations)
            : [];

        // 3) first try: direct slug/ID match from profiles.json
        let hit = locs.find((p) => {
          const slug = String(p?.locationID || "").trim();
          const id   = String(p?.ID || p?.id || "").trim();
          // match by slug OR by ULID (if profiles.json ever stores it)
          return slug === idParam || id === mapped;
        });

        // 4) second try: ULID → slug via KV_ALIASES, then slug → profiles.json
        if (!hit && isUlid && env.KV_ALIASES) {
          let aliasSlug = "";
          let cursor: string | undefined = undefined;

          do {
            const page = await env.KV_ALIASES.list({ prefix: "alias:", cursor });
            for (const k of page.keys) {
              const name = k.name; // "alias:<slug>"
              const raw = await env.KV_ALIASES.get(name, "text");
              if (!raw) continue;

              let val = raw.trim();
              if (val.startsWith("{")) {
                try {
                  const j = JSON.parse(val) as any;
                  val = String(j?.locationID || "").trim();
                } catch {
                  val = "";
                }
              }

              if (val && val === mapped) {
                aliasSlug = name.replace(/^alias:/, "");
                break;
              }
            }
            if (aliasSlug) break;
            cursor = page.cursor || undefined;
          } while (cursor);

          if (aliasSlug) {
            hit = locs.find((p) => String(p?.locationID || "").trim() === aliasSlug);
          }
        }

        if (!hit) {
          return json(
            { error: { code: "not_found", message: "item not found" } },
            404,
            { "x-navigen-route": "/api/data/item" }
          );
        }

        const ctxStr = String(hit.context || hit.Context || "").trim();
        const ctxArr = ctxStr
          ? ctxStr.split(";").map((s: string) => s.trim()).filter(Boolean)
          : [];

        const payload = {
          id: mapped || hit.ID || hit.id || hit.locationID,
          locationID: String(hit.locationID || "").trim(),
          contexts: ctxArr,
          locationName: hit.locationName || hit.name,
          media: hit.media || {},
          coord: hit.coord || hit["Coordinate Compound"] || "",
          links: hit.links || {},
          contactInformation: hit.contactInformation || hit.contact || {},
          descriptions: hit.descriptions || {},
          tags: Array.isArray(hit.tags) ? hit.tags : [],
          ratings: hit.ratings || {},
          pricing: hit.pricing || {}
        };

        return json(payload, 200, { "x-navigen-route": "/api/data/item" });
      }

      // Fallback 404 — include the evaluated path for live verification
      return json(
        { error: { code: "not_found", message: "No such route", path: (new URL(req.url)).pathname } },
        404,
        { "x-navigen-route": (new URL(req.url)).pathname }
      );

    } catch (err: any) {
      return json({ error: { code: "server_error", message: err?.message || "Unexpected" } }, 500);
    }
  },
};

// build per-request; base comes from Origin header (staging/prod safe)

async function nameForLocation(id: string, siteOrigin?: string): Promise<string | undefined> {
  try {
    const base = siteOrigin || "https://navigen.io"; // fallback only
    const url  = new URL("/data/profiles.json", base).toString();
    const res  = await fetch(url, { cf: { cacheTtl: 300, cacheEverything: true } });
    if (!res.ok) return undefined;
    const data: any = await res.json();

    // supports both: locations: [...] and locations: { [id]: {...} }
    const arr = Array.isArray(data?.locations) ? data.locations : undefined;
    const map = (!arr && data?.locations && typeof data.locations === "object") ? data.locations : undefined;
    const hit = arr ? arr.find((x: any) => x?.locationID === id) : map?.[id];

    // supports { locationName: { en: "…" } } or { name: "…" }
    const ln = hit?.locationName || hit?.name;
    const name = typeof ln === "string" ? ln : (ln?.en || ln?.default);
    return typeof name === "string" ? name : undefined; // safe fallback
  } catch { return undefined; }
}

async function nameForEntity(_id: string): Promise<string | undefined> {
  return undefined; // entities don't have names in profiles.json
}

// ---------- handlers ----------

async function handleQr(req: Request, env: Env): Promise<Response> {
  const url = new URL(req.url);
  const raw = (url.searchParams.get("locationID") || "").trim();
  if (!raw) {
    return json(
      { error: { code: "invalid_request", message: "locationID required" } },
      400
    );
  }

  const fmt = (url.searchParams.get("fmt") || "svg").toLowerCase();
  const size = clamp(parseInt(url.searchParams.get("size") || "512", 10), 128, 1024);

  // 1) Load profiles.json and find the matching record by slug or ID
  let profiles: any;
  try {
    const src = new URL("/data/profiles.json", "https://navigen.io").toString();
    const resp = await fetch(src, {
      cf: { cacheTtl: 60, cacheEverything: true },
      headers: { Accept: "application/json" }
    });
    if (!resp.ok) {
      return json(
        { error: { code: "upstream", message: "profiles.json not reachable" } },
        502
      );
    }
    profiles = await resp.json();
  } catch {
    profiles = { locations: [] };
  }

  const locs: any[] = Array.isArray(profiles?.locations)
    ? profiles.locations
    : (profiles?.locations && typeof profiles.locations === "object")
      ? Object.values(profiles.locations)
      : [];

  const hit = locs.find((p) => {
    const slug = String(p?.locationID || "").trim();
    const id   = String(p?.ID || p?.id || "").trim();
    return slug === raw || id === raw;
  });

  // 2) Resolve final landing URL (qrUrl, or fallback ?lp=<raw>), then wrap it in /out/qr-scan
  let targetUrl = "";
  if (hit && hit.qrUrl) {
    targetUrl = String(hit.qrUrl).trim();
  } else {
    // Fallback: not expected in practice, but keep a sane default
    const dest = new URL("/", "https://navigen.io");
    dest.searchParams.set("lp", raw);
    targetUrl = dest.toString();
  }

  // Build tracked scan URL on navigen.io that will increment qr-scan, then redirect to targetUrl
  const scanUrl = new URL(`/out/qr-scan/${encodeURIComponent(raw)}`, "https://navigen.io");
  scanUrl.searchParams.set("to", targetUrl);
  const dataUrl = scanUrl.toString();

  // 3) Generate QR code with dataUrl as the payload (tracked via /out/qr-scan, then redirected to qrUrl)

  if (fmt === "svg") {
    const svg = await QRCode.toString(dataUrl, { type: "svg", width: size, margin: 0 });
    return new Response(svg, {
      headers: {
        "Content-Type": "image/svg+xml",
        "Cache-Control": "public, max-age=86400",
        "Access-Control-Allow-Origin": "https://navigen.io",
        "Access-Control-Allow-Credentials": "true",
        "Vary": "Origin"
      }
    });
  } else {
    const bytes = await QRCode.toBuffer(dataUrl, { type: "png", width: size, margin: 0 });
    return new Response(bytes, {
      headers: {
        "content-type": "image/png",
        "cache-control": "public, max-age=86400",
        "access-control-allow-origin": "*"
      }
    });
  }
}

async function handleTrack(req: Request, env: Env): Promise<Response> {
  // Expected small JSON from navigator.sendBeacon
  let payload: any = {};
  try {
    payload = await req.json();
  } catch {
    return json({ error: { code: "invalid_request", message: "JSON body required" } }, 400);
  }

  const locRaw = (typeof payload.locationID === "string" && payload.locationID.trim()) ? payload.locationID.trim() : ""; // accept slug or ULID
  const loc = await resolveUid(locRaw, env); if (!loc) { // require canonical id
    // unknown id: no-op (do not leak); keep CORS consistent with allowlist
    return new Response(null, {
      status: 204,
      headers: {
        "access-control-allow-origin": "https://navigen.io", // or your allowOrigin variable
        "access-control-allow-credentials": "true",
        "vary": "Origin"
      }
    });
  }

  // canonicalize: _→- and trim; clients send hyphen metrics
  const event = (payload.event || "").toString().toLowerCase().replaceAll("_","-").trim();
  // normalize action into canonical dashboard keys
  let action = (payload.action || "").toString().toLowerCase().replaceAll("_","-").trim(); // normalize legacy
  // normalize action into canonical keys (keeps daily stats consistent)
  if (action.startsWith("nav.")) action = "map";                  // nav.google/nav.apple → map
  if (action === "route") action = "map";                         // older client emitted "route"
  if (action.startsWith("social.")) action = action.slice(7) || "other"; // social.instagram → instagram
  if (action === "share-contact" || action === "share_contact") action = "share"; // Business Card share → share

  if (action.startsWith("share")) action = "share";               // share_contact / share-qr → share
  // optional: fold anything not in EVENT_ORDER into "other" (keeps data consolidated)

  // accept locationID (primary)
  if (!loc || !event) {
    return json({ error: { code: "invalid_request", message: "locationID and event required" } }, 400);
  }
  
  // accept any metric listed in EVENT_ORDER (hyphen canonical)
  const allowed = new Set<string>(EVENT_ORDER as readonly string[]);
  if (!allowed.has(event)) {
    return json({ error: { code: "invalid_request", message: "unsupported event" } }, 400);
  }

  // A) daily counter
  const now = new Date();
  const country = (req as any).cf?.country || "";      // CF edge country
  const tz = (payload?.tz || "").trim() || undefined;  // optional client tz
  // direct metric counting (event itself is the metric key)
  const evKey = event;
  if ((EVENT_ORDER as readonly string[]).includes(evKey)) {
    const day = dayKeyFor(now, tz, country);
    const key = `stats:${loc}:${day}:${evKey}`;
    await kvIncr(env.KV_STATS, key); // base counter (e.g. "rating" → how many rating events)

    // For rating events, also accumulate the 1–5 score so /api/stats can compute an average.
    if (evKey === "rating") {
      const scoreRaw = (
        payload?.score ??
        payload?.rating ??
        payload?.value ??
        ""
      ).toString().trim();
      const score = parseInt(scoreRaw, 10);

      if (Number.isFinite(score) && score >= 1 && score <= 5) {
        const scoreKey = `stats:${loc}:${day}:rating-score`;
        const cur = parseInt((await env.KV_STATS.get(scoreKey)) || "0", 10) || 0;
        await env.KV_STATS.put(scoreKey, String(cur + score), {
          expirationTtl: 60 * 60 * 24 * 366 // keep stats ~1 year like kvIncr()
        });
      }
    }
  }
  
  // count by the metric key directly (event is canonical)
  const bucket = event;
  await increment(env.KV_STATS, keyForStat(loc, bucket));

  // keep response as before (e.g., return 204)
  // daily counters above + legacy YYYYMMDD bucket for older readers

  const origin = req.headers.get("Origin") || "";
  const allowOrigin = origin || "*";

  return new Response(null, {
    status: 204,
    headers: {
      "access-control-allow-origin": "https://navigen.io", // same as above (or allowOrigin variable)
      "access-control-allow-credentials": "true",
      "vary": "Origin"
    }
  });
}

async function handleStatus(req: Request, env: Env): Promise<Response> {
  const url = new URL(req.url);
  const idParam = url.searchParams.get("locationID") || "";
  const idRaw = String(idParam || "").trim();
  const locID = ULID_RE.test(idRaw) ? idRaw : ((await resolveUid(idRaw, env)) || "");  
  if (!locID) return json({ error: { code: "invalid_request", message: "locationID required" } }, 400);

  const raw = await env.KV_STATUS.get(statusKey(locID), "json");
  const status = raw?.status || "free";
  const tier = raw?.tier || "free";

  // return minimal status payload for the app (no caching to reflect live changes)
  const vis = await computeVisibilityState(env, locID);

  // campaign entitlement (authoritative, KV-backed)
  const camp = await campaignEntitlementForUlid(env, locID);

  // Expose the full active set so the LPM can distinguish single vs multiple campaigns.
  const rawCampaignRows = await env.KV_STATUS.get(campaignsByUlidKey(locID), { type: "json" }) as any;
  const campaignRows: any[] = Array.isArray(rawCampaignRows) ? rawCampaignRows : [];
  const nowMs = Date.now();

  const activeCampaignKeys = campaignRows
    .filter((row: any) => {
      if (!row || String(row?.locationID || "").trim() !== locID) return false;

      const st = String(row?.statusOverride || row?.status || "").trim().toLowerCase();
      if (st !== "active") return false;

      const startMs = parseYmdUtcMs(String(row?.startDate || ""));
      const endMs = parseYmdUtcMs(String(row?.endDate || ""));
      if (!Number.isFinite(startMs) || !Number.isFinite(endMs)) return false;

      if (nowMs < startMs) return false;
      if (nowMs > (endMs + 24 * 60 * 60 * 1000 - 1)) return false;

      return true;
    })
    .map((row: any) => String(row?.campaignKey || "").trim())
    .filter(Boolean)
    .filter((value: string, index: number, arr: string[]) => arr.indexOf(value) === index);

  const ratingSummary = await readRatingSummary(env, locID);
  const ratingDeviceKey = readRatingDeviceKey(req);
  const rawRatingVote = ratingDeviceKey
    ? await env.KV_STATUS.get(ratingVoteKey(locID, ratingDeviceKey), { type: "json" }) as any
    : null;

  const userScoreRaw = Number(rawRatingVote?.score);
  const ratingLockedUntil = (() => {
    const votedAtMs = Date.parse(String(rawRatingVote?.votedAt || ""));
    if (!Number.isFinite(votedAtMs)) return "";

    const untilMs = votedAtMs + RATING_WINDOW_MS;
    return untilMs > Date.now() ? new Date(untilMs).toISOString() : "";
  })();    

  return json(
    {
      locationID: locID,
      status,
      tier,
      ownedNow: vis.ownedNow,
      visibilityState: vis.visibilityState,
      exclusiveUntil: vis.exclusiveUntil,
      courtesyUntil: vis.courtesyUntil,

      // Campaign entitlement spine (authoritative)
      campaignEntitled: camp.entitled,
      campaignEndsAt: camp.endDate,
      activeCampaignKey: camp.campaignKey,
      activeCampaignKeys,

      // Rating spine (authoritative, cross-device read model for the LPM)
      ratingAvg: ratingSummary.avg,
      ratedSum: ratingSummary.count,
      userScore: (Number.isFinite(userScoreRaw) && userScoreRaw >= 1 && userScoreRaw <= 5) ? userScoreRaw : 0,
      ratingLockedUntil,
      ratingCooldownMinutes: 30
    },
    200,
    { "cache-control": "no-store" }
  );
}

// ---------- helpers ----------

// JSON: must be compatible with credentialed fetches from the app
function json(body: unknown, status = 200, headers: Record<string, string> = {}): Response {
  const allowOrigin = "https://navigen.io"; // keep in sync with ALLOW set above
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Access-Control-Allow-Origin": allowOrigin,
      "Access-Control-Allow-Credentials": "true",
      "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
      "Access-Control-Allow-Headers": "content-type, authorization, x-ng-device",      
      "Vary": "Origin",
      ...headers
    }
  });
}

function clamp(n: number, min: number, max: number): number {
  if (isNaN(n)) return min;
  return Math.max(min, Math.min(max, n));
}

function todayKey(): string {
  const now = new Date();
  const y = now.getUTCFullYear();
  const m = String(now.getUTCMonth() + 1).padStart(2, "0");
  const d = String(now.getUTCDate()).padStart(2, "0");
  return `${y}${m}${d}`;
}

function keyForStat(locationID: string, bucket: string): string {
  return `stats:${locationID}:${todayKey()}:${bucket}`;
}

function statusKey(locationID: string): string {
  return `status:${locationID}`;
}

function aliasKey(legacy: string): string {
  return `alias:${legacy}`;
}

// Silent QA auto-tagging: store per-location QA flags alongside status/tier in KV_STATUS.
// Flags are internal-only (admin dashboards, monitoring); merchants never see them.
async function writeQaFlags(env: Env, locationID: string, flags: string[]): Promise<void> {
  try {
    const key = statusKey(locationID);
    const raw = await env.KV_STATUS.get(key, "json");
    const base: any = raw && typeof raw === "object" ? raw : {};

    const next = {
      ...base,
      qaFlags: Array.isArray(flags) ? flags : [],
      qaUpdatedAt: new Date().toISOString()
    };

    await env.KV_STATUS.put(key, JSON.stringify(next));
  } catch {
    // never throw from QA tagging; stats endpoint must not fail because of tagging
  }
}

// -------- Campaign KV model + entitlement resolver (authoritative) --------

// Storage keys (KV_STATUS):
// - campaigns:byUlid:<ULID> -> CampaignRow[] (rules/rich model)
// - campaigns:activeIndex:<ULID> -> { entitled:boolean, campaignKey:string, endDate:string } (optional fast path)
function campaignsByUlidKey(ulid: string): string {
  return `campaigns:byUlid:${ulid}`;
}

function campaignGroupKeyKey(campaignGroupKey: string): string {
  return `campaign_group:${campaignGroupKey}`;
}

function normCampaignScope(v: unknown): "single" | "selected" | "all" {
  const s = String(v || "").trim().toLowerCase();
  if (s === "selected") return "selected";
  if (s === "all") return "all";
  return "single";
}

function normCampaignPreset(v: unknown): "visibility" | "promotion" {
  const s = String(v || "").trim().toLowerCase();
  return s === "visibility" ? "visibility" : "promotion";
}

function deriveCampaignGroupKey(seedSlug: string, campaignKey: string): string {
  const seed = String(seedSlug || "").trim() || "location";
  const key = String(campaignKey || "").trim() || "campaign";
  return `${seed}::${key}`;
}

interface EligibleLocation {
  ulid: string;
  slug: string;
  locationName: string;
}

async function eligibleLocationsForRequest(req: Request, env: Env, activeUlid = ""): Promise<EligibleLocation[]> {
  const dev = readDeviceId(req);
  if (!dev) return [];

  const idxKey = devIndexKey(dev);
  const rawIdx = await env.KV_STATUS.get(idxKey, "text");
  let arr: string[] = [];
  try { arr = rawIdx ? JSON.parse(rawIdx) : []; } catch { arr = []; }
  if (!Array.isArray(arr)) arr = [];

  const out: EligibleLocation[] = [];
  const seen = new Set<string>();

  const ordered = [
    ...arr.map(v => String(v || "").trim()).filter(Boolean),
    String(activeUlid || "").trim()
  ].filter(Boolean);

  for (const ulid of ordered) {
    if (!ulid || seen.has(ulid)) continue;
    seen.add(ulid);

    const sid = await env.KV_STATUS.get(devSessKey(dev, ulid), "text");
    if (!sid) continue;

    const sess = await env.KV_STATUS.get(`opsess:${sid}`, { type: "json" }) as any;
    if (!sess || String(sess?.ulid || "").trim() !== ulid) continue;

    let slug = ulid;
    let locationName = ulid;
    try {
      const item = await getItemById(ulid, env).catch(() => null);
      slug = String(item?.locationID || ulid).trim() || ulid;

      const ln = item?.locationName;
      const nm = (ln && typeof ln === "object")
        ? String(ln.en || Object.values(ln)[0] || "").trim()
        : String(ln || "").trim();

      if (nm) locationName = nm;
      else if (slug) locationName = slug;
    } catch {}

    out.push({ ulid, slug, locationName });
  }

  return out;
}

async function currentPlanForUlid(env: Env, ulid: string): Promise<PlanRecord | null> {
  try {
    const own = await env.KV_STATUS.get(`ownership:${ulid}`, { type: "json" }) as any;
    const paymentIntentId = String(own?.lastEventId || "").trim();
    if (!paymentIntentId) return null;

    const plan = await env.KV_STATUS.get(`plan:${paymentIntentId}`, { type: "json" }) as any;
    if (!plan || typeof plan !== "object") return null;

    return {
      priceId: String(plan?.priceId || "").trim(),
      tier: normalizePlanTier(plan?.tier),
      maxPublishedLocations: Math.max(0, Number(plan?.maxPublishedLocations || 0) || 0),
      purchasedAt: String(plan?.purchasedAt || "").trim(),
      expiresAt: String(plan?.expiresAt || "").trim()
    };
  } catch {
    return null;
  }
}

async function currentGroupPlanForUlid(env: Env, ulid: string): Promise<{ tier: PlanTier; maxPublishedLocations: number } | null> {
  try {
    const hist = await env.KV_STATUS.get(campaignsByUlidKey(ulid), { type: "json" }) as any;
    const rows: any[] = Array.isArray(hist) ? hist : [];
    const nowMs = Date.now();

    for (const row of [...rows].reverse()) {
      const groupKey = String(row?.campaignGroupKey || "").trim();
      if (!groupKey) continue;

      const st = effectiveCampaignStatus(row as any);
      if (st !== "active" && st !== "suspended") continue;

      const endMs = parseYmdUtcMs(String(row?.endDate || ""));
      if (Number.isFinite(endMs) && nowMs > (endMs + 24 * 60 * 60 * 1000 - 1)) continue;

      const parent = await env.KV_STATUS.get(campaignGroupKeyKey(groupKey), { type: "json" }) as any;
      const tier = normalizePlanTier(parent?.planTier || row?.planTier);
      const maxPublishedLocations = Math.max(
        0,
        Number(parent?.maxPublishedLocations || row?.maxPublishedLocations || 0) || 0
      );

      if (tier !== "unknown" || maxPublishedLocations > 0) {
        return { tier, maxPublishedLocations };
      }
    }
  } catch {}

  return null;
}

async function multiLocationEnabledForUlid(env: Env, ulid: string): Promise<boolean> {
  try {
    const plan = await currentPlanForUlid(env, ulid);
    return Number(plan?.maxPublishedLocations || 0) > 1;
  } catch {
    return false;
  }
}

function buildPlanUpgradeErrorBody(plan: { tier?: PlanTier; maxPublishedLocations?: number } | null, scope: "single" | "selected" | "all", requestedLocations: number) {
  const currentTier = normalizePlanTier(plan?.tier);
  const currentCapacity = Math.max(0, Number(plan?.maxPublishedLocations || 0) || 0);
  const message = currentCapacity > 0
    ? `This selection needs ${requestedLocations} locations, but the current Plan allows ${currentCapacity}.`
    : "This selection is not available for the current Plan.";

  return {
    error: {
      code: "plan_upgrade_required",
      message
    },
    upgrade: {
      currentTier,
      currentCapacity,
      requestedLocations,
      scope
    }
  };
}

interface CampaignGroupRow {
  campaignGroupKey: string;
  campaignKey: string;
  campaignScope: "single" | "selected" | "all";
  campaignPreset?: "visibility" | "promotion";
  seedLocationULID: string;
  seedLocationSlug: string;
  startDate: string;
  endDate: string;
  createdAt: string;
  stripeSessionId?: string;
  planTier?: PlanTier;
  maxPublishedLocations?: number;
}

type PromoteCampaignDraftResult =
  | {
      ok: true;
      campaignGroupKey: string;
      includedTargets: EligibleLocation[];
      endDate: string;
    }
  | {
      ok: false;
      status: number;
      body: any;
    };

async function describeLocationForMaterialization(env: Env, ulid: string, fallbackSlug = ""): Promise<EligibleLocation> {
  let slug = String(fallbackSlug || ulid).trim() || ulid;
  let locationName = slug || ulid;

  try {
    const item = await getItemById(ulid, env).catch(() => null);
    const resolvedSlug = String(item?.locationID || "").trim();
    const resolvedName = pickName(item?.locationName);

    if (resolvedSlug) slug = resolvedSlug;
    if (resolvedName) locationName = resolvedName;
    else if (slug) locationName = slug;
  } catch {}

  return { ulid, slug, locationName };
}

async function promoteCampaignDraftToActiveRows(params: {
  req: Request;
  env: Env;
  ownerUlid: string;
  draft: any;
  locationSlug: string;
  campaignKey: string;
  stripeSessionId: string;
  paidPlan: { tier?: PlanTier; maxPublishedLocations?: number } | null;
  logTag: string;
}): Promise<PromoteCampaignDraftResult> {
  const { req, env, ownerUlid, draft, locationSlug, campaignKey, stripeSessionId, paidPlan, logTag } = params;

  const scope = normCampaignScope(draft?.campaignScope);
  const campaignPreset = normCampaignPreset(draft?.campaignPreset);
  const eligibleLocations = await eligibleLocationsForRequest(req, env, ownerUlid);
  const eligibleByUlid = new Map(eligibleLocations.map((x) => [x.ulid, x]));

  if (scope !== "single" && Number(paidPlan?.maxPublishedLocations || 0) <= 1) {
    return { ok: false, status: 409, body: buildPlanUpgradeErrorBody(paidPlan, scope, 2) };
  }

  let includedTargets: EligibleLocation[] = [];

  if (scope === "selected") {
    const storedSelectedUlids: string[] = Array.from(
      new Set(
        (Array.isArray(draft?.selectedLocationULIDs) ? draft.selectedLocationULIDs : [])
          .map((x: any) => String(x || "").trim())
          .filter(Boolean)
      )
    );

    if (!storedSelectedUlids.length) {
      return {
        ok: false,
        status: 409,
        body: { error: { code: "invalid_state", message: "selected scope has no stored locations" } }
      };
    }

    for (const targetUlid of storedSelectedUlids) {
      const eligibleLoc = eligibleByUlid.get(targetUlid);
      if (eligibleLoc) {
        includedTargets.push({ ...eligibleLoc });
        continue;
      }

      if (!ULID_RE.test(targetUlid)) {
        return {
          ok: false,
          status: 409,
          body: { error: { code: "invalid_state", message: "selected scope contains an invalid location id" } }
        };
      }

      console.warn(`${logTag}: selected_target_rehydrated_from_draft`, {
        ownerUlid,
        targetUlid,
        campaignKey
      });
      includedTargets.push(await describeLocationForMaterialization(env, targetUlid));
    }
  } else if (scope === "all") {
    if (eligibleLocations.length) includedTargets = eligibleLocations.map((loc) => ({ ...loc }));
    else includedTargets = [await describeLocationForMaterialization(env, ownerUlid, locationSlug)];
  } else {
    const currentLoc = eligibleByUlid.get(ownerUlid)
      ? { ...eligibleByUlid.get(ownerUlid)! }
      : await describeLocationForMaterialization(env, ownerUlid, locationSlug);
    includedTargets = [currentLoc];
  }

  const seenTargets = new Set<string>();
  includedTargets = includedTargets.filter((loc) => {
    const id = String(loc?.ulid || "").trim();
    if (!id || seenTargets.has(id)) return false;
    seenTargets.add(id);
    return true;
  });

  if (!includedTargets.length) {
    return {
      ok: false,
      status: 409,
      body: { error: { code: "invalid_state", message: "campaign materialization resolved zero locations" } }
    };
  }

  if (Number(paidPlan?.maxPublishedLocations || 0) > 0 && includedTargets.length > Number(paidPlan?.maxPublishedLocations || 0)) {
    return { ok: false, status: 409, body: buildPlanUpgradeErrorBody(paidPlan, scope, includedTargets.length) };
  }

  const campaignGroupKey = scope === "single"
    ? ""
    : String((draft as any)?.campaignGroupKey || deriveCampaignGroupKey(locationSlug, campaignKey)).trim();

  if (campaignGroupKey) {
    const parent: CampaignGroupRow = {
      campaignGroupKey,
      campaignKey,
      campaignScope: scope,
      campaignPreset,
      seedLocationULID: ownerUlid,
      seedLocationSlug: locationSlug,
      startDate: String(draft?.startDate || "").trim(),
      endDate: String(draft?.endDate || "").trim(),
      createdAt: new Date().toISOString(),
      stripeSessionId,
      planTier: normalizePlanTier(paidPlan?.tier),
      maxPublishedLocations: Math.max(0, Number(paidPlan?.maxPublishedLocations || 0) || 0)
    };
    await env.KV_STATUS.put(campaignGroupKeyKey(campaignGroupKey), JSON.stringify(parent));
  }

  for (const target of includedTargets) {
    await writeCampaignChildRow({
      env,
      targetUlid: target.ulid,
      targetSlug: target.slug,
      draft: { ...draft, campaignPreset },
      campaignGroupKey,
      stripeSessionId,
      inherited: false
    });
  }

  return {
    ok: true,
    campaignGroupKey,
    includedTargets,
    endDate: String(draft?.endDate || "").trim()
  };
}

async function writeCampaignChildRow(params: {
  env: Env;
  targetUlid: string;
  targetSlug: string;
  draft: any;
  campaignGroupKey: string;
  stripeSessionId: string;
  inherited: boolean;
}): Promise<void> {
  const { env, targetUlid, targetSlug, draft, campaignGroupKey, stripeSessionId, inherited } = params;

  const histKey = campaignsByUlidKey(targetUlid);
  const hist = await env.KV_STATUS.get(histKey, { type: "json" }) as any;
  const arr: any[] = Array.isArray(hist) ? hist : [];

  const row = {
    ...draft,
    locationID: targetUlid,
    locationULID: targetUlid,
    locationSlug: targetSlug,
    campaignGroupKey,
    campaignScope: normCampaignScope(draft?.campaignScope),
    status: "Active",
    promotedAt: new Date().toISOString(),
    stripeSessionId
  } as any;

  if (inherited) row.inheritedAt = new Date().toISOString();

  const next = arr.filter((x) => {
    const sameKey = String(x?.campaignKey || "").trim() === String(row?.campaignKey || "").trim();
    const sameGroup = String(x?.campaignGroupKey || "").trim() === String(row?.campaignGroupKey || "").trim();
    return !(sameKey && sameGroup);
  });

  next.push(row);
  await env.KV_STATUS.put(histKey, JSON.stringify(next));
}

async function materializeInheritedAllScopeForCurrentUlid(
  req: Request,
  env: Env,
  currentUlid: string
): Promise<{
  addedRows: number;
  addedGroups: number;
  blockedRows: number;
  blockedGroups: number;
  blockedPlanTier: PlanTier | "";
  blockedMaxPublishedLocations: number;
}> {  
  const eligible = await eligibleLocationsForRequest(req, env, currentUlid);
  const eligibleByUlid = new Map(eligible.map((x) => [x.ulid, x]));
  const currentLoc = eligibleByUlid.get(currentUlid);
  if (!currentLoc) return { addedRows: 0, addedGroups: 0, blockedRows: 0, blockedGroups: 0, blockedPlanTier: "", blockedMaxPublishedLocations: 0 };  

  const currentHistKey = campaignsByUlidKey(currentUlid);
  const currentHistRaw = await env.KV_STATUS.get(currentHistKey, { type: "json" }) as any;
  const currentRows: any[] = Array.isArray(currentHistRaw) ? currentHistRaw : [];

  const existing = new Set(
    currentRows
      .map((r: any) => `${String(r?.campaignGroupKey || "").trim()}::${String(r?.campaignKey || "").trim()}`)
      .filter(Boolean)
  );

  const countIncludedForGroup = async (groupKey: string, campaignKey: string): Promise<number> => {
    let count = 0;
    for (const checkLoc of eligible) {
      const histRaw = await env.KV_STATUS.get(campaignsByUlidKey(checkLoc.ulid), { type: "json" }) as any;
      const rows: any[] = Array.isArray(histRaw) ? histRaw : [];
      const hit = rows.some((r: any) =>
        String(r?.campaignGroupKey || "").trim() === groupKey &&
        String(r?.campaignKey || "").trim() === campaignKey &&
        effectiveCampaignStatus(r) !== "finished"
      );
      if (hit) count += 1;
    }
    return count;
  };

  let addedRows = 0;
  let blockedRows = 0;
  const touchedGroups = new Set<string>();
  const blockedGroups = new Set<string>();
  let blockedPlanTier: PlanTier | "" = "";
  let blockedMaxPublishedLocations = 0;  
  const nowMs = Date.now();

  for (const loc of eligible) {
    const histRaw = await env.KV_STATUS.get(campaignsByUlidKey(loc.ulid), { type: "json" }) as any;
    const rows: any[] = Array.isArray(histRaw) ? histRaw : [];

    for (const row of rows) {
      const groupKey = String(row?.campaignGroupKey || "").trim();
      const campaignKey = String(row?.campaignKey || "").trim();
      if (!groupKey || !campaignKey) continue;
      if (normCampaignScope(row?.campaignScope) !== "all") continue;

      const st = effectiveCampaignStatus(row);
      if (st !== "active" && st !== "suspended") continue;

      const endMs = parseYmdUtcMs(String(row?.endDate || ""));
      if (Number.isFinite(endMs) && nowMs > (endMs + 24 * 60 * 60 * 1000 - 1)) continue;

      const sig = `${groupKey}::${campaignKey}`;
      if (existing.has(sig)) continue;

      const parent = await env.KV_STATUS.get(campaignGroupKeyKey(groupKey), { type: "json" }) as any;
      const maxAllowed = Math.max(
        0,
        Number(parent?.maxPublishedLocations || row?.maxPublishedLocations || 0) || 0
      );

      if (maxAllowed > 0) {
        const includedCount = await countIncludedForGroup(groupKey, campaignKey);
        if (includedCount >= maxAllowed) {
          blockedRows += 1;
          blockedGroups.add(groupKey);
          if (!blockedPlanTier) blockedPlanTier = normalizePlanTier(parent?.planTier || row?.planTier);
          if (!blockedMaxPublishedLocations) blockedMaxPublishedLocations = maxAllowed;
          continue;
        }
      }

      await writeCampaignChildRow({
        env,
        targetUlid: currentUlid,
        targetSlug: currentLoc.slug,
        draft: row,
        campaignGroupKey: groupKey,
        stripeSessionId: String(row?.stripeSessionId || "").trim(),
        inherited: true
      });

      existing.add(sig);
      addedRows += 1;
      touchedGroups.add(groupKey);
    }
  }

  return { addedRows, addedGroups: touchedGroups.size, blockedRows, blockedGroups: blockedGroups.size, blockedPlanTier, blockedMaxPublishedLocations };  
}

type CampaignStatus =
  | "Active"
  | "Paused"
  | "Finished"
  | "Suspended"
  | "Draft";

interface CampaignRow {
  // Identity
  locationID: string;              // canonical ULID (required in KV representation)
  campaignKey: string;
  campaignGroupKey?: string;
  campaignScope?: string;          // single | selected | all
  campaignName?: string;
  sectorKey?: string;
  brandKey?: string;
  context?: string;

  // Core lifecycle
  startDate: string;               // YYYY-MM-DD
  endDate: string;                 // YYYY-MM-DD
  status: CampaignStatus | string; // tolerate legacy capitalization
  statusOverride?: CampaignStatus | string;

  // Rules (rich model; validated/used progressively)
  campaignType?: string;
  targetChannels?: string[] | string;
  offerType?: string;
  discountKind?: string;           // Percent | Amount | None
  campaignDiscountValue?: number | string;
  eligibilityType?: string;
  eligibilityNotes?: string;
  selectedLocationULIDs?: string[];

  // Attribution
  utmSource?: string;
  utmMedium?: string;
  utmCampaign?: string;

  // Misc
  inheritedAt?: string;
  promotedAt?: string;
  stripeSessionId?: string;
  notes?: string;
}

// Safe date parsing: accept only YYYY-MM-DD; return ms at UTC midnight
function parseYmdUtcMs(s: string): number {
  const v = String(s || "").trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) return NaN;
  const t = Date.parse(`${v}T00:00:00Z`);
  return Number.isFinite(t) ? t : NaN;
}

function normStatus(v: unknown): string {
  return String(v || "").trim().toLowerCase();
}

function effectiveCampaignStatus(row: CampaignRow): string {
  const ov = normStatus(row.statusOverride);
  if (ov) return ov;
  return normStatus(row.status);
}

async function campaignEntitlementForUlid(
  env: Env,
  ulid: string,
  nowMs = Date.now()
): Promise<{ entitled: boolean; campaignKey: string; endDate: string }> {
  // Optional fast path (can be written later during seed / updates)
  try {
    const fast = await env.KV_STATUS.get(`campaigns:activeIndex:${ulid}`, { type: "json" }) as any;
    if (fast && typeof fast === "object") {
      const entitled = fast.entitled === true;
      const campaignKey = String(fast.campaignKey || "").trim();
      const endDate = String(fast.endDate || "").trim();
      if (entitled && campaignKey && /^\d{4}-\d{2}-\d{2}$/.test(endDate)) {
        const endMs = parseYmdUtcMs(endDate);
        if (Number.isFinite(endMs) && endMs >= nowMs) {
          return { entitled: true, campaignKey, endDate };
        }
      }
      // If fast says not entitled, we still fall through (fast index may be stale)
    }
  } catch {
    // fall through to full evaluation
  }

  const raw = await env.KV_STATUS.get(campaignsByUlidKey(ulid), { type: "json" }) as any;
  const rows: CampaignRow[] = Array.isArray(raw) ? raw : [];

  if (!rows.length) return { entitled: false, campaignKey: "", endDate: "" };

  // Entitling rule:
  // - effective status is "active"
  // - today within [startDate, endDate] inclusive (UTC dates)
  const active: Array<{ row: CampaignRow; startMs: number; endMs: number }> = [];

  for (const row of rows) {
    if (!row || String(row.locationID || "").trim() !== ulid) continue;

    const st = effectiveCampaignStatus(row);
    if (st !== "active") continue;

    const startMs = parseYmdUtcMs(String(row.startDate || ""));
    const endMs = parseYmdUtcMs(String(row.endDate || ""));
    if (!Number.isFinite(startMs) || !Number.isFinite(endMs)) continue;

    // inclusive window: start <= now <= end+24h-1ms; easier: compare date-midnights
    if (nowMs < startMs) continue;
    if (nowMs > (endMs + 24 * 60 * 60 * 1000 - 1)) continue;

    active.push({ row, startMs, endMs });
  }

  if (!active.length) return { entitled: false, campaignKey: "", endDate: "" };

  // Deterministic "primary" selection:
  // 1) earliest endDate wins (soonest to expire)
  // 2) if tie, latest startDate wins
  active.sort((a, b) => {
    if (a.endMs !== b.endMs) return a.endMs - b.endMs;
    return b.startMs - a.startMs;
  });

  const winner = active[0].row;
  const campaignKey = String(winner.campaignKey || "").trim();
  const endDate = String(winner.endDate || "").trim();

  return { entitled: true, campaignKey, endDate };
}

async function activeCampaignRowForUlid(
  env: Env,
  ulid: string,
  nowMs = Date.now()
): Promise<CampaignRow | null> {
  const raw = await env.KV_STATUS.get(campaignsByUlidKey(ulid), { type: "json" }) as any;
  const rows: CampaignRow[] = Array.isArray(raw) ? raw : [];
  if (!rows.length) return null;

  const active: Array<{ row: CampaignRow; startMs: number; endMs: number }> = [];

  for (const row of rows) {
    if (!row || String(row.locationID || "").trim() !== ulid) continue;

    const st = effectiveCampaignStatus(row);
    if (st !== "active") continue;

    const startMs = parseYmdUtcMs(String(row.startDate || ""));
    const endMs = parseYmdUtcMs(String(row.endDate || ""));
    if (!Number.isFinite(startMs) || !Number.isFinite(endMs)) continue;

    if (nowMs < startMs) continue;
    if (nowMs > (endMs + 24 * 60 * 60 * 1000 - 1)) continue;

    active.push({ row, startMs, endMs });
  }

  if (!active.length) return null;

  active.sort((a, b) => {
    if (a.endMs !== b.endMs) return a.endMs - b.endMs;
    return b.startMs - a.startMs;
  });

  return active[0].row || null;
}

// Visibility policy (Business-first):
// - "promoted": campaign/exclusive operation is active (paid window).
// - "visible": courtesy visibility after paid window ends (Y=2 → 60 days).
// - "hidden": not discoverable inside NaviGen (direct link may still open LPM later).
// This is a NaviGen-internal discoverability concept, not web indexing.
type VisibilityState = "promoted" | "visible" | "hidden";

async function computeVisibilityState(env: Env, ulid: string, nowMs = Date.now()): Promise<{
  visibilityState: VisibilityState;
  ownedNow: boolean;
  exclusiveUntil: string;   // ISO or ""
  courtesyUntil: string;    // ISO or ""
}> {
  // Courtesy window approved: Y = 2 → 60 days
  const COURTESY_MS = 60 * 24 * 60 * 60 * 1000;

  const ownKey = `ownership:${ulid}`;
  const ownership = await env.KV_STATUS.get(ownKey, { type: "json" }) as any;

  const exclusiveUntilIso = String(ownership?.exclusiveUntil || "").trim();
  const exclusiveUntil = exclusiveUntilIso ? new Date(exclusiveUntilIso) : null;

  // No ownership record → treat as publicly discoverable.
  if (!exclusiveUntil || Number.isNaN(exclusiveUntil.getTime())) {
    return {
      visibilityState: "visible",
      ownedNow: false,
      exclusiveUntil: "",
      courtesyUntil: ""
    };
  }

  const ownedNow = exclusiveUntil.getTime() > nowMs;
  if (ownedNow) {
    return {
      visibilityState: "promoted",
      ownedNow: true,
      exclusiveUntil: exclusiveUntil.toISOString(),
      courtesyUntil: new Date(exclusiveUntil.getTime() + COURTESY_MS).toISOString()
    };
  }

  const courtesyUntil = new Date(exclusiveUntil.getTime() + COURTESY_MS);
  const isCourtesy = courtesyUntil.getTime() > nowMs;

  return {
    visibilityState: isCourtesy ? "visible" : "hidden",
    ownedNow: false,
    exclusiveUntil: exclusiveUntil.toISOString(),
    courtesyUntil: courtesyUntil.toISOString()
  };
}

type TargetIdentityRoute = "existing-location" | "brand-new-private-shell";

type TargetIdentity = {
  route: TargetIdentityRoute;
  ulid: string;
  locationID: string;
  draftULID: string;
  draftSessionId: string;
};

async function readPrivateShellDraft(env: Env, draftULID: string, draftSessionId: string): Promise<any | null> {
  const key = `override_draft:${draftULID}:${draftSessionId}`;
  const hitJson = await env.KV_STATUS.get(key, { type: "json" }) as any;
  if (hitJson) return hitJson;
  const hitText = await env.KV_STATUS.get(key, "text");
  if (!hitText) return null;
  try { return JSON.parse(hitText); } catch { return { raw: hitText }; }
}

async function resolveTargetIdentity(
  env: Env,
  input: { locationID?: unknown; draftULID?: unknown; draftSessionId?: unknown },
  opts: { validateDraft?: boolean } = {}
): Promise<TargetIdentity | null> {
  const locationID = String(input?.locationID || "").trim();
  const draftULID = String(input?.draftULID || "").trim();
  const draftSessionId = String(input?.draftSessionId || "").trim();

  const hasLocation = !!locationID;
  const hasDraft = !!draftULID || !!draftSessionId;
  if ((hasLocation && hasDraft) || (!hasLocation && !hasDraft)) return null;

  if (hasLocation) {
    const ulid = await resolveUid(locationID, env);
    if (!ulid) return null;
    return {
      route: "existing-location",
      ulid,
      locationID,
      draftULID: "",
      draftSessionId: ""
    };
  }

  if (!ULID_RE.test(draftULID) || !draftSessionId) return null;
  if (opts.validateDraft) {
    const draft = await readPrivateShellDraft(env, draftULID, draftSessionId);
    if (!draft) return null;
  }

  return {
    route: "brand-new-private-shell",
    ulid: draftULID,
    locationID: "",
    draftULID,
    draftSessionId
  };
}

async function increment(kv: KVNamespace, key: string): Promise<void> {
  // Simple read-modify-write; good enough for MVP. Upgrade to Durable Object later.
  const current = parseInt((await kv.get(key)) || "0", 10) || 0;
  await kv.put(key, String(current + 1));
}

// -------- QR log helpers (per-scan metadata for QR Info / Campaigns) --------

interface QrLogEntry {
  time: string;          // ISO timestamp (UTC)
  locationID: string;    // canonical ULID (location that owns this QR)
  day: string;           // YYYY-MM-DD (for quick filtering)
  ua: string;            // User-Agent
  lang: string;          // Accept-Language
  country: string;       // Cloudflare country code (scanner location, best-effort)
  city: string;          // Cloudflare city (scanner location, best-effort)
  source: string;        // logical source (for now: "qr-scan")
  signal: string;        // "scan" | "redeem" | other
  visitor: string;       // provisional visitor fingerprint (e.g. UA+country)
  campaignKey: string;   // resolved from campaign.json when possible, else empty
}

interface CampaignDef {
  locationID: string;
  campaignKey: string;
  campaignName?: string;
  brandKey?: string;
  context?: string;
  startDate?: string;
  endDate?: string;
  status?: string;
  sectorKey?: string;
  eligibilityType?: string;
  discountKind?: string;
  discountValue?: number | null;
}

/**
 * Fetch campaign definitions once per request.
 * Reads /data/campaign.json from the main site origin.
 */
async function loadCampaigns(baseOrigin: string, env: Env): Promise<CampaignDef[]> {
  const normalizeDate = (v: any): string | undefined => {
    if (!v) return undefined;
    const s = String(v).trim();
    if (!s) return undefined;
    if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;

    const d = new Date(s);
    if (isNaN(d.getTime())) return undefined;

    // SHIFT: add 12 hours before converting to ISO date to avoid
    // off-by-one for midnight local times in campaign_data.
    d.setHours(d.getHours() + 12);

    return d.toISOString().slice(0, 10); // YYYY-MM-DD
  };

  try {
    const src = new URL("/data/campaigns.json", baseOrigin || "https://navigen.io").toString();
    const resp = await fetch(src, {
      cf: { cacheTtl: 60, cacheEverything: true },
      headers: { "Accept": "application/json" }
    });
    if (!resp.ok) return [];
    const data: any = await resp.json();
    const rows: any[] = Array.isArray(data) ? data : (Array.isArray(data?.campaigns) ? data.campaigns : []);

    // First map raw rows
    const rawDefs = rows.map((r) => ({
      locationID: String(r.locationID || "").trim(),
      campaignKey: String(r.campaignKey || "").trim(),
      campaignName: typeof r.campaignName === "string" ? r.campaignName : undefined,
      brandKey: typeof r.brandKey === "string" ? r.brandKey : undefined,
      context: typeof r.context === "string" ? r.context : undefined,
      startDate: normalizeDate(r.startDate),
      endDate: normalizeDate(r.endDate),
      status: typeof r.status === "string" ? r.status : undefined,
      sectorKey: typeof r.sectorKey === "string" ? r.sectorKey : undefined,
      eligibilityType: typeof r.eligibilityType === "string" ? r.eligibilityType : undefined,
      discountKind: typeof r.discountKind === "string" ? r.discountKind : undefined,
      discountValue: typeof r.discountValue === "number" ? r.discountValue : null
    })).filter(r => r.locationID && r.campaignKey);

    // Now canonicalize locationID to ULID when possible
    const normalized: CampaignDef[] = [];
    for (const def of rawDefs) {
      const ulid = await resolveUid(def.locationID, env);
      normalized.push({
        ...def,
        locationID: ulid || def.locationID
      });
    }

    return normalized;
  } catch {
    return [];
  }
}

interface FinanceRow {
  sectorKey: string;
  countryCode: string;
  currency: string;
  campFee: number | null;
  campFeeRate: number | null;
}

/**
 * Load finance (sector-based fee) definitions from /data/finance.json.
 */
async function loadFinance(baseOrigin: string, env: Env): Promise<FinanceRow[]> {
  try {
    const src = new URL("/data/finance.json", baseOrigin || "https://navigen.io").toString();
    const resp = await fetch(src, {
      cf: { cacheTtl: 60, cacheEverything: true },
      headers: { "Accept": "application/json" }
    });
    if (!resp.ok) return [];
    const data: any = await resp.json();
    const rows: any[] = Array.isArray(data) ? data : (Array.isArray(data?.finance) ? data.finance : []);
    return rows.map((r) => ({
      sectorKey: String(r.sectorKey || "").trim(),
      countryCode: String(r.countryCode || "").trim(),
      currency: String(r.currency || "").trim(),
      campFee: typeof r.campFee === "number" ? r.campFee : null,
      campFeeRate: typeof r.campFeeRate === "number" ? r.campFeeRate : null
    })).filter(r => r.sectorKey && r.countryCode);
  } catch {
    return [];
  }
}

/**
 * Given a locationID + day, find the best matching campaignKey.
 * For now: pick any campaign for that location where:
 *   - status is not "ended"
 *   - and the scan day is between startDate and endDate (if those exist)
 * If none match, return "".
 */
function pickCampaignForScan(
  campaigns: CampaignDef[],
  locationID: string,
  day: string
): string {
  const candidates = campaigns.filter(c => c.locationID === locationID);
  if (!candidates.length) return "";

  const d = day;
  let best: CampaignDef | null = null;

  for (const c of candidates) {
    const startOK = !c.startDate || d >= c.startDate;
    const endOK = !c.endDate || d <= c.endDate;
    const statusOK = !c.status || c.status.toLowerCase() !== "ended";
    if (!startOK || !endOK || !statusOK) continue;
    // Pick first matching; later we can add priority if needed.
    best = c;
    break;
  }
  return best?.campaignKey || "";
}

/**
 * Log a QR scan into KV_STATS under qrlog:<loc>:<day>:<scanId>.
 * This powers the QR Info and Campaigns views in the dashboard.
 */
async function logQrScan(
  kv: KVNamespace,
  env: Env,
  loc: string,
  req: Request
): Promise<void> {
  try {
    const now = new Date();
    const day = dayKeyFor(now, undefined, (req as any).cf?.country || "");
    const timeISO = now.toISOString();

    // For scans coming directly from the app, we use the browser UA/lang.
    const ua = req.headers.get("User-Agent") || "";
    const lang = req.headers.get("Accept-Language") || "";

    const country = ((req as any).cf?.country || "").toString();
    const city = ((req as any).cf?.city || "").toString();
    const source = "qr-scan"; // logical source for Business/Promotion QR views
    const signal = "scan";    // distinguishes scan events from redeems/invalids

    // provisional visitor identity (UA + country); no IP stored
    const visitor = `${ua}|${country}`;

    // Info QR scans must remain detached from campaigns
    const campaignKey = ""; // Info QR scans must never attach to campaigns

    // Generate a short random scan ID (hex string)
    const bytes = new Uint8Array(6);
    (crypto as any).getRandomValues(bytes);
    const scanId = Array.from(bytes).map(b => b.toString(16).padStart(2, "0")).join("");

    const entry: QrLogEntry = {
      time: timeISO,
      locationID: loc,
      day,
      ua,
      lang,
      country,
      city,
      source,
      signal,
      visitor,
      campaignKey
    };

    const key = `qrlog:${loc}:${day}:${scanId}`;
    // TTL: 56 days for QR logs (~8 weeks)
    const ttlSeconds = 56 * 24 * 60 * 60;
    await kv.put(key, JSON.stringify(entry), { expirationTtl: ttlSeconds });
  } catch {
    // never throw from logging; stats must not break the main flow
  }
}

/**
 * Log that a promotion QR was shown (ARMED) for a given campaign.
 * This is called when /api/promo-qr is used to generate a promo QR code.
 */
async function logQrArmed(
  kv: KVNamespace,
  _env: Env,
  loc: string,
  req: Request,
  campaignKey: string
): Promise<void> {
  try {
    const now = new Date();
    const day = dayKeyFor(now, undefined, (req as any).cf?.country || "");
    const timeISO = now.toISOString();

    const ua = req.headers.get("User-Agent") || "";
    const lang = req.headers.get("Accept-Language") || "";

    const country = ((req as any).cf?.country || "").toString();
    const city = ((req as any).cf?.city || "").toString();
    const source = "qr-redeem"; // same logical family as promotion QR
    const signal = "armed";     // distinguishes promo QR shown from scans/redeems

    const visitor = `${ua}|${country}`;

    // explicit campaignKey: promo QR is always tied to a campaign
    const keyBytes = new Uint8Array(6);
    (crypto as any).getRandomValues(keyBytes);
    const scanId = Array.from(keyBytes).map(b => b.toString(16).padStart(2, "0")).join("");

    const entry: QrLogEntry = {
      time: timeISO,
      locationID: loc,
      day,
      ua,
      lang,
      country,
      city,
      source,
      signal,
      visitor,
      campaignKey
    };

    const key = `qrlog:${loc}:${day}:${scanId}`;
    const ttlSeconds = 56 * 24 * 60 * 60; // align with other QR logs (~8 weeks)
    await kv.put(key, JSON.stringify(entry), { expirationTtl: ttlSeconds });
  } catch {
    // never throw from logging; stats must not break the main flow
  }
}

/**
 * Log a QR redeem into KV_STATS under qrlog:<loc>:<day>:<scanId>.
 * This powers the QR Info and Campaigns views in the dashboard.
 */
async function logQrRedeem(
  kv: KVNamespace,
  env: Env,
  loc: string,
  req: Request,
  campaignKey: string = ""
): Promise<void> {
  try {
    const now = new Date();
    const day = dayKeyFor(now, undefined, (req as any).cf?.country || "");
    const timeISO = now.toISOString();

    const ua = req.headers.get("X-NG-UA") || req.headers.get("User-Agent") || "";
    const lang = req.headers.get("X-NG-Lang") || req.headers.get("Accept-Language") || "";

    const country = ((req as any).cf?.country || "").toString();
    const city = ((req as any).cf?.city || "").toString();
    const source = "qr-redeem"; // logical source for Promotion QR redemptions
    const signal = "redeem";    // distinguishes redeem events from scans

    // provisional visitor identity (UA + country); no IP stored
    const visitor = `${ua}|${country}`;

    const ck = String(campaignKey || "").trim();

    // Generate a short random scan ID (hex string)
    const bytes = new Uint8Array(6);
    (crypto as any).getRandomValues(bytes);
    const scanId = Array.from(bytes).map(b => b.toString(16).padStart(2, "0")).join("");

    const entry: QrLogEntry = {
      time: timeISO,
      locationID: loc,
      day,
      ua,
      lang,
      country,
      city,
      source,
      signal,
      visitor,
      campaignKey: ck
    };

    const key = `qrlog:${loc}:${day}:${scanId}`;
    // TTL: 56 days for QR logs (~8 weeks)
    const ttlSeconds = 56 * 24 * 60 * 60;
    await kv.put(key, JSON.stringify(entry), { expirationTtl: ttlSeconds });
  } catch {
    // never throw from logging; stats must not break the main flow
  }
}

/**
 * Log an invalid QR redeem attempt into KV_STATS (signal="invalid").
 */
async function logQrRedeemInvalid(
  kv: KVNamespace,
  env: Env,
  loc: string,
  req: Request,
  campaignKey: string = ""
): Promise<void> {
  try {
    const now = new Date();
    const day = dayKeyFor(now, undefined, (req as any).cf?.country || "");
    const timeISO = now.toISOString();

    const ua = req.headers.get("X-NG-UA") || req.headers.get("User-Agent") || "";
    const lang = req.headers.get("X-NG-Lang") || req.headers.get("Accept-Language") || "";

    const country = ((req as any).cf?.country || "").toString();
    const city = ((req as any).cf?.city || "").toString();
    const source = "qr-redeem"; // same logical source
    const signal = "invalid";   // distinguishes invalid attempts

    // provisional visitor identity (UA + country); no IP stored
    const visitor = `${ua}|${country}`;

    const ck = String(campaignKey || "").trim();

    const bytes = new Uint8Array(6);
    (crypto as any).getRandomValues(bytes);
    const scanId = Array.from(bytes).map(b => b.toString(16).padStart(2, "0")).join("");

    const entry: QrLogEntry = {
      time: timeISO,
      locationID: loc,
      day,
      ua,
      lang,
      country,
      city,
      source,
      signal,
      visitor,
      campaignKey: ck
    };

    const key = `qrlog:${loc}:${day}:${scanId}`;
    const ttlSeconds = 56 * 24 * 60 * 60;
    await kv.put(key, JSON.stringify(entry), { expirationTtl: ttlSeconds });
  } catch {
    // never throw from logging; stats must not break the main flow
  }
}

// -------- Redeem token helpers (one-time Promotion QR tokens) --------

interface RedeemTokenRecord {
  locationID: string;
  campaignKey: string;
  status: "fresh" | "redeemed" | "invalid";
  createdAt: string;
}

/**
 * Create a fresh redeem token for a given location + campaignKey.
 * Token is a short random hex string, stored under redeem:<token>.
 */
async function createRedeemToken(
  kv: KVNamespace,
  locationID: string,
  campaignKey: string
): Promise<string> {
  // Generate 8-byte random token (16 hex chars)
  const bytes = new Uint8Array(8);
  (crypto as any).getRandomValues(bytes);
  const token = Array.from(bytes).map(b => b.toString(16).padStart(2, "0")).join("");

  const record: RedeemTokenRecord = {
    locationID,
    campaignKey,
    status: "fresh",
    createdAt: new Date().toISOString()
  };

  const key = `redeem:${token}`;
  const ttlSeconds = 56 * 24 * 60 * 60; // align with QR logs (~8 weeks)
  await kv.put(key, JSON.stringify(record), { expirationTtl: ttlSeconds });

  return token;
}

/**
 * Try to consume a redeem token for a given location + campaignKey.
 * Returns "ok" if token is valid and now marked redeemed, otherwise "invalid".
 */
async function consumeRedeemToken(
  kv: KVNamespace,
  token: string,
  locationID: string,
  campaignKey: string
): Promise<"ok" | "used" | "invalid"> {
  if (!token) return "invalid";
  const key = `redeem:${token}`;
  const raw = await kv.get(key, "text");
  if (!raw) return "invalid";

  let rec: RedeemTokenRecord;
  try {
    rec = JSON.parse(raw) as RedeemTokenRecord;
  } catch {
    return "invalid";
  }

  if (rec.locationID !== locationID || rec.campaignKey !== campaignKey) {
    return "invalid";
  }

  if (rec.status === "redeemed") {
    return "used";
  }

  if (rec.status !== "fresh") {
    return "invalid";
  }

  // Mark as redeemed
  rec.status = "redeemed";
  await kv.put(key, JSON.stringify(rec));
  return "ok";
}

interface BillingRecord {
  locationID: string;
  campaignKey: string;
  sectorKey: string;
  countryCode: string;
  currency: string;
  timestamp: string;
  campFee: number;
  campFeeRate: number | null;
}

/**
 * Write a billing ledger record into KV_STATS under billing:YYYY-MM:<loc>:<id>.
 * For now we reuse KV_STATS as storage; later this can be moved to its own namespace.
 */
async function writeBillingRecord(kv: KVNamespace, rec: BillingRecord): Promise<void> {
  const d = new Date(rec.timestamp || new Date().toISOString());
  const ym = `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}`;
  // random 6-byte id
  const bytes = new Uint8Array(6);
  (crypto as any).getRandomValues(bytes);
  const rid = Array.from(bytes).map(b => b.toString(16).padStart(2, "0")).join("");

  const key = `billing:${ym}:${rec.locationID}:${rid}`;
  await kv.put(key, JSON.stringify(rec), { expirationTtl: 60 * 60 * 24 * 366 });
}
